# 프로필 사진 배경 지우기(누끼). 사용: python 도구/누끼.py <사진 경로> [저장 경로=assets/profile_cut.png]
# 처음 한 번은 rembg 설치와 인물용 모델 다운로드 때문에 몇 분 걸려요: pip install "rembg[cpu]"
import sys
from PIL import Image
from rembg import remove, new_session

src = sys.argv[1]
dst = sys.argv[2] if len(sys.argv) > 2 else "assets/profile_cut.png"
im = Image.open(src).convert("RGB")
try:
    session = new_session("birefnet-portrait")   # 머리카락 경계가 깔끔한 인물 전용 모델
except Exception:
    session = new_session("u2net_human_seg")     # 위 모델을 못 받으면 가벼운 모델로
cut = remove(im, session=session)
box = cut.getbbox()
if box is None:
    sys.exit("사람을 찾지 못했어요. 얼굴과 상반신이 잘 보이는 사진으로 바꿔 주세요.")
cut = cut.crop(box)
cut.thumbnail((1000, 1400))
cut.save(dst, "PNG", optimize=True)
print("저장:", dst, cut.size)
