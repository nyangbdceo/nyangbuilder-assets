// AI 오피스 화면 연결: 루프, 카메라(자동 투어, 따라가기, 자유), HUD.
import { Office, blockAreas } from './sim.js';
import { propFootprints } from './art.js';
import { Renderer, paintAvatar, paintGear, drawMinimap, baseKeyOf, scaleOf, pctOf, ZOOM_100 } from './render.js';
import { TEAMS, WORLD, MEETING_TABLE, CEO_SEAT, ENTRANCE, STAGE, COMPANY, ASSISTANT, BOSS, CHARACTERS, NOTICES } from './data.js';
import { startLive, drawLiveMarks } from './live.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const office = new Office();
blockAreas(propFootprints(office.staff)); // 장식 소품 발자리를 길찾기에서 뺀다
const canvas = $('map');
const view = new Renderer(canvas);
view.office = office;

let speed = 2;
let paused = params.get('paused') === '1';

// 확인용: ?t=1030 (그 시각까지 빨리 돌림), ?paused=1
if (params.get('t')) {
  const t = params.get('t').padStart(4, '0');
  office.fastForward(Number(t.slice(0, 2)) * 60 + Number(t.slice(2)));
}
// 실데이터 연결 (에이전트 실행 기록). ?live=0이면 연결하지 않고 시뮬레이션만
const live = params.get('live') === '0' ? null : startLive(office);

const hhmm = (m) => `${String(Math.floor(m / 60) % 24).padStart(2, '0')}:${String(Math.floor(m % 60)).padStart(2, '0')}`;
const present = () => office.staff.filter((e) => e.state !== 'off');
const realHhmm = (ms) => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };

// ---------- 화면 크기 ----------
// 확대를 직접 바꾸기 전에는 창 크기가 바뀌면 그 화면의 기본 배율로 다시 맞춘다 (고를 수 있는 배율이 화면마다 다르다)
let ready = false;
function fit() {
  view.resize(window.innerWidth, window.innerHeight); // 맞춤이면 새 화면에 다시 맞추고, 아니면 가장 가까운 단계로
  if (!ready) return;
  if (!cam.userZoom && !view.selected && cam.mode !== 'tour') home(); else setZoom(view.zoom, view.center());
}
window.addEventListener('resize', fit);
fit();

// ---------- 카메라 ----------
// 배율: 맞춤(사무실 전체, 별도 버튼) + 50%, 100%, 150% (100% = 캐릭터 원본 도트 1칸이 화면 1 CSS px). 순서는 view.steps() (첫 칸이 맞춤).
// view.level은 배율에서 나온다: all = 맞춤 (카메라 고정, 미니맵 숨김), 그 밖은 미니맵과 방향키로 옮긴다.
// 모드: tour = 일이 생긴 곳을 6초마다 옮겨 다님 / follow = 고른 직원을 따라감 / free = 미니맵이나 방향키로 옮긴 곳에 머묾
const cam = { mode: 'free', target: null, until: 0, lastKey: '', userZoom: false };
const MIDDLE = { x: WORLD.w / 2, y: (WORLD.h + STAGE.top) / 2 };
const zoomedOut = () => view.zoom < ZOOM_100 - 1e-9; // 직원을 고르거나 투어를 켜면 100%로 들어가는 배율
const stepIndex = (st) => st.reduce((bi, s, i) => (Math.abs(s.z - view.zoom) < Math.abs(st[bi].z - view.zoom) ? i : bi), 0);
function setZoom(z, at) {
  const p = at || (cam.mode === 'follow' && view.selected) || view.center();
  view.setZoom(z, p.x, p.y);
  const st = view.steps(), i = stepIndex(st);
  $('zoom-pct').textContent = view.level === 'all' ? '맞춤' : `${pctOf(view.zoom)}%`; // 맞춤은 퍼센트 단계가 아니다
  $('zoom-label').title = '배율 고르기';
  $('zoom-fit').classList.toggle('on', view.level === 'all');
  $('zoom-out').disabled = i === 0;
  $('zoom-in').disabled = i === st.length - 1;
  document.querySelector('.mini').hidden = view.level === 'all';
  if (view.level === 'all' && cam.mode === 'tour') setMode('free');
  if (view.level !== 'all' && cam.mode === 'free') cam.target = { key: 'free', x: view.center().x, y: view.center().y };
  if (!$('zoom-pop').hidden) renderZoomPop();
}
function setLevel(level, at) { // 이름으로 (확인용, 호환): all = 맞춤, wide = 50%, normal = 100%, close = 200%
  view.setLevel(level); setZoom(view.zoom, at);
}
// 처음 화면: 그 화면의 기본 배율(50%가 맞춤보다 크면 50%, 아니면 맞춤), 카메라는 사무실 가운데.
// 폰 폭(720px 이하)은 미니맵이 숨어 있어 옮겨 볼 수단이 없으니 맞춤으로 시작한다
const homeZoom = () => view.overviewZoom(); // 처음엔 바다부터 사무실까지 한 화면에
function home() { setMode('free'); setZoom(homeZoom(), MIDDLE); cam.target = { key: 'free', ...MIDDLE }; }
function pickZoom(z, at) {
  cam.userZoom = true;
  let focus = at;
  if (!focus && view.level === 'all' && view.selected) { focus = view.selected; setMode('follow'); }
  setZoom(z, focus);
}
function zoomStep(dir, at) {
  const st = view.steps(), i = stepIndex(st), j = Math.max(0, Math.min(st.length - 1, i + dir));
  if (j !== i) pickZoom(st[j].z, at);
}
// 배율 목록: 배율 글자를 누르면 바로 위에 종이 목록이 뜬다. 고르면 닫힘, 바깥을 누르거나 Esc도 닫힘
function renderZoomPop() {
  const pop = $('zoom-pop'), st = view.steps(), cur = stepIndex(st);
  for (const b of [...pop.querySelectorAll('button')]) b.remove();
  [...st].reverse().forEach((s) => { // 큰 배율이 위
    const b = document.createElement('button'), i = st.indexOf(s);
    b.setAttribute('role', 'option'); b.setAttribute('aria-selected', String(i === cur));
    b.className = i === cur ? 'on' : '';
    b.innerHTML = s.fit ? '<span>맞춤</span><small>사무실 전체</small>' : `<span>${pctOf(s.z)}%</span>`;
    b.onclick = (ev) => { ev.stopPropagation(); closeZoomPop(); pickZoom(s.z); };
    pop.append(b);
  });
  placeZoomPop();
}
function placeZoomPop() {
  const pop = $('zoom-pop'), r = $('zoom-label').getBoundingClientRect(), bar = document.querySelector('.bar-main').getBoundingClientRect();
  const w = pop.offsetWidth, x = Math.max(14, Math.min(window.innerWidth - w - 14, r.left + r.width / 2 - w / 2));
  Object.assign(pop.style, { left: `${Math.round(x)}px`, bottom: `${Math.round(window.innerHeight - bar.top + 10)}px` }); // 조작 바 위 (폰 폭 두 줄이어도 가리지 않게)
}
function openZoomPop() { $('zoom-pop').hidden = false; $('zoom-label').setAttribute('aria-expanded', 'true'); renderZoomPop(); }
function closeZoomPop() { $('zoom-pop').hidden = true; $('zoom-label').setAttribute('aria-expanded', 'false'); }
$('zoom-label').onclick = (ev) => { ev.stopPropagation(); if ($('zoom-pop').hidden) openZoomPop(); else closeZoomPop(); };
document.addEventListener('pointerdown', (ev) => { if (!$('zoom-pop').hidden && !ev.target.closest('#zoom-pop, #zoom-label')) closeZoomPop(); });
window.addEventListener('resize', () => { if (!$('zoom-pop').hidden) renderZoomPop(); });
$('zoom-in').onclick = () => zoomStep(1);
$('zoom-fit').onclick = () => pickZoom(view.overviewZoom()); // 맞춤: 사무실 전체 (예전 "전체")
$('zoom-out').onclick = () => zoomStep(-1);
// 휠: 조금씩 부드럽게 확대·축소, 마우스가 가리킨 곳은 그대로 둔다
canvas.addEventListener('wheel', (ev) => {
  ev.preventDefault();
  const st = view.steps(), lo = view.overviewZoom(), hi = st[st.length - 1].z;
  const w = view.toWorld(ev.clientX, ev.clientY);
  const z = Math.max(lo, Math.min(hi, view.zoom * Math.exp(-Math.max(-60, Math.min(60, ev.deltaY)) * 0.0022)));
  if (Math.abs(z - view.zoom) < 1e-6) return;
  if (cam.mode !== 'free') setMode('free');
  cam.userZoom = true;
  const c = { x: w.x - ev.clientX / z + view.cssW / z / 2, y: w.y - ev.clientY / z + view.cssH / z / 2 };
  setZoom(z, c);
  cam.target = { key: 'free', ...view.center() };
}, { passive: false });
const TOUR_MS = 6000;

function tourCandidates() {
  const c = [];
  if (office.meeting) c.push({ key: 'meeting', x: MEETING_TABLE.x + MEETING_TABLE.w / 2, y: MEETING_TABLE.y + 20, w: 4 });
  if (office.show) c.push({ key: 'stage', x: STAGE.x, y: STAGE.floor.y + 20, w: office.show.start ? 8 : 3 }); // 사내 공연 무대
  if (present().some((e) => e.state === 'report' || (e.state === 'walk' && e.next === 'report'))) c.push({ key: 'ceo', x: CEO_SEAT.x, y: CEO_SEAT.y + 30, w: 3 });
  for (const e of present()) {
    if (e.live || (e.task && e.task.live)) c.push({ key: e.id, person: e, w: 4 }); // 실제로 일하는 직원을 더 자주 비춘다
    else if (office.clock < e.happyUntil) c.push({ key: e.id, person: e, w: 3 });
    else if (e.bubble) c.push({ key: e.id, person: e, w: 2 });
    else if (e.state === 'walk' && e.id !== 'assistant') c.push({ key: e.id, person: e, w: 0.6 });
    else c.push({ key: e.id, person: e, w: 0.25 });
  }
  if (!c.length) c.push({ key: 'door', x: ENTRANCE.x, y: ENTRANCE.y - 60, w: 1 });
  return c.filter((x) => x.key !== cam.lastKey);
}
function nextTour(now) {
  const c = tourCandidates();
  let r = Math.random() * c.reduce((s, x) => s + x.w, 0);
  const pick = c.find((x) => (r -= x.w) <= 0) || c[0];
  cam.target = pick; cam.lastKey = pick.key; cam.until = now + TOUR_MS;
}
function targetPoint() {
  if (cam.mode === 'follow' && view.selected) return { x: view.selected.x, y: view.selected.y - 10 };
  const t = cam.target;
  if (!t) return view.center();
  if (t.person) return t.person.state === 'off' ? view.center() : { x: t.person.x, y: t.person.y - 10 };
  return { x: t.x, y: t.y };
}
function setMode(m) {
  cam.mode = m;
  $('btn-tour').classList.toggle('on', m === 'tour');
  if (m === 'tour') cam.until = 0;
}
// 자동 투어: 켜면 보통 단계로 돌고, 끄면 처음 화면(기본 단계, 사무실 가운데)으로 돌아간다
$('btn-tour').onclick = () => {
  if (cam.mode === 'tour') { cam.userZoom = false; home(); }
  else { select(null, true); setMode('tour'); if (zoomedOut()) setZoom(ZOOM_100); }
};

// 미니맵: 누른 곳으로 이동
const mini = $('mini');
mini.style.height = Math.round(192 * (WORLD.h - STAGE.top) / WORLD.w) + 'px'; // 월드 비율 그대로, 위로 공연 무대까지 (클릭 위치 = 월드 좌표)
mini.addEventListener('click', (ev) => {
  const r = mini.getBoundingClientRect();
  cam.target = { key: 'free', x: (ev.clientX - r.left) / r.width * WORLD.w, y: STAGE.top + (ev.clientY - r.top) / r.height * (WORLD.h - STAGE.top) };
  if (view.selected) select(null, true);
  setMode('free');
});

// 방향키: 카메라를 조금씩 옮긴다
const held = new Set();
document.addEventListener('keydown', (ev) => {
  if (ev.target.closest && ev.target.closest('input, textarea, select, [contenteditable]')) return; // 글자 입력 중에는 단축키 끔 (띄어쓰기, +, - 등)
  if (ev.code === 'Space') { ev.preventDefault(); setPaused(!paused); return; }
  if (ev.code === 'Escape') { if (!$('zoom-pop').hidden) closeZoomPop(); else if (!$('approvals').hidden) $('approvals').hidden = true; else select(null); return; }
  if (ev.key === '+' || ev.key === '=') { zoomStep(1); return; }
  if (ev.key === '-' || ev.key === '_') { zoomStep(-1); return; }
  if (ev.key.startsWith('Arrow') && view.level !== 'all') {
    ev.preventDefault();
    if (cam.mode !== 'free') { cam.target = view.center(); if (view.selected) select(null, true); setMode('free'); }
    held.add(ev.key);
  }
});
document.addEventListener('keyup', (ev) => held.delete(ev.key));

// ---------- 직원 선택 ----------
const hitAt = (ev) => {
  const w = view.toWorld(ev.clientX, ev.clientY);
  return view.hit(w.x, w.y, office);
};
canvas.addEventListener('pointermove', (ev) => {
  view.hover = hitAt(ev);
  canvas.classList.toggle('pointer', !!view.hover);
});
canvas.addEventListener('pointerleave', () => { view.hover = null; });
// 끌어서 옮기기: 누른 채 움직이면 화면이 따라오고, 거의 안 움직였으면 클릭(직원 고르기)
let drag = null, dragged = false;
canvas.addEventListener('pointerdown', (ev) => { if (ev.button === 0) { drag = { x: ev.clientX, y: ev.clientY, c: view.center() }; dragged = false; } });
window.addEventListener('pointermove', (ev) => {
  if (!drag) return;
  const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
  if (!dragged && Math.hypot(dx, dy) < 5) return;
  dragged = true; canvas.style.cursor = 'grabbing';
  if (cam.mode !== 'free') setMode('free');
  view.setCenter(drag.c.x - dx / view.zoom, drag.c.y - dy / view.zoom);
  cam.target = { key: 'free', ...view.center() }; cam.userZoom = true;
});
window.addEventListener('pointerup', () => { drag = null; canvas.style.cursor = ''; });
canvas.addEventListener('click', (ev) => { if (dragged) { dragged = false; return; } const e = hitAt(ev); if (e) select(e); });

// 직원을 누르면 따라가며 확대(전체나 넓게였으면 보통 단계로), Esc나 ×면 처음 화면(기본 단계, 사무실 가운데)으로
function select(e, keepMode) {
  view.selected = e;
  $('info').hidden = !e;
  if (e) {
    paintIdCard(e); setMode('follow');
    if (zoomedOut()) setZoom(ZOOM_100, e);
  } else if (!keepMode) { cam.userZoom = false; home(); }
  renderInfo();
  drawIdLines(); // 글이 바뀐 뒤 크기를 재서 그린다 (크기가 같아도 직원마다 선 모양이 다르니)
}
$('info-close').onclick = () => select(null);

// 사원증 꾸미기: 사진 칸 얼굴(원본 도트 1배), 위 가운데 표식(팀 소품 도트 2배), 팀 색 진행 막대, 사진 칸 바탕 = 구역 바닥색
function paintIdCard(e) {
  // 사진 칸 60x70에 그 직원 캐릭터를 원본 1배로 (머리 위 4칸 여백, 몸 가운데). 큰 그림은 아래가 잘린다
  const av = $('info-avatar');
  paintAvatar(av, e.team, baseKeyOf(e), 1, { w: 60, h: 70, face: 28 });
  Object.assign(av.style, { width: '60px', height: '70px' });
  const mark = $('info-mark'), has = paintGear(mark, e.team, baseKeyOf(e));
  mark.hidden = !has;
  const t = TEAMS[e.team] || {};
  $('info').style.setProperty('--team', t.tint || '#C9B9A6');
  $('info').style.setProperty('--floor', t.floor || '#F3EEE7');
}

// ---------- 사원증 손그림 선 ----------
// 카드 크기를 재서 실제 픽셀 좌표로 경로를 만든다: 늘어나도 선 굵기는 그대로. 흔들림은 1~2px의 부드러운 곡선
// (닫힌 도형은 둘레를 한 바퀴 도는 사인 두 개를 더해 법선 방향으로 밀고, Catmull-Rom 곡선으로 잇는다. 도트 계단 없음).
// 모양은 직원 id로 고정해 매 프레임 흔들리지 않는다.
function seeded(str) {
  let h = 2166136261;
  for (const ch of str) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  return () => { h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16; return (h >>> 0) / 4294967296; };
}
const f2 = (v) => Math.round(v * 100) / 100;
function curve(pts, closed) { // Catmull-Rom -> 3차 베지어
  const n = pts.length, at = (i) => (closed ? pts[(i + n) % n] : pts[Math.max(0, Math.min(n - 1, i))]);
  let d = `M${f2(pts[0][0])} ${f2(pts[0][1])}`;
  for (let i = 0; i < (closed ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    d += `C${f2(p1[0] + (p2[0] - p0[0]) / 6)} ${f2(p1[1] + (p2[1] - p0[1]) / 6)} ${f2(p2[0] - (p3[0] - p1[0]) / 6)} ${f2(p2[1] - (p3[1] - p1[1]) / 6)} ${f2(p2[0])} ${f2(p2[1])}`;
  }
  return closed ? d + 'Z' : d;
}
function wobblyRect(x, y, w, h, r, amp, rnd) {
  const L = 2 * (w - 2 * r) + 2 * (h - 2 * r) + 2 * Math.PI * r, n = Math.max(24, Math.round(L / 9));
  const k1 = 2 + Math.floor(rnd() * 2), k2 = 5 + Math.floor(rnd() * 3), p1 = rnd() * 6.283, p2 = rnd() * 6.283;
  const segs = [ // [길이, (u) => [x, y, 법선x, 법선y]]
    [w - 2 * r, (u) => [x + r + u, y, 0, -1]],
    [Math.PI * r / 2, (u) => { const a = -Math.PI / 2 + u / r; return [x + w - r + r * Math.cos(a), y + r + r * Math.sin(a), Math.cos(a), Math.sin(a)]; }],
    [h - 2 * r, (u) => [x + w, y + r + u, 1, 0]],
    [Math.PI * r / 2, (u) => { const a = u / r; return [x + w - r + r * Math.cos(a), y + h - r + r * Math.sin(a), Math.cos(a), Math.sin(a)]; }],
    [w - 2 * r, (u) => [x + w - r - u, y + h, 0, 1]],
    [Math.PI * r / 2, (u) => { const a = Math.PI / 2 + u / r; return [x + r + r * Math.cos(a), y + h - r + r * Math.sin(a), Math.cos(a), Math.sin(a)]; }],
    [h - 2 * r, (u) => [x, y + h - r - u, -1, 0]],
    [Math.PI * r / 2, (u) => { const a = Math.PI + u / r; return [x + r + r * Math.cos(a), y + r + r * Math.sin(a), Math.cos(a), Math.sin(a)]; }],
  ];
  const pts = [];
  for (let i = 0; i < n; i++) {
    let s = (i / n) * L, k = 0;
    while (k < segs.length - 1 && s > segs[k][0]) { s -= segs[k][0]; k++; }
    const [px, py, nx, ny] = segs[k][1](s), t = i / n;
    const dd = amp * (0.65 * Math.sin(6.2832 * k1 * t + p1) + 0.35 * Math.sin(6.2832 * k2 * t + p2));
    pts.push([px + nx * dd, py + ny * dd]);
  }
  return curve(pts, true);
}
function wobblyLine(x1, y1, x2, y2, amp, rnd) { // 끝점은 그대로, 가운데가 살짝 부푼 손그림 직선
  const len = Math.hypot(x2 - x1, y2 - y1), n = Math.max(2, Math.round(len / 12)), nx = -(y2 - y1) / len, ny = (x2 - x1) / len;
  const sg = rnd() < 0.5 ? -1 : 1, p = rnd() * 6.283, pts = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n, dd = amp * (sg * Math.sin(Math.PI * t) + 0.3 * Math.sin(2 * Math.PI * 2 * t + p) * Math.sin(Math.PI * t));
    pts.push([x1 + (x2 - x1) * t + nx * dd, y1 + (y2 - y1) * t + ny * dd]);
  }
  return curve(pts, false);
}
function drawIdLines() {
  const e = view.selected, card = document.querySelector('#info .idc');
  if (!e || !card || !card.clientWidth) return;
  const W = card.clientWidth, H = card.clientHeight, rnd = seeded(e.id), cb = card.getBoundingClientRect();
  const rel = (el) => { const r = el.getBoundingClientRect(); return { x: r.left - cb.left, y: r.top - cb.top, w: r.width, h: r.height }; };
  // 뒤: 흰 바탕을 겸한 바깥선(4px), 안쪽선(2px)
  $('info-back').innerHTML = `<path class="fill" d="${wobblyRect(3, 3, W - 6, H - 6, 13, 1.6, rnd)}"/>`
    + `<path class="ln" stroke-width="2" d="${wobblyRect(10, 10, W - 20, H - 20, 8, 1, rnd)}"/>`;
  // 앞: 사진 틀(살짝 삐뚤), 틀 왼쪽에 닿는 기울어진 구분선, 틀 오른쪽 짧은 꼬리
  const slot = $('info-avatar').parentElement, ph = rel(slot), j = () => (rnd() - 0.5) * 2.4;
  const c = [[ph.x + 1 + j(), ph.y + 1 + j()], [ph.x + ph.w - 1 + j(), ph.y + 1 + j()], [ph.x + ph.w - 1 + j(), ph.y + ph.h - 1 + j()], [ph.x + 1 + j(), ph.y + ph.h - 1 + j()]];
  const side = (a, b) => { const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, len = Math.hypot(b[0] - a[0], b[1] - a[1]), o = (rnd() - 0.5) * 1.4; return `Q${f2(mx - (b[1] - a[1]) / len * o)} ${f2(my + (b[0] - a[0]) / len * o)} ${f2(b[0])} ${f2(b[1])}`; };
  const frame = `M${f2(c[0][0])} ${f2(c[0][1])}${side(c[0], c[1])}${side(c[1], c[2])}${side(c[2], c[3])}${side(c[3], c[0])}Z`;
  const xAt = (a, b, y) => a[0] + (b[0] - a[0]) * ((y - a[1]) / (b[1] - a[1]));
  const rule = rel(document.querySelector('#info .idc-rule')), ry = rule.y + rule.h / 2, tilt = (rnd() < 0.5 ? -1 : 1) * (0.8 + rnd() * 0.7);
  const yl = ry + tilt, yr = ry - tilt, ty = yr + (rnd() - 0.5);
  $('info-front').innerHTML = `<path class="ln" stroke-width="2" d="${wobblyLine(10, yl, xAt(c[0], c[3], yr), yr, 0.8, rnd)}"/>`
    + `<path class="ln" stroke-width="2" d="${wobblyLine(xAt(c[1], c[2], ty), ty, W - 10, ty + (rnd() - 0.5), 0.3, rnd)}"/>`
    + `<path class="ln" stroke-width="2" d="${frame}"/>`
    + (!$('info-bar').hidden ? (() => { const g = rel($('info-bar')); return `<path class="ln" stroke-width="2" d="${wobblyRect(g.x + 1, g.y + 1, g.w - 2, g.h - 2, 5, 0.6, rnd)}"/>`; })() : '');
  slot.style.clipPath = `polygon(${c.map(([x, y]) => `${f2(x - ph.x)}px ${f2(y - ph.y)}px`).join(', ')})`;
}
new ResizeObserver(drawIdLines).observe(document.querySelector('#info .idc'));

// 손그림 상자 (사원증과 같은 선): host 맨 앞에 SVG 한 장을 깔아 바탕과 선을 그린다. 크기가 바뀌면 다시 그림.
// o = { w: 바깥선 굵기, r: 모서리, fill, stroke, amp: 흔들림, inner: 안쪽선 거리(없으면 생략), ring: 바깥에 한 줄 더 (색), seed }
const handOpt = new WeakMap();
const handRO = new ResizeObserver((ents) => ents.forEach((en) => paintHand(en.target)));
function handBox(host, o) {
  let svg = host.querySelector(':scope > svg.hand');
  if (!svg) { svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'hand'); svg.setAttribute('aria-hidden', 'true'); host.prepend(svg); }
  host.classList.add('hand-host');
  handOpt.set(host, o); handRO.observe(host); paintHand(host);
}
function paintHand(host) {
  const o = handOpt.get(host), svg = host.querySelector(':scope > svg.hand'), W = host.clientWidth, H = host.clientHeight;
  if (!o || !svg || !W) return;
  const rnd = seeded(o.seed), h = o.w / 2 + 1;
  let d = `<path style="fill:${o.fill};stroke:${o.stroke};stroke-width:${o.w};stroke-linejoin:round" d="${wobblyRect(h, h, W - 2 * h, H - 2 * h, o.r, o.amp ?? 1.3, rnd)}"/>`;
  if (o.inner) d += `<path style="fill:none;stroke:${o.stroke};stroke-width:2;stroke-linejoin:round" d="${wobblyRect(o.inner + 1, o.inner + 1, W - 2 * o.inner - 2, H - 2 * o.inner - 2, Math.max(4, o.r - 5), 0.9, rnd)}"/>`;
  if (o.ring) d += `<path style="fill:none;stroke:${o.ring};stroke-width:2;stroke-linejoin:round" d="${wobblyRect(h - o.w / 2 - 1, h - o.w / 2 - 1, W - 2 * h + o.w + 2, H - 2 * h + o.w + 2, o.r + 2, o.amp ?? 1.3, rnd)}"/>`;
  svg.innerHTML = d;
}
const PAPER = { stroke: '#D9607A', ring: '#F7C9D4' }; // 분홍 손그림 선
handBox($('approvals'), { ...PAPER, w: 4, r: 13, inner: 9, fill: '#FFFDF9', seed: 'approvals' });
handBox(document.querySelector('.topbar'), { ...PAPER, w: 3, r: 22, amp: 1.1, fill: '#FFFDF9', seed: 'topbar' });   // 위 시계 띠
handBox(document.querySelector('.bar-main'), { ...PAPER, w: 3, r: 22, amp: 1.1, fill: '#FFFDF9', seed: 'bar-main' }); // 아래 조작 바
handBox($('dialog'), { ...PAPER, w: 3, r: 12, amp: 0.9, fill: '#FFFDF9', seed: 'assistant-dialog' });          // 비서 대사 창 (종이)
handBox(document.querySelector('.mini'), { ...PAPER, w: 3, r: 10, amp: 0.7, fill: '#FFFDF9', seed: 'minimap' });   // 미니맵 (종이)
handBox($('zoom-pop'), { ...PAPER, w: 3, r: 10, amp: 0.7, fill: '#FFFDF9', seed: 'zoom-pop' });       // 배율 목록 (종이)
// 아래 바 버튼도 손그림 동그라미 (켜진 버튼 색은 style.css가 채움)
document.querySelectorAll('.bar-main button').forEach((b) => { for (const n of [...b.childNodes]) if (n.nodeType === 3 && n.textContent.trim()) { const sp = document.createElement('span'); sp.textContent = n.textContent; n.replaceWith(sp); } }); // 글자가 손그림 위로 오게
document.querySelectorAll('.bar-main button').forEach((b, i) => handBox(b, { stroke: '#D9607A', w: 2, r: 14, amp: 0.5, fill: b.classList.contains('desk-btn') ? '#E85A6B' : '#FFF6F8', seed: `btn${i}` }));

const GAUGE_N = 10, gaugeCells = $('info-fill');
gaugeCells.innerHTML = '<i></i>'.repeat(GAUGE_N);
function renderInfo() {
  const e = view.selected;
  if (!e) return;
  $('info-name').textContent = e.name;
  $('info-team').textContent = TEAMS[e.team].name;
  $('info-late').hidden = !(e.task && e.task.delayed);
  $('info-desc').textContent = e.id === 'ceo' ? '대표실에서 결재하는 중이에요.' : office.describe(e);
  $('info-desc').hidden = !$('info-desc').textContent;
  $('info-bar').hidden = !e.task || e.task.live; // 실제 작업은 진행률을 모르니 게이지를 숨긴다
  if (e.task) { // 진행 게이지: 10칸이 하나씩 찬다
    const k = Math.min(GAUGE_N, Math.floor((e.task.progress / e.task.actual) * GAUGE_N));
    [...gaugeCells.children].forEach((c, i) => c.classList.toggle('on', i < k));
  }
}

// ---------- 일시정지, 속도 ----------
const PAUSE_ICON = '<path d="M4 3h3v10H4zM9 3h3v10H9z"/>'; // 도트 아이콘 (16칸 격자, 칸 단위 사각형만)
const PLAY_ICON = '<path d="M4 3h2v10H4zM6 4h2v8H6zM8 5h2v6H8zM10 6h2v4h-2zM12 7h1v2h-1z"/>';
function setPaused(p) {
  paused = p;
  $('ic-pause').innerHTML = p ? PLAY_ICON : PAUSE_ICON;
  $('btn-pause').title = p ? '다시 재생 (스페이스바)' : '일시정지 (스페이스바)';
}
$('btn-pause').onclick = () => setPaused(!paused);
// ---------- 직원 목록 (팀별) + 산책 보내기 ----------
const STATE_TXT = { off: '퇴근', walk: '이동 중', work: '근무 중', idle: '잠깐 쉬는 중', break: '휴식', meet: '회의 중', report: '보고 중' };
function renderStaff() {
  const zones = [...new Set(office.staff.filter((e) => e.id !== 'assistant').map((e) => e.team))];
  const j = office.byId.assistant;
  const row = (e, role, canWalk) => `<div class="staff-row"><div class="staff-who"><b>${e.name}</b><span>${role}</span></div>` +
    `<em class="staff-st" data-st="${e.id}">${e.stroll ? '산책 중' : (e.live ? '실제 작업 중' : STATE_TXT[e.state] || e.state)}</em>` +
    `<button data-see="${e.id}">보기</button>${e.stroll ? `<button data-back="${e.id}" class="back" ${e.strollPhase === 'back' ? 'disabled' : ''}>${e.strollPhase === 'back' ? '돌아오는 중' : '복귀'}</button>` : `<button data-walk="${e.id}" ${e.state === 'off' ? 'disabled' : ''}>산책</button>`}` + '</div>';
  const head = `<section class="desk-team"><h4><i class="staff-dot" style="background:${(TEAMS.ceo || {}).tint || '#F2C14E'}"></i>대표실 <small>2명</small></h4>` +
    row(office.ceo, '결정·승인 (대표님)', true) + (j ? row(j, '팀에 일 나누기, 보고 모아 브리핑, 일정·루틴 챙기기', true) : '') + '</section>';
  $('staff-body').innerHTML = head + zones.map((z) => {
    const people = office.staff.filter((e) => e.team === z && e.id !== 'assistant');
    return `<section class="desk-team"><h4><i class="staff-dot" style="background:${(TEAMS[z] || {}).tint || '#ccc'}"></i>${TEAMS[z] ? TEAMS[z].name : z} <small>${people.length}명</small></h4>` +
      people.map((e) => row(e, e.role || '', true)).join('') + '</section>';
  }).join('');
  $('staff-body').querySelectorAll('[data-see]').forEach((b) => { b.onclick = () => { const e = b.dataset.see === 'ceo' ? office.ceo : office.byId[b.dataset.see]; if (e) select(e); }; });
  const who = (id) => (id === 'ceo' ? office.ceo : office.byId[id]);
  $('staff-body').querySelectorAll('[data-back]').forEach((b) => { b.onclick = () => { if (office.recallStroll(who(b.dataset.back))) renderStaff(); }; });
  $('staff-body').querySelectorAll('[data-walk]').forEach((b) => { b.onclick = () => { const e = who(b.dataset.walk); /* 1분 안에 누른 사람끼리 같이 간다 (sim.js) */ if (e && office.startStroll(e)) { select(e); renderStaff(); pumpDialog(performance.now()); } else if (e) { office.say('assistant', `${e.name} 님은 지금 ${e.state === 'report' ? '보고 중' : e.state === 'off' ? '퇴근했' : '바빠서 산책을 못 나가'}어요.`); pumpDialog(performance.now()); } }; });
}
$('btn-staff').onclick = () => { const p = $('staff-panel'); p.hidden = !p.hidden; $('btn-staff').classList.toggle('on', !p.hidden); if (!p.hidden) renderStaff(); };
$('staff-x').onclick = () => { $('staff-panel').hidden = true; $('btn-staff').classList.remove('on'); };
let staffSig = '';
setInterval(() => { // 상태가 바뀐 사람이 있을 때만 다시 그린다 (누르는 중에 버튼이 사라지지 않게)
  if ($('staff-panel').hidden) return;
  const all = [office.ceo, ...office.staff];
  const sig = all.map((e) => `${e.state === 'off' ? 0 : 1}${e.stroll ? 1 : 0}${e.strollPhase === 'back' ? 1 : 0}`).join(); // 버튼이 바뀔 때만 다시 그림
  if (sig !== staffSig) { staffSig = sig; renderStaff(); return; }
  all.forEach((e) => { const el = $('staff-body').querySelector(`[data-st="${e.id}"]`); if (el) el.textContent = e.stroll ? '산책 중' : (e.live ? '실제 작업 중' : STATE_TXT[e.state] || e.state); });
}, 1000);

// 출근 / 퇴근: 화면 직원들만 (근무 시간 기록은 focus.js)
$('btn-in').onclick = () => {
  setPaused(false);
  if (office.clock >= 18 * 60) office.fastForward(24 * 60); // 퇴근한 뒤 다시 출근하면 사무실도 새 아침으로 (날이 바뀌면 멈춤)
};
$('btn-out').onclick = () => {
  if (office.clock < 18 * 60) office.fastForward(18 * 60);
};
document.querySelectorAll('.seg button').forEach((b) => {
  b.onclick = () => {
    speed = Number(b.dataset.speed);
    document.querySelectorAll('.seg button').forEach((x) => x.classList.toggle('on', x === b));
  };
});

// ---------- 비서 대사 창 ----------
paintAvatar($('dlg-avatar'), 'sec', baseKeyOf({ id: 'assistant', team: 'sec' }), 2, { w: 35, h: 45, padTop: 5, side: 1 }); // 비서 얼굴 (1/2판)
let shown = office.log.length - 1, dlgUntil = 0;
function showDialog(text) {
  $('dlg-text').textContent = text;
  $('dialog').hidden = false; $('dialog').classList.remove('fade');
  dlgUntil = performance.now() + Math.max(5000, text.length * 120);
}
function pumpDialog(now) {
  while (shown < office.log.length - 1) {
    const m = office.log[++shown];
    if (m.from === 'assistant') showDialog(m.text);
  }
  if (!$('dialog').hidden && now > dlgUntil) {
    $('dialog').classList.add('fade');
    if (now > dlgUntil + 300) $('dialog').hidden = true;
  }
}
if (office.log.length) showDialog(office.log.at(-1).text);
document.querySelectorAll('[data-cmd]').forEach((b) => { b.onclick = () => { office.command(b.dataset.cmd); pumpDialog(performance.now()); if (b.dataset.cmd === 'show' && office.show) lookAtStage(); }; });
// 공연 버튼: 공연이 열리면(이미 열려 있어도) 카메라를 무대로. 맞춤 보기에서 무대가 화면 밖이면 100%로 (넓은 화면의 맞춤은 카메라가 고정이라)
function lookAtStage() {
  const at = { x: STAGE.x, y: STAGE.floor.y + 24 };
  if (view.selected) select(null, true);
  setMode('free'); cam.target = { key: 'free', ...at };
  const top = view.toDev(0, STAGE.backdrop.y)[1] / view.dpr;
  if (zoomedOut() || top < 0) { cam.userZoom = true; setZoom(ZOOM_100, at); }
}
$('dialog').onclick = () => { $('dialog').hidden = true; };

// ---------- 결재 창 (최근 3건) ----------
const SHOW_CARDS = 3;
let cardSig = '';
$('btn-apv').onclick = () => { $('approvals').hidden = !$('approvals').hidden; cardSig = ''; renderCards(); };
function renderCards() {
  const n = office.cards.length;
  $('card-count').textContent = n;
  $('card-count').classList.toggle('has', n > 0);
  if ($('approvals').hidden) return;
  const recent = office.cards.slice(-SHOW_CARDS).reverse();
  const sig = recent.map((c) => c.id).join(',') + '|' + n;
  if (sig === cardSig) return;
  cardSig = sig;
  $('apv-sub').textContent = n ? `대기 ${n}건` : '';
  $('cards-more').hidden = n <= SHOW_CARDS;
  $('cards-more').textContent = `이전 보고 ${n - SHOW_CARDS}건 더 있어요`;
  const box = $('cards');
  for (const old of box.children) handRO.unobserve(old);
  box.textContent = '';
  if (!n) { box.innerHTML = '<p class="empty">결재할 보고가 아직 없어요.</p>'; return; }
  for (const c of recent) {
    const e = office.byId[c.emp];
    const el = document.createElement('div');
    el.className = 'apv';
    el.innerHTML = '<div class="apv-who"><i class="dot"></i><span></span></div><div class="apv-title"></div><button>승인</button>';
    el.querySelector('.dot').style.background = TEAMS[e.team].tint;
    el.querySelector('.apv-who span').textContent = c.live && c.at ? `${TEAMS[e.team].name} ${e.name}  ${realHhmm(c.at)} 완료` : `${TEAMS[e.team].name} ${e.name}  ${hhmm(c.time)} 보고`;
    if (c.live) { el.classList.add('live'); el.querySelector('button').textContent = '확인'; } // 실제 보고는 확인만 (화면 안에서만 지운다, 아무 데도 쓰지 않음)
    el.querySelector('.apv-title').textContent = c.title;
    el.querySelector('button').onclick = () => {
      office.approve(c.id);
      if (cam.mode === 'tour' && e.state !== 'off') { cam.target = { key: e.id, person: e }; cam.lastKey = e.id; cam.until = performance.now() + TOUR_MS; }
      tick();
    };
    box.append(el);
    handBox(el, { ...PAPER, w: 2, r: 6, amp: 0.8, fill: '#FBF5EA', seed: 'card' + c.id }); // 서류 한 장
  }
}

// ---------- HUD 갱신 ----------
function tick() {
  const k = office.counts();
  $('clock-time').textContent = hhmm(office.clock);
  $('clock-day').textContent = `${office.day}일차`;
  $('phase').textContent = paused ? '일시정지' : office.phase();
  $('c-present').textContent = k.present;
  $('c-done').textContent = k.done;
  $('live-chip').hidden = k.live === null;
  if (k.live !== null) $('c-live').textContent = k.live;
  renderCards(); renderInfo();
}

// ---------- 회사 이름, 빈 상태, 알림 ----------
$('brand').textContent = COMPANY;
$('dlg-name').textContent = ASSISTANT;
if (!CHARACTERS.length) { // 캐릭터 그림이 하나도 없으면 사무실만 보이고 안내 창을 띄운다 (시간도 멈춘다)
  $('empty').hidden = false;
  paused = true; $('dialog').hidden = true; office.log.length = 0; shown = -1;
  const n = office.staff.length;
  $('empty-staff').textContent = window.AIO_CONFIG.sample
    ? `에이전트를 아직 못 찾아서 예시 직원 ${n - 1}명으로 준비해 뒀어요.`
    : `직원 ${n - 1}명과 ${ASSISTANT}가 캐릭터를 기다리고 있어요.`;
}
if (NOTICES.length) {
  const box = $('notices');
  box.hidden = false;
  box.innerHTML = '<b>확인해 주세요</b><ul></ul><button class="x" title="닫기">×</button>';
  for (const t of NOTICES.slice(0, 6)) { const li = document.createElement('li'); li.textContent = t; box.querySelector('ul').append(li); }
  box.querySelector('button').onclick = () => { box.hidden = true; };
}

// ---------- 루프 ----------
setPaused(paused);
home(); ready = true;
let last = performance.now(), uiAt = 0;
function frame(now) {
  const dtReal = Math.min(0.1, (now - last) / 1000);
  last = now;
  if (!paused) {
    let sim = dtReal * speed;
    while (sim > 0) { const d = Math.min(0.25, sim); office.step(d); sim -= d; }
  }
  if (cam.mode === 'tour' && now > cam.until) nextTour(now);
  if (cam.mode === 'free' && held.size && cam.target) {
    const v = 260 * dtReal;
    if (held.has('ArrowLeft')) cam.target.x -= v;
    if (held.has('ArrowRight')) cam.target.x += v;
    if (held.has('ArrowUp')) cam.target.y -= v;
    if (held.has('ArrowDown')) cam.target.y += v;
    cam.target.x = Math.max(0, Math.min(WORLD.w, cam.target.x));
    cam.target.y = Math.max(STAGE.top, Math.min(WORLD.h, cam.target.y)); // 위로 공연 무대까지
  }
  if (cam.mode === 'free' && cam.target && view.level !== 'all') { // 카메라가 갈 수 없는 곳에 목표가 남지 않게 (방향키가 바로 먹히도록)
    const c0 = view.center(); view.setCenter(cam.target.x, cam.target.y); const c1 = view.center(); view.setCenter(c0.x, c0.y);
    cam.target.x = c1.x; cam.target.y = c1.y;
  }
  if (view.level !== 'all') {
    const p = targetPoint(), c = view.center(), k = 1 - Math.exp(-dtReal * 2.6);
    view.setCenter(c.x + (p.x - c.x) * k, c.y + (p.y - c.y) * k);
  }
  view.draw(office, now);
  drawLiveMarks(view, office, now); // 실제 작업 표시 (연결 중에만)
  drawMinimap(mini, office, view);
  pumpDialog(now);
  if (now - uiAt > 200) { uiAt = now; tick(); }
  requestAnimationFrame(frame);
}
tick();
requestAnimationFrame(frame);
window.__aio = { office, view, cam, setMode, setLevel, setZoom, select, live }; // 확인용
