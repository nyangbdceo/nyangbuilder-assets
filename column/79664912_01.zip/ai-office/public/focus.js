// 집중 도구: 오늘 근무 시간(출근~퇴근, 휴식은 빼고), 뽀모도로 타이머, 집중 음악(브라우저에서 바로 만드는 소리, 파일·저작권 없음).
// 근무 기록은 이 브라우저(localStorage)에만 날짜별로 남는다.
const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, '0');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* 저장 못 해도 화면은 동작 */ } };

// ---------- 화면 붙이기 ----------
$('clock-time').hidden = true; $('clock-day').hidden = true; // 시뮬레이션 시계 대신 실제 근무 시간
$('brand').insertAdjacentHTML('afterend', `
  <span class="work-st" id="work-st">퇴근</span>
  <span class="work-time" id="work-time" title="오늘 근무 시간 (휴식 제외)">0:00</span>
  <button class="focus-btn" id="pomo" title="뽀모도로: 누르면 시작/멈춤">🍅 25:00</button>
  <button class="focus-btn small" id="pomo-reset" title="뽀모도로 처음으로">↺</button>
  <button class="focus-btn" id="music" title="누를 때마다 다음 소리: 카페 재즈, 빗소리+장작, 시골 빗소리, 장작">♪ 소리 끔</button>`);

// ---------- 근무 시간 ----------
const KEY = () => `work-${today()}`;
// acc = 이번 출근부터 일한 시간(휴식 제외), total = 오늘 앞서 퇴근한 근무들의 합. 퇴근 후 다시 출근하면 acc는 0부터.
const EMPTY = { state: 'off', acc: 0, since: 0, total: 0 };
let W = { ...EMPTY, ...load(KEY(), EMPTY) };
const worked = () => W.acc + (W.state === 'work' ? Date.now() - W.since : 0);
const hms = (ms) => { const t = Math.floor(ms / 1000); return `${Math.floor(t / 3600)}:${pad(Math.floor(t / 60) % 60)}:${pad(t % 60)}`; };
function setState(next) {
  const now = Date.now();
  if (W.state === 'work') W = { ...W, acc: W.acc + now - W.since };
  if (next === 'off') W = { ...W, total: W.total + W.acc };                 // 퇴근: 이번 근무를 오늘 합계에 더함
  if (next === 'work' && W.state === 'off') W = { ...W, acc: 0 };           // 퇴근 뒤 출근: 새로 0부터
  W = { ...W, state: next, since: now };
  save(KEY(), W); paintWork();
}
function paintWork() {
  const showing = W.state === 'off' ? 0 : worked(), day = W.total + (W.state === 'off' ? 0 : worked());
  $('work-time').textContent = hms(W.state === 'off' && W.total ? W.total : showing);
  $('work-time').title = W.state === 'off' && W.total ? `오늘 근무 합계 ${hms(W.total)}` : `이번 근무 ${hms(showing)} · 오늘 합계 ${hms(day)} (휴식 제외)`;
  $('work-st').textContent = { work: '근무 중', rest: '휴식 중', off: W.total ? '오늘 합계' : '출근 전' }[W.state];
  $('work-st').dataset.s = W.state;
  $('rest-lbl').textContent = W.state === 'rest' ? '휴식 끝' : '휴식';
  $('btn-rest').classList.toggle('on', W.state === 'rest');
}
$('btn-in').addEventListener('click', () => { if (W.state !== 'work') setState('work'); });
$('btn-out').addEventListener('click', () => { if (W.state !== 'off') setState('off'); stopPomo(); });
$('btn-rest').addEventListener('click', () => setState(W.state === 'rest' ? 'work' : 'rest'));
let day = today();
setInterval(() => { if (today() !== day) { day = today(); W = { ...EMPTY, ...load(KEY(), EMPTY) }; } paintWork(); }, 1000); // 1초마다, 자정이 지나면 새 날 기록
paintWork();

// ---------- 소리 ----------
let ctx = null, master = null;
function audio() {
  if (!ctx) { ctx = new AudioContext(); master = ctx.createGain(); master.gain.value = 0.22; master.connect(ctx.destination); }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}
function chime() { // 타이머 끝: 맑은 종소리 세 번
  const c = audio();
  [0, 0.25, 0.5].forEach((t, i) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = [880, 1175, 1568][i];
    g.gain.setValueAtTime(0.0001, c.currentTime + t); g.gain.exponentialRampToValueAtTime(0.5, c.currentTime + t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t + 1.2);
    o.connect(g).connect(c.destination); o.start(c.currentTime + t); o.stop(c.currentTime + t + 1.3);
  });
}

// ---------- 뽀모도로 (집중/쉬기 분은 고를 수 있고 이 브라우저에 기억) ----------
// 위 띠의 🍅 버튼 = 남은 시간. 누르면 왼쪽 위에 큰 타이머 카드가 열린다(시작/멈춤, 처음으로, 분 설정, 진행 막대).
const MIN = load('pomo-min', { focus: 25, break: 5 });
const LEN = () => ({ focus: MIN.focus * 60, break: MIN.break * 60 });
let P = { mode: 'focus', left: LEN().focus, running: false, timer: 0 };
$('pomo-reset').remove(); // 처음으로는 카드 안에
document.body.insertAdjacentHTML('beforeend', `
  <div class="pomo-card" id="pomo-card" hidden>
    <div class="pomo-mode" id="pomo-mode">🍅 집중</div>
    <div class="pomo-big" id="pomo-big">25:00</div>
    <div class="pomo-bar"><i id="pomo-fill"></i></div>
    <div class="pomo-act"><button id="pomo-go">시작</button><button id="pomo-re" class="ghost">처음으로</button></div>
    <div class="pomo-set"><label>집중 <input id="pomo-f" type="number" min="1" max="120"> 분</label><label>쉬기 <input id="pomo-b" type="number" min="1" max="60"> 분</label></div>
    <button class="pomo-x" id="pomo-x" aria-label="닫기">×</button>
  </div>`);
$('pomo-f').value = MIN.focus; $('pomo-b').value = MIN.break;
function paintPomo() {
  const mmss = `${pad(Math.floor(P.left / 60))}:${pad(P.left % 60)}`, total = LEN()[P.mode];
  $('pomo').textContent = `${P.mode === 'focus' ? '🍅' : '☕'} ${mmss}`;
  $('pomo').classList.toggle('on', P.running);
  $('pomo-big').textContent = mmss;
  $('pomo-mode').textContent = P.mode === 'focus' ? '🍅 집중 시간' : '☕ 쉬는 시간';
  $('pomo-card').dataset.mode = P.mode;
  $('pomo-fill').style.width = `${100 - (P.left / total) * 100}%`;
  $('pomo-go').textContent = P.running ? '멈춤' : '시작';
  document.title = P.running ? `${mmss} ${P.mode === 'focus' ? '집중' : '쉬기'}` : 'AI 오피스';
}
function tick() {
  P.left -= 1;
  if (P.left <= 0) { chime(); P.mode = P.mode === 'focus' ? 'break' : 'focus'; P.left = LEN()[P.mode]; $('pomo-card').hidden = false; placeCard(); }
  paintPomo();
}
function stopPomo() { clearInterval(P.timer); P.running = false; paintPomo(); }
function toggle() {
  if (P.running) { stopPomo(); return; }
  audio(); P.running = true; P.timer = setInterval(tick, 1000); paintPomo();
  if (W.state !== 'work') setState('work');
}
function placeCard() { // 🍅 버튼 바로 아래 가운데에 붙인다
  const r = $('pomo').getBoundingClientRect(), c = $('pomo-card');
  c.style.left = Math.max(12, Math.min(innerWidth - 242, r.left + r.width / 2 - 115)) + 'px';
  c.style.top = (r.bottom + 14) + 'px';
  c.style.setProperty('--arrow', (r.left + r.width / 2 - parseFloat(c.style.left)) + 'px');
}
$('pomo').onclick = () => { $('pomo-card').hidden = !$('pomo-card').hidden; if (!$('pomo-card').hidden) placeCard(); };
addEventListener('resize', () => { if (!$('pomo-card').hidden) placeCard(); });
$('pomo-x').onclick = () => { $('pomo-card').hidden = true; };
$('pomo-go').onclick = toggle;
$('pomo-re').onclick = () => { stopPomo(); P.mode = 'focus'; P.left = LEN().focus; paintPomo(); };
for (const [id, k, max] of [['pomo-f', 'focus', 120], ['pomo-b', 'break', 60]]) {
  $(id).onchange = () => {
    const v = Math.max(1, Math.min(max, Math.round(Number($(id).value) || MIN[k])));
    $(id).value = v; MIN[k] = v; save('pomo-min', MIN);
    if (!P.running && P.mode === k) P.left = v * 60;
    paintPomo();
  };
}
paintPomo();

// ---------- 집중 소리: 카페 / 장작 타는 소리 (브라우저에서 만드는 소리) ----------
// 진짜 녹음은 유튜브 영상을 작은 플레이어로 틀고(파일 다운로드 없음), 장작은 브라우저가 만든 소리
const YT = { cafe: 'isROfGEioHw', lofi: 'jfKfPfyJRdk', rainfire: '5xqAPiafWVw', library: 'J0rb56Wegq4' };
const MODES = ['off', 'cafe', 'rainfire', 'library', 'fire'];
const LABEL = { off: '♪ 소리 끔', cafe: '☕ 카페 재즈', lofi: '🎧 로파이', rainfire: '🌧 빗소리+장작', library: '🌾 시골 빗소리', fire: '🔥 장작 (가벼운 소리)' };
document.body.insertAdjacentHTML('beforeend', '<div class="yt-mini" id="yt-mini" hidden><iframe id="yt-frame" title="집중 소리" allow="autoplay; encrypted-media" referrerpolicy="strict-origin-when-cross-origin"></iframe><button id="yt-x" aria-label="소리 끄기">×</button></div>');
function playYT(id) {
  const live = id === YT.lofi; // 라이브 방송은 반복(loop) 설정을 붙이면 재생이 막힌다
  $('yt-frame').src = id ? `https://www.youtube.com/embed/${id}?autoplay=1&controls=1&rel=0${live ? '' : `&loop=1&playlist=${id}`}` : 'about:blank';
  $('yt-mini').hidden = !id;
}
let mode = 'off', nodes = [], timers = [];
function noiseBuffer(c, brown) {
  const len = c.sampleRate * 6, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w; }
  return buf;
}
function loopNoise(c, brown, type, freq, q, gain, wobble = 0) {
  const s = c.createBufferSource(); s.buffer = noiseBuffer(c, brown); s.loop = true;
  const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
  const g = c.createGain(); g.gain.value = gain;
  s.connect(f).connect(g).connect(master); s.start(); nodes.push(s);
  if (wobble) { // 사람 말소리처럼 크기가 천천히 오르내림
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = wobble; lg.gain.value = gain * 0.45;
    lfo.connect(lg).connect(g.gain); lfo.start(); nodes.push(lfo);
  }
}
function burst(c, t, dur, freq, vol, type = 'highpass') { // 짧은 소리 한 번 (장작 탁, 컵 딸깍)
  const s = c.createBufferSource(), len = Math.max(1, Math.floor(c.sampleRate * dur)), buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
  s.buffer = buf;
  const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = 1.2;
  const g = c.createGain(); g.gain.value = vol;
  s.connect(f).connect(g).connect(master); s.start(t);
}
function clink(c, t) { // 잔이 부딪히는 소리
  const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = 2200 + Math.random() * 1600;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.05, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
  o.connect(g).connect(master); o.start(t); o.stop(t + 0.4);
}
function every(ms, fn) { const id = setInterval(fn, ms); timers.push(id); }
function cafe(c) {
  loopNoise(c, true, 'bandpass', 420, 0.8, 0.9, 0.23);   // 웅성웅성 말소리
  loopNoise(c, true, 'bandpass', 900, 1.1, 0.35, 0.37);
  loopNoise(c, false, 'lowpass', 300, 0.5, 0.05);         // 공간 울림
  every(700, () => { const t = c.currentTime; if (Math.random() < 0.35) clink(c, t + Math.random() * 0.5); if (Math.random() < 0.15) burst(c, t, 0.06, 1800, 0.12, 'bandpass'); });
  every(9000, () => { if (Math.random() < 0.5) burst(c, c.currentTime, 1.6, 600, 0.25, 'bandpass'); }); // 멀리서 커피 머신
}
function fire(c) {
  loopNoise(c, true, 'lowpass', 220, 0.7, 1.1, 0.12);    // 낮게 타오르는 소리
  loopNoise(c, false, 'bandpass', 2500, 0.6, 0.03, 0.5);  // 쉬익 하는 불꽃
  every(120, () => { // 탁탁 튀는 소리 (불규칙)
    const t = c.currentTime;
    if (Math.random() < 0.28) burst(c, t + Math.random() * 0.1, 0.012 + Math.random() * 0.03, 1500 + Math.random() * 3000, 0.25 + Math.random() * 0.5);
    if (Math.random() < 0.02) for (let k = 0; k < 4; k++) burst(c, t + k * 0.05 + Math.random() * 0.03, 0.02, 2500, 0.35);
  });
}
function setMusic(m) {
  nodes.forEach((n) => { try { n.stop(); } catch { /* 이미 멈춤 */ } }); nodes = []; timers.forEach(clearInterval); timers = [];
  mode = m; $('music').textContent = LABEL[m]; $('music').classList.toggle('on', m !== 'off');
  playYT(YT[m]);
  if (m === 'off' || YT[m]) return;
  const c = audio();
  if (m === 'cafe') cafe(c);
  if (m === 'fire') fire(c);
}
$('music').onclick = () => setMusic(MODES[(MODES.indexOf(mode) + 1) % MODES.length]);

$('yt-x').onclick = () => setMusic('off');
