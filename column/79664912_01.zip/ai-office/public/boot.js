// 시작: 회사 정보와 캐릭터 그림을 먼저 읽고 나서 화면(app.js)을 연다.
// 그림 PNG는 1px = 도트 1칸. 칸마다 색을 글자 하나로 바꿔 { w, h, rows, palette } 꼴로 window.AIO_SPRITES에 넣는다.
async function loadImage(url) {
  const img = new Image();
  img.src = url;
  await img.decode();
  return img;
}
function toDots(img) {
  const w = img.naturalWidth, h = img.naturalHeight;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(img, 0, 0);
  const d = g.getImageData(0, 0, w, h).data;
  const palette = {}, keyOf = new Map(), rows = [];
  for (let y = 0; y < h; y++) {
    let row = '';
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (d[i + 3] < 128) { row += '.'; continue; } // 반투명 아래는 투명
      const hex = '#' + [d[i], d[i + 1], d[i + 2]].map((v) => v.toString(16).padStart(2, '0')).join('');
      let k = keyOf.get(hex);
      if (!k) { k = String.fromCodePoint(0x4e00 + keyOf.size); keyOf.set(hex, k); palette[k] = hex; }
      row += k;
    }
    rows.push(row);
  }
  // 위아래 빈 줄을 잘라 발이 그림 맨 아래에 닿게 (가로는 그대로: 가운데 기준)
  let top = 0, bot = h - 1;
  while (top < h && !/[^.]/.test(rows[top])) top++;
  while (bot > top && !/[^.]/.test(rows[bot])) bot--;
  const cut = top <= bot ? rows.slice(top, bot + 1) : rows;
  return { w, h: cut.length, rows: cut, palette };
}

const res = await fetch('api/office', { cache: 'no-store' });
const cfg = await res.json();
const sprites = {}, notices = [...(cfg.notices || [])];
const ok = [];
for (const ch of cfg.characters || []) {
  try {
    for (const [pose, url] of Object.entries(ch.poses)) sprites[pose === 'front' ? ch.name : `${ch.name}_${pose}`] = toDots(await loadImage(url));
    ok.push(ch);
  } catch { notices.push(`"${ch.name}" 그림을 열지 못했어요.`); }
}
// 작은 그림은 정수배로 키운다: 키가 80칸 안팎이 되는 배수(최대 3배, 가로 100칸, 세로 110칸 안)
for (const ch of ok) {
  const s = sprites[ch.name];
  let k = Math.max(1, Math.min(3, Math.round(80 / s.h)));
  while (k > 1 && (s.w * k > 100 || s.h * k > 110)) k--;
  ch.scale = k;
}
window.AIO_SPRITES = sprites;
window.AIO_CONFIG = { ...cfg, characters: ok, notices };
document.title = cfg.company || 'AI 오피스';
await import('./app.js');
