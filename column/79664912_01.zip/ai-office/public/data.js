// 사무실 맵, 직원 명단, 업무 목록.
// 명단과 회사 이름은 서버가 office.config.json과 .claude/agents 폴더에서 만들어 window.AIO_CONFIG로 넘긴다 (boot.js).
// 이 파일의 맵 좌표는 바꾸지 않아도 된다. 팀은 최대 6개, 팀마다 자리 수가 정해져 있다(ZONE_CAP).
const CFG = (typeof window !== 'undefined' && window.AIO_CONFIG) || { company: 'AI 오피스', boss: '대표', assistant: '비서', teams: [], characters: [] };
export const WORLD = { w: 704, h: 384 };
export const WALL_Y = 366;                       // 아래 벽 (입구는 이 벽의 빈칸)
export const DOOR_GAP = { x0: 188, x1: 244 };     // 라운지 카페와 dev 구역 사이 로비
export const ENTRANCE = { x: 216, y: 378 };
export const CELL = 8;

// 팀 구역: tint = 미니맵 점과 결재 카드 점 색, floor = 러그 색. 이름은 설정 파일에서 온다.
// 구역 id(edu, cplan, ...)는 맵 자리 이름일 뿐이다. 설정의 팀이 큰 순서대로 자리가 넓은 구역에 들어간다.
export const TEAMS = {
  ceo:    { name: `${CFG.boss}실`,          tint: '#F2C14E', floor: '#F6E3E3' },
  sec:    { name: `${CFG.assistant} 데스크`, tint: '#6FA8E8', floor: '#E2EAF4' },
  edu:    { name: '', tint: '#58B98A', floor: '#E0F0E3' },
  cplan:  { name: '', tint: '#F28CA8', floor: '#F8E1E6' },
  cmake:  { name: '', tint: '#F2A35E', floor: '#F8E7D6' },
  ops:    { name: '', tint: '#E8B83E', floor: '#F6EDCF' },
  mkt:    { name: '', tint: '#4FB4D8', floor: '#DDEEF4' },
  dev:    { name: '', tint: '#9C86E8', floor: '#E9E3F5' },
  fin:    { name: '', tint: '#5FB98E', floor: '#E3F3EA' }, // 재무팀 (탕비실 왼쪽을 잘라 만든 자리)
  meeting:{ name: '회의실',      tint: null, floor: '#EEE7DD' },
  lounge: { name: '탕비실', tint: null, floor: '#EEE1CE' },
};
// 구역마다 앉을 수 있는 사람 수 (넓은 구역부터)
export const ZONE_CAP = { edu: 6, cplan: 6, cmake: 4, ops: 4, mkt: 4, fin: 3, dev: 2 };

// 오픈 오피스. 벽이 있는 방은 대표실과 회의실(유리벽) 둘뿐. 3줄 배치:
// 1줄 대표실(위쪽 벽 뒷문 = 공연 무대), 팀 구역 edu, cplan / 2줄 회의실, 팀 구역 cmake, ops, mkt / 3줄 라운지 카페, 입구 로비, 팀 구역 dev.
// 구역 폭은 책상 수로 정했다(책상 43이라 한 줄 3개면 폭 약 210, 2개면 약 156). 구역 소품은 둘째 줄 책상 양옆 빈자리에 둔다.
// 대표실 문은 오른쪽 아래, 회의실 문은 아래(라운지 카페 쪽).
const zone = (id, x, y, w, h, door) => ({ id, x, y, w, h, walled: !!door, door });
export const ROOMS = [ // 원본 좌우를 뒤집은 배치 (대표실·회의실 오른쪽, 탕비실 오른쪽 아래, 입구 왼쪽)
  zone('ceo', 480, 16, 212, 112, { side: 'bottom', x: 498 }),
  zone('edu', 246, 16, 226, 112),
  zone('cplan', 12, 16, 226, 112),
  zone('meeting', 510, 140, 182, 104, { side: 'bottom', x: 554 }),
  zone('cmake', 342, 140, 160, 104),
  zone('ops', 174, 140, 160, 104),
  zone('mkt', 12, 140, 154, 104),
  { ...zone('fin', 272, 256, 140, 106), noPass: true }, // 재무팀: 벽은 없고, 재무팀 직원이 아니면 가로질러 다니지 않는다 (sim.js findPath)
  zone('lounge', 420, 256, 272, 106),
  zone('dev', 12, 256, 148, 106),
];
export const roomById = Object.fromEntries(ROOMS.map((r) => [r.id, r]));

// 팀 자리: 한 명씩 따로 놓은 책상 2줄, 모두 화면 쪽을 본다. 줄마다 구역 폭을 고르게 나눠 놓는다(윗줄과 아랫줄이 엇갈림).
// 옆에 소품이 있는 구역은 그만큼 비워 두고 나눈다(SEAT_PAD = [왼쪽, 오른쪽]).
const SEAT_ROWS = { 2: [1, 1], 3: [2, 1], 4: [2, 2], 5: [3, 2] };
const SEAT_PAD = { dev: [40, 0] }; // dev 구역만 왼쪽 서버 랙 자리. 다른 구역 소품은 둘째 줄 책상 양옆
export function seatsFor(r, n) {
  const rows = SEAT_ROWS[n] || [Math.ceil(n / 2), Math.floor(n / 2)];
  const [pl, pr] = SEAT_PAD[r.id] || [0, 0], x0 = r.x + pl, span = r.w - pl - pr;
  const y1 = r.y + 42; // 첫 줄 발 자리 (머리 위 소품 자리 포함), 줄 간격 50
  const seats = [];
  rows.forEach((k, row) => { for (let i = 0; i < k; i++) seats.push({ x: Math.round(x0 + (span * (i + 1)) / (k + 1)), y: y1 + row * 50 }); });
  return seats;
}

const ceo = roomById.ceo, mt = roomById.meeting, lg = roomById.lounge;
export const CEO_SEAT = { x: ceo.x + 66, y: ceo.y + 40 };
// 비서 자리: 대표실 안 오른쪽, 문 바로 위. 보고 줄(대표 책상 앞 4곳)이 한눈에 보이고, 아침 브리핑은 대표 책상 오른쪽으로 몇 걸음
export const ASSIST_SEAT = { x: ceo.x + 180, y: ceo.y + 70 };
export const ASSIST_BRIEF = { x: CEO_SEAT.x + 50, y: CEO_SEAT.y + 22 };
// 보고 자리 4곳. 먼저 온 한 사람만 보고하고(말풍선), 나머지는 옆에서 기다린다("…" 표시). 4곳이 다 차면 자리에서 기다렸다 온다.
export const REPORT_SPOTS = [-42, -14, 14, 42].map((dx) => ({ x: CEO_SEAT.x + dx, y: ceo.y + 86 }));
export const MEETING_TABLE = { x: mt.x + mt.w / 2 - 52, y: mt.y + 40, w: 104, h: 24 };
const MEET_DX = [-34, 0, 34]; // 위아래 3석씩 + 양 끝 1석씩 = 8석
export const MEETING_SEATS = [
  ...MEET_DX.map((dx) => ({ x: mt.x + mt.w / 2 + dx, y: MEETING_TABLE.y + 9, side: 'far' })),
  ...MEET_DX.map((dx) => ({ x: mt.x + mt.w / 2 + dx, y: MEETING_TABLE.y + MEETING_TABLE.h + 26, side: 'near' })),
  { x: MEETING_TABLE.x - 16, y: MEETING_TABLE.y + MEETING_TABLE.h + 8, side: 'end' },
  { x: MEETING_TABLE.x + MEETING_TABLE.w + 16, y: MEETING_TABLE.y + MEETING_TABLE.h + 8, side: 'end' },
];
// 라운지 카페: 왼쪽 위 커피 코너와 정수기, 왼쪽 아래 소파, 가운데 러그 위 카페 테이블 셋, 오른쪽 자료 코너(책장, 프린터, 테이블)
export const COFFEE = { x: lg.x + 186, y: lg.y + 6 }; // 탕비실: 오른쪽 위 커피 코너+정수기, 오른쪽 아래 소파, 왼쪽 간식 선반·프린터·테이블
export const SOFA = { x: lg.x + 150, y: lg.y + 68, w: 112, h: 32 };
export const CAFE_TABLES = [{ x: lg.x + 40, y: lg.y + 52 }, { x: lg.x + 108, y: lg.y + 52 }];
export const BREAK_SPOTS = [
  { x: SOFA.x + 30, y: SOFA.y + 20, squish: true },
  { x: SOFA.x + 82, y: SOFA.y + 20, squish: true },
  { x: COFFEE.x + 18, y: COFFEE.y + 48 }, { x: COFFEE.x + 50, y: COFFEE.y + 48 },
  ...CAFE_TABLES.flatMap((t) => [{ x: t.x - 28, y: t.y + 8 }, { x: t.x + 28, y: t.y + 8 }]),
  { x: lg.x + 124, y: lg.y + 100 },
];

// 잠깐 다녀오는 곳 (자리에서 일하다 가끔 다녀온다): 정수기는 커피 코너 옆, 책장과 프린터는 라운지 카페 오른쪽 자료 코너, 화분은 입구 로비
export const WATER = { x: lg.x + 262, y: lg.y + 6 };
export const BOOKSHELF = { x: lg.x + 6, y: lg.y + 4, w: 72, h: 30 };
export const PRINTER = { x: lg.x + 84, y: lg.y + 10 };
export const COMMON_TABLE = { x: lg.x + 74, y: lg.y + 90 };
export const HALL_PLANTS = [DOOR_GAP.x0 - 16, DOOR_GAP.x1 + 16].map((x) => ({ x, y: lg.y + 40 }));
export const ERRANDS = {
  water: { x: WATER.x + 8, y: WATER.y + 48, line: ['물 한 잔', '목말라요'] },
  print: { x: PRINTER.x + 14, y: PRINTER.y + 44, line: ['출력 중', '프린터 어디 갔지'], back: true },
  books: { x: BOOKSHELF.x + 36, y: BOOKSHELF.y + 52, line: ['자료 찾는 중', '이 책 좋다'], back: true },
  plant: { spots: HALL_PLANTS.map((p) => ({ x: p.x, y: p.y + 24 })), line: ['물 줄게요', '잘 자라라'], back: true },
};
export const CHAT_SPOTS = [
  [{ x: COMMON_TABLE.x - 26, y: COMMON_TABLE.y + 8 }, { x: COMMON_TABLE.x + 26, y: COMMON_TABLE.y + 8 }],
  [{ x: lg.x + 134, y: lg.y + 30 }, { x: lg.x + 162, y: lg.y + 30 }],
  [{ x: DOOR_GAP.x0 + 12, y: lg.y + 24 }, { x: DOOR_GAP.x1 - 12, y: lg.y + 24 }], // 입구 안쪽 복도
];


// ---------- 직원 명단 (설정에서) ----------
// 팀이 큰 순서대로 넓은 구역에 넣는다. 자리가 모자라면 넘치는 사람은 빠지고 NOTICES에 남는다.
export const NOTICES = [...(CFG.notices || [])];
const zoneOrder = Object.keys(ZONE_CAP).sort((a, b) => ZONE_CAP[b] - ZONE_CAP[a]);
const teamList = (CFG.teams || []).filter((t) => t && Array.isArray(t.members) && t.members.length).map((t, i) => ({ ...t, i }));
const placed = [];
const wants = (t) => (t.zone && ZONE_CAP[t.zone] ? 1 : 0); // 자리를 지정한 팀이 먼저
for (const t of [...teamList].sort((a, b) => wants(b) - wants(a) || b.members.length - a.members.length || a.i - b.i)) {
  const z = wants(t) && !placed.some((p) => p.zone === t.zone) ? t.zone : zoneOrder.find((id) => !placed.some((p) => p.zone === id) && !teamList.some((o) => o !== t && o.zone === id));
  if (!z) { NOTICES.push(`팀이 6개를 넘어서 "${t.name}" 팀은 화면에 넣지 못했어요.`); continue; }
  const cap = ZONE_CAP[z];
  if (t.members.length > cap) NOTICES.push(`"${t.name}" 팀 자리가 ${cap}개라 ${t.members.length - cap}명은 빠졌어요.`);
  placed.push({ zone: z, name: t.name, members: t.members.slice(0, cap) });
}
for (const p of placed) TEAMS[p.zone].name = p.name;
// 아직 팀이 없는 구역도 팀 이름표를 단다 (쓰고 있는 이름은 건너뛴다)
const usedNames = new Set(placed.map((p) => p.name));
let spare = 1;
for (const id of zoneOrder) if (!TEAMS[id].name) {
  while (usedNames.has(`팀${spare}`)) spare++;
  usedNames.add(`팀${spare}`); TEAMS[id].name = `팀${spare}`;
}

export const STAFF = [
  { id: 'assistant', name: CFG.assistant, team: 'sec', lead: true, char: CFG.assistantCharacter || null },
  ...placed.flatMap((p) => p.members.map((m, i) => ({ id: m.id, name: m.name || m.id, role: m.role || '', team: p.zone, lead: i === 0, char: m.character || null }))),
];

// 지어낸 업무 (실제 작업 기록과 연결되지 않았을 때만 보인다). 설정의 tasks가 있으면 그걸 쓴다
const DEFAULT_TASKS = ['자료 정리하기', '초안 쓰기', '다시 검토하기', '메모 정리', '다음 할 일 정리'];
export const TASKS = Object.fromEntries(STAFF.map((s) => {
  const m = placed.flatMap((p) => p.members).find((x) => x.id === s.id);
  return [s.id, m && Array.isArray(m.tasks) && m.tasks.length ? m.tasks : DEFAULT_TASKS];
}));

// 캐릭터: characters 폴더의 그림 이름 목록 (boot.js가 그림을 읽어 window.AIO_SPRITES에 넣는다).
// 설정에서 정하지 않은 직원은 목록을 차례로 돌려 쓴다. 그림이 하나도 없으면 null (사람을 그리지 않는다)
export const CHARACTERS = (CFG.characters || []).map((c) => c.name);
const auto = {};
let turn = 0;
const pickChar = () => (CHARACTERS.length ? CHARACTERS[turn++ % CHARACTERS.length] : null);
auto.ceo = CFG.bossCharacter && CHARACTERS.includes(CFG.bossCharacter) ? CFG.bossCharacter : pickChar();
for (const s of STAFF) auto[s.id] = s.char && CHARACTERS.includes(s.char) ? s.char : pickChar();
export const charOf = (e) => e.char && CHARACTERS.includes(e.char) ? e.char : (auto[e.id] ?? null);
export const CHAR_SCALE = Object.fromEntries((CFG.characters || []).map((c) => [c.name, c.scale || 1])); // 작은 그림은 정수배로 키운다 (boot.js)
export const COMPANY = CFG.company;
export const BOSS = CFG.boss;
export const ASSISTANT = CFG.assistant;

// ---------- 사내 공연 무대 ----------
// 사무실 위쪽 벽 밖 숲 공터의 야외 무대. 대표실 위쪽 벽에 뒷문(STAGE.door)을 내고, 문 밖에서 관객석, 무대 단, 노란 배경막 순서로 위로 올라간다.
// 사무실 월드(WORLD)는 그대로 두고 카메라와 미니맵만 위로 STAGE.top까지 늘린다. y는 음수 = 위쪽 벽 바깥.
// 공연(SHOW): 하루 한 번 at에 직원 몇 명이 무대에 올라 두 줄(뒤 4, 앞 3)로 서고, 다 모이면 p2분 동안 같은 박자로 통통 뛴다.
const SX = 594; // 무대 가운데 = 대표실 위쪽 벽 뒷문 x
const GY = -60; // 무대 묶음을 위로 60 띄우고 사이는 풀밭과 디딤돌 길
export const STAGE = {
  x: SX, top: -250 ,                                                  // 카메라, 미니맵이 올라가는 끝 (배경막 위 여백 포함)
  door: { x: SX, inY: 26, outY: -6, w: 24 },                          // 뒷문: 대표실 안 26, 벽 밖 -6, 문 폭 24
  // 공터와 무대를 줄 4명 폭에 맞춰 줄였다 (무대 152, 배경막 136, 공터 216)
  backdrop: { x: SX - 68, y: -156 + GY, w: 136, h: 52 },              // 노란 배경막 (둥근 위쪽)
  floor: { x: SX - 76, y: -112 + GY, w: 152, h: 48, edge: 8 },        // 흰 무대 단 + 앞면 두께
  aisleY: -92,                                                        // 대기석과 관객석 사이 가로 통로 (가운데 세로 통로와 만나는 줄)
  // 공연 자리: 줄마다 발 높이 하나, 가로 30 간격. 앞 줄은 뒤 줄 사이사이 (레퍼런스 배치)
  perf: [[-45, -92], [-15, -92], [15, -92], [45, -92], [-30, -72], [0, -72], [30, -72]].map(([dx, y]) => ({ x: SX + dx, y: y + GY })), // 뒤 4, 앞 3 (발 자리)
  aud: [[-66, -82], [-44, -82], [-22, -82], [22, -82], [44, -82], [66, -82], [-55, -62], [-33, -62], [33, -62], [55, -62]].map(([dx, y]) => ({ x: SX + dx, y })),
  yard: { x0: SX - 108, x1: SX + 108, y1: -46 },                      // 흙 마당 좌우와 아래 끝 (아래로 사무실 벽까지 40은 풀밭과 디딤돌 길)
  // 2부 공연자 대기석: 무대 바로 앞 한 줄 7자리, 가로 26 간격이라 서로 몸이 겹치지 않는다 (예전 무대 양옆 세로 줄은 탑처럼 겹쳤다)
  wings: [-3, -2, -1, 0, 1, 2, 3].map((k) => ({ x: SX + k * 26, y: -102 })),
  path: [-12, -21, -30, -39].map((y, i) => ({ x: SX + (i % 2 ? 3 : -3), y })), // 뒷문에서 마당까지 디딤돌
  avoid: { x0: SX - 122, x1: SX + 122, y0: -244, y1: -46 },           // 숲 소품(나무, 덤불, 꽃)을 두지 않는 범위 (마당)
};
export const SHOW = { at: 17 * 60, p2: 5, wait: 15, min: 3, max: 7 }; // wait = 다 모일 때까지 기다리는 최대 분, min = 공연할 사람이 이보다 적으면 하지 않음

// 정기 회의: 두 명 이상인 팀마다 하루 한 번
const MEET_AT = [10 * 60, 13 * 60 + 30, 15 * 60, 16 * 60, 11 * 60, 14 * 60 + 30];
export const MEETINGS = placed.filter((p) => p.members.length >= 2).map((p, i) => ({ at: MEET_AT[i % MEET_AT.length], teams: [p.zone], name: `${p.name} 회의` }));

export const LINES = {
  cheer: ['와아', '최고예요', '앵콜', '박수 짝짝'],
  work: ['이거 먼저 끝낼게요', '거의 다 됐어요', '한 번만 더 볼게요', '자료 찾는 중', '초안 나왔어요'],
  delayed: ['생각보다 오래 걸려요', '조금만 더 주세요', '막히는 데가 있어요'],
  waiting: ['결재 기다리는 중', '보고 올렸는데 아직이에요'],
  meeting: ['이번 주 뭐 올리죠?', '그건 제가 맡을게요', '마감 언제까지예요?', '지난주 반응 좋았어요', '일정 다시 볼게요', '저도 의견 있어요'],
  break: ['커피 한 잔', '잠깐 쉬어요', '스트레칭', '오늘 바쁘네요'],
  arrive: ['출근했어요', '좋은 아침이에요'],
  approved: ['승인 났어요!', '감사합니다!'],
  ceo: ['좋아요, 진행해요', '확인했어요', '수고했어요'],
  visit: ['이거 잠깐 봐 줄래요?', '물어볼 게 있어요', '이렇게 하면 어때요?'],
  reply: ['오 좋아요', '잠깐만요', '그거 괜찮네요'],
  chat: ['점심 뭐 먹어요?', '어제 그거 봤어요?', '요즘 바쁘죠', '주말에 뭐 해요?'],
  stretch: ['기지개 쭉', '으쌰', '어깨 결려요'],
  assistant: ['다들 잘 돼 가요?', '필요한 거 있어요?', '진행 상황 볼게요'],
};
