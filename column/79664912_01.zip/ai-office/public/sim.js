import { strollToBeach, strollFromBeach, bossToBeach, bossFromBeach, beachSpot } from './art.js';
const STROLL_MS = 180000; // 산책 시간: 출발부터 약 3분 (바닷가에서 시간을 채우고 돌아온다)
// 사무실 시뮬레이션: 출근 -> 자리 작업 -> 회의 -> 대표실 보고 -> 라운지 휴식 -> 퇴근.
// 시간 단위는 '분'. 1x 속도 = 실제 1초에 1분.
import {
  WORLD, WALL_Y, DOOR_GAP, ENTRANCE, CELL, ROOMS, roomById, seatsFor, STAFF, TASKS, MEETINGS, LINES,
  CEO_SEAT, ASSIST_SEAT, ASSIST_BRIEF, REPORT_SPOTS, MEETING_SEATS, BREAK_SPOTS, TEAMS, ERRANDS, CHAT_SPOTS, STAGE, SHOW, BOSS, ASSISTANT,
} from './data.js';

const DAY_START = 8 * 60 + 35, WORK_END = 18 * 60, DAY_RESET = 18 * 60 + 45;
const WALK = 70; // 분당 이동 거리(월드 단위)
const AUTO_APPROVE = 25; // 결재 카드가 이만큼(분) 묵으면 대표가 알아서 처리한다 (실데이터 카드는 빼고)
// 실데이터 연결 (app.js가 live.js로 /api/live를 받아 applyLive를 부른다. 안 부르면 예전 시뮬레이션 그대로)
const LIVE_REPORT_MS = 10 * 60e3; // 이 안에 끝난 실행만 대표실 보고로 보여 준다 (처음 연결할 때 오래된 건 숫자로만)
const LIVE_FRESH_MS = 2 * 60e3;   // 처음 연결할 때 이 안에 시작된 실행은 비서가 일을 맡기러 가는 모습부터
const LIVE_CARDS = 20;            // 실데이터 결재 카드는 최근 이만큼만 남긴다
const hasBatchim = (w) => { const c = w.charCodeAt(w.length - 1) - 0xac00; return c >= 0 && c <= 11171 && c % 28 !== 0; }; // 이/가 고르기

function rng(seed) { // mulberry32
  return () => {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- 길찾기 (8단위 격자 BFS) ----------
const GW = WORLD.w / CELL, GH = WORLD.h / CELL;
const walk = new Uint8Array(GW * GH);
(function buildGrid() {
  for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++) {
    const cx = gx * CELL + CELL / 2, cy = gy * CELL + CELL / 2;
    let ok = cx >= 12 && cx <= WORLD.w - 12 && cy >= 16 && cy <= WALL_Y - 4;
    if (cx >= DOOR_GAP.x0 + 6 && cx <= DOOR_GAP.x1 - 6 && cy > WALL_Y - 6) ok = true; // 입구
    for (const r of ROOMS) {
      if (!r.walled) continue; // 러그 구역은 벽이 없다
      const inOuter = cx > r.x - 5 && cx < r.x + r.w + 5 && cy > r.y - 5 && cy < r.y + r.h + 5;
      if (!inOuter) continue;
      const inInner = cx > r.x + 5 && cx < r.x + r.w - 5 && cy > r.y + 5 && cy < r.y + r.h - 5;
      if (inInner) continue;
      const dy = r.door.side === 'top' ? r.y : r.y + r.h;
      const inDoor = Math.abs(cx - r.door.x) <= 18 && Math.abs(cy - dy) <= 6;
      if (!inDoor) ok = false;
    }
    walk[gy * GW + gx] = ok ? 1 : 0;
  }
})();
// 가구 발자리 막기: 소품 그림의 바닥 상자(art.js propFootprints)에 중심이 드는 칸은 걷지 않는다.
// 책상, 회의 탁자, 카페 탁자, 소파처럼 앉는 가구는 빼고(그 자리가 목적지), 장식 소품만 돌아가게 한다. 화면 쪽(app.js)이 한 번 부른다.
const baseWalk = walk.slice();
export function blockAreas(rects, pad = 2) {
  walk.set(baseWalk);
  for (const r of rects) {
    for (let gy = Math.max(0, Math.floor((r.y0 - pad) / CELL)); gy < GH && gy * CELL < r.y1 + pad + 2; gy++) {
      for (let gx = Math.max(0, Math.floor((r.x0 - pad) / CELL)); gx < GW && gx * CELL < r.x1 + pad; gx++) {
        const cx = gx * CELL + CELL / 2, cy = gy * CELL + CELL / 2;
        if (cx > r.x0 - pad && cx < r.x1 + pad && cy > r.y0 - pad && cy < r.y1 + pad + 2) walk[gy * GW + gx] = 0; // 앞쪽은 조금 더 띄운다
      }
    }
  }
}
const freeAt = (x, y) => { const [gx, gy] = cellOf(x, y); return !!walk[gy * GW + gx]; }; // 소품 발자리가 아닌가
const cellOf = (x, y) => [Math.min(GW - 1, Math.max(0, Math.floor(x / CELL))), Math.min(GH - 1, Math.max(0, Math.floor(y / CELL)))];
function nearestFree(gx, gy) {
  if (walk[gy * GW + gx]) return [gx, gy];
  for (let r = 1; r < 6; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const x = gx + dx, y = gy + dy;
    if (x >= 0 && y >= 0 && x < GW && y < GH && walk[y * GW + x]) return [x, y];
  }
  return [gx, gy];
}
export function findPath(x0, y0, x1, y1) {
  const [sx, sy] = nearestFree(...cellOf(x0, y0));
  const [tx, ty] = nearestFree(...cellOf(x1, y1));
  const prev = new Int32Array(GW * GH).fill(-1);
  const start = sy * GW + sx, goal = ty * GW + tx;
  // 지나가지 않는 구역(noPass): 출발이나 도착이 그 안이 아니면 피해서 복도로 돌아간다
  const inside = (r, x, y, p = 0) => x > r.x - p && x < r.x + r.w + p && y > r.y - p && y < r.y + r.h + p;
  const avoid = ROOMS.filter((r) => r.noPass && !inside(r, x0, y0, 6) && !inside(r, x1, y1, 6));
  const blocked = (n) => avoid.some((r) => inside(r, (n % GW) * CELL + CELL / 2, ((n / GW) | 0) * CELL + CELL / 2, 2));
  const q = [start]; prev[start] = start;
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  for (let qi = 0; qi < q.length && prev[goal] < 0; qi++) {
    const c = q[qi], cx = c % GW, cy = (c / GW) | 0;
    for (const [dx, dy] of dirs) {
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
      const n = ny * GW + nx;
      if (prev[n] >= 0 || !walk[n] || (avoid.length && blocked(n))) continue;
      if (dx && dy && (!walk[cy * GW + nx] || !walk[ny * GW + cx])) continue; // 모서리 가로지르기 금지
      prev[n] = c; q.push(n);
    }
  }
  if (prev[goal] < 0) return [{ x: x1, y: y1 }];
  const cells = [];
  for (let c = goal; c !== start; c = prev[c]) cells.push(c);
  cells.reverse();
  const pts = cells.map((c) => ({ x: (c % GW) * CELL + CELL / 2, y: ((c / GW) | 0) * CELL + CELL / 2 }));
  // 같은 방향으로 이어지는 점은 줄인다
  const out = [];
  for (let i = 0; i < pts.length; i++) {
    const a = out[out.length - 1], b = pts[i], c = pts[i + 1];
    if (a && c && (b.x - a.x) * (c.y - b.y) === (b.y - a.y) * (c.x - b.x)) continue;
    out.push(b);
  }
  out.push({ x: x1, y: y1 });
  return out;
}


// ---------- 시뮬레이션 ----------
export class Office {
  constructor() {
    this.day = 1;
    this.clock = DAY_START;
    this.log = []; // 지시창으로 보낼 메시지 {from, text, time}
    this.cards = []; // 결재 대기 카드
    this.done = 0;
    this.meeting = null;
    this.firedMeetings = new Set();
    this.cardSeq = 1;
    this.liveOn = false; this.liveToday = 0; this.liveSeen = new Map(); this.livePolls = 0; // 실데이터 (applyLive)
    this.rand = rng(this.day * 7919);
    this.ceo = this.makeEmp({ id: 'ceo', name: BOSS, team: 'ceo' }, CEO_SEAT);
    this.ceo.state = 'work'; this.ceo.x = CEO_SEAT.x; this.ceo.y = CEO_SEAT.y;
    const byTeam = {};
    for (const s of STAFF) (byTeam[s.team] ||= []).push(s);
    this.staff = [];
    for (const [team, list] of Object.entries(byTeam)) {
      const seats = team === 'sec' ? [ASSIST_SEAT] : seatsFor(roomById[team], list.length);
      list.forEach((s, i) => this.staff.push(this.makeEmp(s, seats[i])));
    }
    this.byId = Object.fromEntries(this.staff.map((e) => [e.id, e]));
    this.startDay();
  }

  makeEmp(s, seat) {
    return {
      ...s, seat, x: ENTRANCE.x, y: ENTRANCE.y, state: 'off', path: [], next: null,
      task: null, taskIdx: 0, timer: 0, bubble: null, dist: 0, dir: 'down',
      arriveAt: 0, leaveAt: 0, spot: null, waiting: 0, happyUntil: 0, squish: false, meetAt: 0, backAt: 0,
    };
  }

  startDay() {
    this.rand = rng(this.day * 7919);
    this.clock = DAY_START;
    this.done = 0; this.cards = this.cards.filter((k) => k.live); // 실데이터 카드는 날이 바뀌어도 남긴다
    this.meeting = null; this.firedMeetings = new Set();
    this.show = null; this.showRand = rng(this.day * 7307); // 공연 고르기 난수는 따로 (직원 하루 흐름이 바뀌지 않게)
    CHAT_SPOTS.forEach((p) => { p.busy = false; });
    for (const e of this.staff) {
      Object.assign(e, { state: 'off', x: ENTRANCE.x, y: ENTRANCE.y, path: [], next: null, bubble: null, spot: null, squish: false, leaving: false, wentHome: false, meetSeat: null, meetAt: 0, backAt: 0, waiting: 0, idle: null, chatWith: null, reporting: false, queued: false, reportAt: 0, stage: null, stageBack: 0 });
      e.arriveAt = DAY_START + 5 + this.rand() * 35;
      e.leaveAt = WORK_END + this.rand() * 12;
      if (e.task) e.task.progress = Math.min(e.task.progress, e.task.actual * 0.9);
    }
    this.byId.assistant.arriveAt = DAY_START + 2;
    this.say('assistant', '좋은 아침이에요. 다들 출근하는 중이에요.');
  }

  // ---- 공용 헬퍼 ----
  pick(arr) { return arr[Math.floor(this.rand() * arr.length)]; }
  // 말풍선 (mins분 동안)
  talk(e, text, mins = 7) { e.bubble = { text, until: this.clock + mins }; }
  say(from, text) { this.log.push({ from, text, time: this.clock }); }
  // 산책: 입구로 나가 흙길·차도를 따라 바닷가까지 갔다가 같은 길로 돌아와 자리로
  // k = 같이 가는 순번: 길 위에서 옆으로 조금씩 비켜 나란히 걷는다
  // 산책: 1분 안에 산책을 누른 직원들은 한 무리로 입구에 모였다가 같이 나간다(나란히 조금씩 비켜 걷기).
  // 바닷가에서 모래사장을 거닐며 시간을 채우고(출발부터 약 3분) 돌아온다. 복귀를 누르면 바로 돌아온다.
  // 대표는 무리에 안 끼고 대표실 뒷문으로 나간다.
  startStroll(e) {
    if (!e || e.state === 'off' || e.leaving || e.stroll || e.state === 'report') return false;
    if (e.meetSeat) { e.meetSeat = null; e.meetAt = 0; e.backAt = 0; if (this.meeting) this.meeting.members = this.meeting.members.filter((id) => id !== e.id); } // 회의 중이어도 산책 누르면 빠져나와서 나간다
    const now = Date.now();
    e.strollTrail = []; e.strollOff = { dx: 0, dy: 0 }; e.state = 'walk'; e.next = 'work'; e.squish = false; e.stroll = true;
    if (e === this.ceo) {
      e.path = [...findPath(e.x, e.y, STAGE.door.x, STAGE.door.inY), ...bossToBeach()];
      e.strollPhase = 'go'; e.strollT0 = now;
      this.talk(e, '바다 좀 보고 올게요', 6); this.say('assistant', `${e.name}님이 바닷가 산책 나가셨어요.`);
      return true;
    }
    this.releaseSpot(e); this.endIdle(e);
    let g = this.strollGroup;
    if (!g || now - g.t0 > 60000) g = this.strollGroup = { t0: now, n: 0, members: [], departAt: now }; // 첫 사람은 기다리지 않고 바로 출발
    const k = g.n++; g.members.push(e); e.group = g;
    const dx = [0, 9, -9, 16, -16, 22, -22][k % 7], dy = [0, 6, -6, 10, -10, 14, -14][k % 7];
    e.strollOff = { dx, dy };
    e.path = [...findPath(e.x, e.y, ENTRANCE.x, WALL_Y - 6), { x: ENTRANCE.x + dx, y: ENTRANCE.y + 4 }];
    e.strollPhase = 'catch'; // 입구까지 걸어가서 바로 나간다 (뒤에 누른 사람은 빠르게 따라붙음)
    if (g.members.length === 1) { this.talk(e, this.pick(['바다 보고 올게요', '산책 다녀올게요', '바람 좀 쐬고 올게요']), 6); this.say('assistant', `${e.name} 님이 산책 나가요. 1분 안에 산책을 누르면 같이 가요.`); }
    else { this.talk(e, this.pick(['저도 같이 가요!', '같이 가요~', '잠깐만요, 저도요']), 6); this.say('assistant', `${g.members.map((m) => m.name).join(', ')} 님이 같이 산책 가요.`); }
    return true;
  }
  shiftPts(e, pts) { const { dx, dy } = e.strollOff || { dx: 0, dy: 0 }; return pts.map((p) => ({ x: p.x + dx, y: p.y + dy })); }
  // 돌아오는 길: 바닷가에 있으면 그 자리에서 돌아오는 길로, 아직 가는 중이면 온 길을 거꾸로
  returnPath(e) {
    const seat = e.seat || CEO_SEAT;
    if (e === this.ceo) {
      if (e.strollPhase === 'beach') return [...bossFromBeach(e.x), ...findPath(STAGE.door.x, STAGE.door.inY, seat.x, seat.y)];
      return [...[...e.strollTrail].reverse(), ...findPath(e.strollTrail[0] ? e.strollTrail[0].x : e.x, e.strollTrail[0] ? e.strollTrail[0].y : e.y, seat.x, seat.y)];
    }
    const home = [{ x: ENTRANCE.x, y: ENTRANCE.y + 4 }, ...findPath(ENTRANCE.x, WALL_Y - 6, seat.x, seat.y)];
    if (e.strollPhase === 'beach') return [...this.shiftPts(e, strollFromBeach(e.x)), ...home];
    if (e.strollPhase === 'gather') return findPath(e.x, e.y, seat.x, seat.y);
    return [...[...e.strollTrail].reverse(), ...home];
  }
  recallStroll(e) { // 복귀 버튼
    if (!e || !e.stroll || e.strollPhase === 'back') return false;
    e.path = this.returnPath(e); e.strollPhase = 'back';
    if (e.group) e.group.members = e.group.members.filter((m) => m !== e);
    this.talk(e, '들어갈게요!', 4);
    return true;
  }
  // 길을 따라 걷기만 하고(도착해도 다른 상태로 안 바뀜) 다 왔으면 true. 바깥에서 지나온 점은 남겨 둔다(복귀용)
  glide(e, dist) {
    while (dist > 0 && e.path.length) {
      const p = e.path[0], ddx = p.x - e.x, ddy = p.y - e.y, d = Math.hypot(ddx, ddy);
      if (Math.abs(ddx) > Math.abs(ddy) * 0.6) e.dir = ddx > 0 ? 'right' : 'left'; else if (d > 0.01) e.dir = ddy < 0 ? 'up' : 'down';
      if (d <= dist) { e.x = p.x; e.y = p.y; e.path.shift(); dist -= d; e.dist = (e.dist || 0) + d; if (e.stroll && e.strollPhase !== 'back' && e.strollPhase !== 'beach') e.strollTrail.push({ x: p.x, y: p.y }); }
      else { e.x += (ddx / d) * dist; e.y += (ddy / d) * dist; e.dist = (e.dist || 0) + dist; dist = 0; }
    }
    return !e.path.length;
  }
  stepStroll(e, dt) {
    const g = e.group, now = Date.now(), ph = e.strollPhase;
    const lead = g && g.members[0], isLead = !g || lead === e;
    const near = lead && !isLead && lead.stroll && Math.hypot(lead.x - e.x, lead.y - e.y) < 26; // 앞사람을 따라잡으면 같은 걸음으로
    const speed = dt * WALK * (ph === 'beach' ? 0.45 : !isLead && (ph === 'catch' || ph === 'go-fast') && !near ? 1.3 : 0.7);
    if (ph === 'gather') { // 입구에서 무리 모으기: 첫 사람이 도착하고 6초, 늦어도 누른 지 1분이면 출발
      if (!this.glide(e, speed)) return;
      e.dir = 'down';
      if (!g.firstAt) g.firstAt = now;
      const allHere = g.members.every((m) => m.strollPhase !== 'gather' || !m.path.length);
      if (!g.departAt && ((allHere && now - g.firstAt > 6000) || now - g.t0 > 60000)) g.departAt = now;
      if (g.departAt) { e.strollTrail = []; e.path = this.shiftPts(e, strollToBeach()); e.strollPhase = 'go'; e.strollT0 = g.departAt; }
      return;
    }
    if (ph === 'catch') { if (this.glide(e, speed)) { e.strollTrail = []; e.path = this.shiftPts(e, strollToBeach()); e.strollPhase = isLead ? 'go' : 'go-fast'; e.strollT0 = g ? g.departAt : now; } return; }
    if (ph === 'go' || ph === 'go-fast') { if (this.glide(e, speed)) { e.strollPhase = 'beach'; e.path = []; } return; }
    if (ph === 'beach') { // 모래사장 거닐기: 시간이 될 때까지 다음 자리로, 물가에서는 잠깐 멈춰 바다 보기
      if (now - e.strollT0 > STROLL_MS - 30000) { e.path = this.returnPath(e); e.strollPhase = 'back'; return; }
      if (e.lookUntil && now < e.lookUntil) { e.dir = 'up'; return; }
      if (this.glide(e, speed)) {
        const s = beachSpot(e.x, this.rand);
        if (e.path.lookNext) { e.lookUntil = now + 4000 + this.rand() * 4000; }
        e.path = [{ x: s.x, y: s.y }]; e.path.lookNext = !!s.look;
        if (!e.bubble && this.rand() < 0.3) this.talk(e, this.pick(['바다 예쁘다', '바람 좋다~', '파도 소리 좋아요', '아 시원해']), 4);
      }
      return;
    }
    if (this.glide(e, speed)) { // back: 자리 도착
      e.stroll = false; e.strollPhase = null; e.group = null; e.strollTrail = [];
      if (e === this.ceo) { e.state = 'work'; e.x = CEO_SEAT.x; e.y = CEO_SEAT.y; e.dir = 'down'; this.talk(e, '개운하네요!', 4); }
      else { e.state = 'walk'; e.path = []; this.arrive(e); this.talk(e, '개운해요!', 4); }
    }
  }
  goTo(e, x, y, next) {
    e.path = findPath(e.x, e.y, x, y);
    e.state = 'walk'; e.next = next; e.squish = false;
  }
  releaseSpot(e) { if (e.spot) { e.spot.who = null; e.spot = null; } }
  takeSpot(e, list) {
    const free = list.filter((s) => !s.who);
    const s = free.length ? this.pick(free) : this.pick(list);
    s.who = e.id; e.spot = s; return s;
  }
  present(e) { return e.state !== 'off'; }

  newTask(e) {
    const list = TASKS[e.id];
    const title = list[e.taskIdx++ % list.length];
    const est = 70 + this.rand() * 90;
    const actual = est * (this.rand() < 0.22 ? 1.3 + this.rand() * 0.4 : 0.75 + this.rand() * 0.25);
    return { title, est, actual, progress: 0, delayed: false };
  }

  // ---- 상태 진입 ----
  toDesk(e) { this.releaseSpot(e); this.endIdle(e); this.goTo(e, e.seat.x, e.seat.y, 'work'); }
  toReport(e) { this.releaseSpot(e); const s = this.takeSpot(e, REPORT_SPOTS); this.goTo(e, s.x, s.y, 'report'); }
  toBreak(e) {
    this.releaseSpot(e);
    const s = this.takeSpot(e, BREAK_SPOTS);
    e.breakFor = 12 + this.rand() * 10;
    this.goTo(e, s.x, s.y, 'break');
  }
  toLeave(e) { this.releaseSpot(e); this.endIdle(e); this.goTo(e, ENTRANCE.x, ENTRANCE.y, 'gone'); e.leaving = true; }

  arrive(e) {
    e.state = e.next; e.next = null; e.path = [];
    if (e.state === 'work') {
      if (e.id === 'assistant') return;
      if (!e.task) e.task = this.newTask(e);
    } else if (e.state === 'report') { // 줄에 선다. 보고는 맨 앞 사람만 (updateReports)
      e.reportAt = this.clock; e.reporting = false; e.queued = true; e.timer = 6; e.dir = 'up'; e.bubble = null;
    } else if (e.state === 'break') {
      e.timer = e.breakFor; e.squish = !!(e.spot && e.spot.squish);
      if (this.rand() < 0.35) this.talk(e, this.pick(LINES.break), 6);
    } else if (e.state === 'meet') {
      e.timer = 0;
    } else if (e.state === 'gone') {
      e.state = 'off'; e.leaving = false;
    } else if (e.state === 'errand') {
      e.timer = 4; this.talk(e, e.errandText, 5);
    } else if (e.state === 'idle') {
      const d = e.idle;
      e.timer = d.mins; e.dir = d.back ? 'up' : 'down';
      if (d.line) this.talk(e, d.line, Math.min(5, d.mins));
      if (d.kind === 'visit' && d.partner) d.replyAt = this.clock + 1.5;
    }
  }

  // ---- 잠깐 다녀오기 (일하다가 가끔: 물, 출력, 책장, 화분, 동료 자리, 수다, 기지개) ----
  startIdle(e) {
    const kinds = [['water', 2], ['print', 1], ['books', 1], ['plant', 1], ['visit', 2.2], ['chat', 1.4], ['stretch', 1.4]];
    let r = this.rand() * kinds.reduce((a, [, w]) => a + w, 0);
    const kind = (kinds.find(([, w]) => (r -= w) <= 0) || kinds[0])[0];
    const jit = () => (this.rand() - 0.5) * 16;
    if (kind === 'visit') {
      const mates = this.staff.filter((m) => m !== e && m.team === e.team && m.state === 'work' && m.id !== 'assistant');
      if (!mates.length) return;
      const m = this.pick(mates);
      let side = m.seat.x >= e.seat.x ? -24 : 24;
      if (!freeAt(m.seat.x + side, m.seat.y + 4)) side = -side; // 그쪽에 소품이 있으면 반대편에 선다
      e.idle = { kind, mins: 4, partner: m, line: this.pick(LINES.visit) };
      m.chatWith = e;
      return this.goTo(e, m.seat.x + side, m.seat.y + 4, 'idle');
    }
    if (kind === 'chat') {
      const pair = CHAT_SPOTS.find((p) => !p.busy);
      const others = this.staff.filter((m) => m !== e && m.team !== e.team && m.state === 'work' && m.id !== 'assistant' && !m.live);
      if (!pair || !others.length) return;
      const m = this.pick(others);
      pair.busy = true;
      [e, m].forEach((x, k) => {
        x.idle = { kind, mins: 6, pair, line: k === 0 ? this.pick(LINES.chat) : null, talkEvery: 1.6 };
        this.goTo(x, pair[k].x, pair[k].y, 'idle');
      });
      return;
    }
    if (kind === 'stretch') {
      e.idle = { kind, mins: 2.5, line: this.pick(LINES.stretch) };
      let dx = this.rand() < 0.5 ? -26 : 26;
      if (!freeAt(e.seat.x + dx, e.seat.y + 20)) dx = -dx;
      return this.goTo(e, e.seat.x + dx, e.seat.y + 20, 'idle');
    }
    const spot = ERRANDS[kind];
    const at = spot.spots ? this.pick(spot.spots) : spot;
    e.idle = { kind, mins: 3 + this.rand() * 2, back: !!spot.back, line: this.pick(spot.line) };
    this.goTo(e, at.x + jit(), at.y + jit() / 3, 'idle');
  }
  endIdle(e) {
    const d = e.idle;
    if (!d) return;
    if (d.partner && d.partner.chatWith === e) d.partner.chatWith = null;
    if (d.pair) d.pair.busy = false;
    e.idle = null;
  }

  // 대표실 보고 줄: 먼저 온 한 사람만 보고하고 말풍선을 띄운다. 나머지는 "…"로 기다린다(렌더러가 e.queued를 본다).
  reportLoad() { return this.staff.filter((e) => e.state === 'report' || (e.state === 'walk' && e.next === 'report')).length; }
  updateReports() {
    const q = [];
    for (const e of this.staff) { if (e.state === 'report') q.push(e); else e.queued = false; }
    q.sort((a, b) => a.reportAt - b.reportAt);
    q.forEach((e, i) => { e.queued = i > 0; });
    const f = q[0];
    if (f && !f.reporting) {
      f.reporting = true; f.timer = q.length > 1 ? 4 : 6; // 뒤에 기다리는 사람이 있으면 짧게
      this.talk(f, `${f.task ? f.task.title : '보고'} 보고드려요`, f.timer);
    }
  }

  finishReport(e) {
    if (!e.task) return;
    const live = !!e.task.live;
    if (live || !this.liveOn) { // 실데이터 연결 중에는 실제로 끝난 일만 결재 카드가 된다
      this.cards.push({ id: this.cardSeq++, emp: e.id, title: e.task.title, time: this.clock, live, at: e.task.at || 0 }); // at = 실제로 끝난 시각 (ms)
      if (live) { const lc = this.cards.filter((k) => k.live); if (lc.length > LIVE_CARDS) this.cards.splice(this.cards.indexOf(lc[0]), 1); }
      e.waiting++;
      this.talk(this.ceo, '확인할게요', 4);
    }
    e.task = e.live ? this.liveTask(e) : null; // 보고하는 사이 새 일을 받았으면 그 일로
  }

  approve(cardId) {
    const i = this.cards.findIndex((c) => c.id === cardId);
    if (i < 0) return;
    const [card] = this.cards.splice(i, 1);
    const e = this.byId[card.emp];
    e.waiting = Math.max(0, e.waiting - 1);
    this.done++;
    this.talk(this.ceo, this.pick(LINES.ceo), 5);
    if (this.present(e)) { e.happyUntil = this.clock + 20; this.talk(e, this.pick(LINES.approved), 6); }
  }

  // ---- 회의 ----
  callMeeting(teams, name) {
    if (this.meeting) return false;
    const members = this.staff.filter((e) => teams.includes(e.team) && this.present(e) && !e.leaving && !e.stage && !e.stageBack && !e.live && !e.stroll); // 공연 중인 사람, 실제로 일하는 사람은 빼고
    if (!members.length) return false;
    const seats = MEETING_SEATS.map((s) => ({ ...s, who: null }));
    // 앞줄(far)과 뒷줄(near)을 번갈아 채운다
    const order = [2, 7, 1, 6, 3, 8, 0, 5, 4, 9];
    this.meeting = { teams, name, members: members.map((m) => m.id), start: this.clock, end: this.clock + 38, seats };
    // 자리에서 일하던 사람은 한꺼번에 일어나지 않고 조금씩 시차를 두고 출발한다 (문 앞 줄서기 방지)
    let lag = 0;
    members.forEach((m, i) => {
      if (m.state === 'report' && m.task) this.finishReport(m);
      this.releaseSpot(m); this.endIdle(m);
      const s = seats[order[i % order.length]];
      s.who = m.id; m.meetSeat = s;
      if (m.state === 'work' && lag > 0) { m.meetAt = this.clock + lag; lag += 0.6 + this.rand() * 0.5; return; }
      if (m.state === 'work') lag = 0.6 + this.rand() * 0.5;
      this.goTo(m, s.x, s.y, 'meet');
    });
    this.say('assistant', `${name} 시작해요. 회의실로 모이는 중이에요.`);
    return true;
  }
  // ---- 사내 공연 ----
  // 무대로 가는 길: 지금 자리에서 대표실 뒷문 안쪽까지는 격자 길찾기, 그다음 벽을 지나 문 밖, 공연하는 사람은 가운데 통로로 무대까지
  toStage(e, spot, role) {
    this.releaseSpot(e); this.endIdle(e);
    const d = STAGE.door;
    e.stage = { role, spot };
    e.path = [...findPath(e.x, e.y, d.x, d.inY), { x: d.x, y: d.inY }, { x: d.x, y: 8 }, { x: d.x, y: d.outY }, { x: d.x, y: STAGE.yard.y1 - 4 }, ...(role === 'perf' ? [{ x: d.x, y: STAGE.aisleY }] : []), { x: spot.x, y: spot.y }]; // 문 밖은 디딤돌 길로 마당까지
    e.state = 'walk'; e.next = role === 'perf' ? 'wait' : 'watch'; e.squish = false; // 공연자는 먼저 무대 앞 대기석에서 기다린다
  }
  // 무대 밖(벽 위쪽)에서 대표실 뒷문 안쪽까지 가는 점들 (공연하는 사람은 가운데 통로부터). 지금 걷는 중이면 지금 자리에서 바로
  fromStage(e) {
    const d = STAGE.door, perf = e.stage && e.stage.role === 'perf' && e.y < STAGE.aisleY;
    e.stage = null;
    if (e.y > d.outY + 1) return []; // 이미 문 안쪽
    return [...(perf ? [{ x: d.x, y: STAGE.aisleY }] : []), ...(e.y < STAGE.yard.y1 - 4 ? [{ x: d.x, y: STAGE.yard.y1 - 4 }] : []), { x: d.x, y: d.outY }, { x: d.x, y: 8 }, { x: d.x, y: d.inY }];
  }
  stageRoute(e, x, y) { // 무대 쪽에서 (x, y)까지: 벽 밖이면 뒷문을 지나고, 이미 안쪽이면 지금 자리에서 바로
    const pre = this.fromStage(e), from = pre.length ? { x: STAGE.door.x, y: STAGE.door.inY } : e;
    return [...pre, ...findPath(from.x, from.y, x, y)];
  }
  // 공연: gather(모이기) -> swap(무대 자리로) -> p2(직원 공연) -> 끝. 시각은 show에 기록하고 stepShow가 넘긴다
  startShow() {
    const free = (e) => this.present(e) && !e.live && !e.leaving && !e.meetAt && !e.backAt && !e.meetSeat && !e.stage && ['work', 'idle', 'break'].includes(e.state) && !(e.state === 'work' && e.task && e.task.progress >= e.task.actual);
    const pool = this.staff.filter(free);
    const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(this.showRand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    let perf = [];
    const far = (e) => Math.hypot(e.x - STAGE.door.x, e.y - STAGE.door.inY);
    perf = [...pool].sort((a, b) => far(a) - far(b)).slice(0, SHOW.max); // 뒷문에서 가까운 사람부터 (멀면 다 모일 때까지 다른 사람이 오래 기다린다)
    if (perf.length < SHOW.min) { this.say('assistant', '공연할 사람이 모자라서 오늘 공연은 쉬어요.'); return false; }
    // 무대 자리: 7명이면 뒤 4, 앞 3 (STAGE.perf). 적으면 같은 규칙(뒤가 반 이상, 가로 30 간격, 줄마다 가운데 정렬)으로 빈자리 없이. 모이는 동안은 무대 앞 대기석(STAGE.wings)에서 기다린다
    const back = perf.length >= 4 ? Math.ceil(perf.length * 4 / 7) : perf.length, row = (n, i) => STAGE.x + Math.round((i - (n - 1) / 2) * 30);
    perf.forEach((e, i) => { this.toStage(e, STAGE.wings[i], 'perf'); e.stage.final = i < back ? { x: row(back, i), y: STAGE.perf[0].y } : { x: row(perf.length - back, i - back), y: STAGE.perf[4].y }; });
    const aud = shuffle(pool.filter((e) => !perf.includes(e) && e.state === 'work')).slice(0, STAGE.aud.length);
    aud.forEach((e, i) => this.toStage(e, STAGE.aud[i], 'aud'));
    this.show = { called: this.clock, phase: 'gather', start: 0, perf, aud };
    this.say('assistant', `곧 사내 공연이에요. 직원 ${perf.length}명이 ${BOSS}실 뒷문 밖 무대로 모이는 중이에요.`);
    return true;
  }
  stepShow(c) {
    const sh = this.show;
    if (sh.phase === 'gather') { // 공연자가 다 모이면(늦어도 SHOW.wait분) 무대 자리로. 관객이 앉을 시간으로 최소 2분
      if (c > sh.called + 2 && (sh.perf.every((e) => e.state === 'wait') || c > sh.called + SHOW.wait)) sh.phase = 'p1';
    } else if (sh.phase === 'p1') { // 무대 앞 대기석에서 무대 자리로
      sh.phase = 'swap'; sh.swapAt = c; sh.start = c;
      for (const e of sh.perf) {
        if (!e.stage) continue; // 그새 퇴근한 사람
        e.stage.spot = e.stage.final;
        if (e.state === 'walk' && e.path.length) { e.path[e.path.length - 1] = { x: e.stage.final.x, y: e.stage.final.y }; e.next = 'show'; } // 아직 오는 중이면 가던 길 끝만 바꾼다 (벽을 뚫지 않게)
        else { e.path = [{ x: e.stage.final.x, y: e.stage.final.y }]; e.state = 'walk'; e.next = 'show'; }
      }
      if (!sh.perf.length) sh.end = c + 1;
    } else if (sh.phase === 'swap') {
      if (sh.perf.length && (sh.perf.every((e) => e.state === 'show' || !e.stage) || c > sh.swapAt + 3)) {
        sh.phase = 'p2'; sh.p2Start = c; sh.end = c + SHOW.p2;
        this.say('assistant', `사내 공연이에요. 직원 ${sh.perf.length}명이 무대에 올랐어요.`);
      } else if (!sh.perf.length && c >= sh.end) this.endShow();
    } else if (sh.phase === 'p2' && c >= sh.end) this.endShow();
  }
  endShow() {
    const sh = this.show; this.show = null;
    let lag = 0;
    for (const e of [...sh.aud, ...sh.perf]) { // 관객 먼저, 문에 가까운 사람부터 하나씩
      if (!e.stage) continue;
      e.stageBack = this.clock + lag; lag += 0.25 + this.showRand() * 0.3;
    }
    this.say('assistant', '공연 끝났어요. 다들 자리로 돌아가는 중이에요.');
  }

  endMeeting() {
    const m = this.meeting; this.meeting = null;
    // 끝나면 앉아 있던 사람도 한꺼번에 나가지 않고 하나씩 일어난다 (문 앞과 복도 줄서기 방지)
    let lag = 0;
    const door = roomById.meeting.door, dy = roomById.meeting.y + roomById.meeting.h;
    const near = (id) => Math.hypot(this.byId[id].x - door.x, this.byId[id].y - dy);
    for (const id of [...m.members].sort((a, b) => near(a) - near(b))) {
      const e = this.byId[id];
      e.meetAt = 0;
      if (e.state === 'meet') { if (lag > 0) { e.backAt = this.clock + lag; } else { e.meetSeat = null; this.toDesk(e); } lag += 0.6 + this.rand() * 0.5; continue; }
      e.meetSeat = null;
      if (e.state === 'walk' && e.next === 'meet') this.toDesk(e);
    }
  }

  // ---- 실데이터 (/api/live 스냅샷) ----
  // snap = { ok, now, runs: [{ id, agent, state: working|done, startedAt, lastAt, finishedAt?, title? }], today: { done } }, null = 연결 끊김.
  // 일하는 실행이 있는 직원 = e.live (자리에서 그 일만 한다: 잠깐 다녀오기, 회의, 공연, 퇴근에서 빠짐).
  // 실행이 끝나면 대표실로 보고하러 가고 결재 카드가 생긴다. 연결 중 다른 직원은 지어낸 일을 하되 보고와 카드는 만들지 않는다.
  applyLive(snap) {
    if (!snap || !snap.ok) {
      if (!this.liveOn) return;
      this.liveOn = false;
      for (const e of this.staff) if (e.live) { e.live = null; if (e.task && e.task.live && !e.task.done && e.state !== 'report') e.task = null; } // 끝난 일은 보고까지 마친다
      this.say('assistant', '실제 작업 기록과 연결이 끊겼어요. 지금은 연습 화면으로 돌아갈게요.');
      return;
    }
    const first = !this.liveOn;
    this.liveOn = true; this.livePolls++;
    this.liveToday = snap.today ? snap.today.done : 0;
    const now = snap.now;
    const working = {};
    for (const r of snap.runs) if (r.state === 'working' && this.byId[r.agent] && r.agent !== 'assistant') (working[r.agent] ||= []).push(r);
    const started = [];
    for (const e of this.staff) {
      const w = (working[e.id] || []).sort((a, b) => b.startedAt - a.startedAt);
      if (w.length) {
        const fresh = w.filter((r) => !this.liveSeen.has(r.id) && (this.livePolls > 1 || now - r.startedAt < LIVE_FRESH_MS));
        const was = e.live;
        e.live = { runs: w.length, title: w[0].title || '', since: w[w.length - 1].startedAt, ids: w.map((r) => r.id) };
        if (!was) { this.liveStart(e, fresh.length > 0); if (fresh.length) started.push(e); }
        else if (e.task && e.task.live) e.task.title = this.liveTitle(e);
      } else if (e.live) e.live = null; // 끝난 건 아래 done에서 보고로. 기록이 끊긴(stale) 실행은 그냥 일을 내려놓는다
      for (const r of w) this.liveSeen.set(r.id, 'working');
    }
    for (const r of snap.runs) {
      if (r.state !== 'done' || this.liveSeen.get(r.id) === 'done') continue;
      const e = this.byId[r.agent];
      const recent = now - r.finishedAt < LIVE_REPORT_MS;
      this.liveSeen.set(r.id, 'done');
      if (!e || e.id === 'assistant' || !recent) continue;
      this.liveFinish(e, r.title, r.finishedAt);
    }
    for (const e of this.staff) if (!e.live && e.task && e.task.live && !e.task.done && e.state !== 'report') e.task = null; // 끝 표시 없이 사라진 실행
    if (first) {
      const n = this.staff.filter((e) => e.live);
      const who = n.map((e) => e.name).join(', ');
      this.say('assistant', n.length ? `실제 작업 기록과 연결됐어요. 지금 ${who}${hasBatchim(who) ? '이' : '가'} 일하는 중이에요.` : '실제 작업 기록과 연결됐어요. 지금 일하는 직원은 없어요.');
    } else if (started.length) this.say('assistant', `${started.map((e) => e.name).join(', ')}에게 일을 맡겼어요.`);
    if (started.length) this.assistDeliver(started[0]);
  }
  liveTitle(e) { return e.live && e.live.title ? e.live.title : `${ASSISTANT}${hasBatchim(ASSISTANT) ? '이' : '가'} 맡긴 일`; }
  liveTask(e) { return { title: this.liveTitle(e), est: Infinity, actual: Infinity, progress: 0, delayed: false, live: true }; }
  // 일 시작: 어디에 있든 자기 자리로 와서 일한다
  liveStart(e, fresh) {
    const reporting = e.state === 'report' || (e.state === 'walk' && e.next === 'report');
    const pending = e.task && ((e.task.live && e.task.done) || reporting); // 하던 보고가 남았으면 그것부터 (finishReport가 새 일을 쥐여 준다. 지어낸 일이면 카드 없이)
    if (!pending) e.task = this.liveTask(e);
    e.leaving = false; e.wentHome = false;
    if (e.meetSeat) { e.meetSeat = null; e.meetAt = 0; e.backAt = 0; if (this.meeting) this.meeting.members = this.meeting.members.filter((id) => id !== e.id); }
    if (e.stage || e.stageBack || e.y < 0) { /* 무대 쪽이면 공연 흐름이 자리로 돌려보낸다 */ }
    else if (e.state === 'off') { e.x = ENTRANCE.x; e.y = ENTRANCE.y; this.goTo(e, e.seat.x, e.seat.y, 'work'); }
    else if (e.state === 'report' || pending) { /* 보고하러 가는 중이거나 보고 중: 마치면 finishReport가 새 일을 쥐여 주고 자리로 */ }
    else if (e.state !== 'work' || e.idle) this.toDesk(e);
    this.talk(e, e.live.runs > 1 ? `${e.live.runs}건 같이 하는 중이에요` : (fresh ? '맡았어요!' : '하던 일 마저 할게요'), 6);
  }
  // 일 끝: 대표실로 보고하러 간다 (자리에 없으면 입구에서 바로)
  liveFinish(e, title, at) {
    if (e.task && e.task.live && e.task.done) this.finishReport(e); // 앞에 끝난 일 보고가 아직이면 카드부터 (걷는 중이든 보고 중이든)
    e.task = { title: title || `${e.name} 작업 끝`, est: 1, actual: 1, progress: 1, delayed: false, live: true, done: true, at };
    if (e.stage || e.stageBack || e.meetSeat || e.y < 0) return; // 무대, 회의에서 돌아와 자리에 앉으면 보고하러 간다 (work 단계)
    if (e.state === 'off') { e.x = ENTRANCE.x; e.y = ENTRANCE.y; e.leaving = false; e.wentHome = false; }
    if (e.state === 'walk' && e.next === 'report') return;
    this.toReport(e);
  }
  // 비서가 일을 맡은 직원 자리로 가서 전한다 (팀 자리 둘러보기와 같은 errand 흐름)
  assistDeliver(m) {
    const j = this.byId.assistant;
    if (!j || !['work', 'errand'].includes(j.state) || j.stage || j.y < 0) return;
    let side = m.seat.x > j.x ? -24 : 24;
    if (!freeAt(m.seat.x + side, m.seat.y + 6)) side = -side;
    j.errandText = `${m.name}, 이거 부탁해요`;
    this.goTo(j, m.seat.x + side, m.seat.y + 6, 'errand');
  }

  // ---- 지시창 빠른 버튼 ----
  command(kind) {
    if (kind === 'status') {
      this.log.push({ from: 'me', text: '현황 보고', time: this.clock });
      return this.say('assistant', this.statusText());
    }
    if (kind === 'show') { // 공연 버튼: 17:00 자동 공연과 같은 흐름. 이미 모이는 중이거나 공연 중이면 다시 열지 않는다 (카메라만 무대로, app.js)
      this.log.push({ from: 'me', text: '공연', time: this.clock });
      if (this.show) return this.say('assistant', this.show.start ? '지금 공연 중이에요. 무대를 보여 드릴게요.' : '무대로 모이는 중이에요. 곧 시작해요.');
      this.startShow();
      return;
    }
    if (kind === 'meeting') {
      this.log.push({ from: 'me', text: '회의 소집', time: this.clock });
      if (this.meeting) return this.say('assistant', '회의실이 쓰는 중이에요. 끝나고 다시 불러 주세요.');
      const teams = this.busiestTeams();
      if (!this.callMeeting(teams, `${TEAMS[teams[0]].name} 회의`)) this.say('assistant', '지금 모일 수 있는 사람이 없어요.');
    }
  }
  busiestTeams() {
    const count = {};
    for (const e of this.staff) if (e.state === 'work' && e.team !== 'sec') count[e.team] = (count[e.team] || 0) + 1;
    const top = Object.entries(count).sort((a, b) => b[1] - a[1])[0];
    return [top ? top[0] : 'cplan'];
  }

  // ---- 표시용 ----
  counts() {
    return { present: this.staff.filter((e) => this.present(e)).length, done: this.liveOn ? this.liveToday : this.done, live: this.liveOn ? this.staff.filter((e) => e.live).length : null };
  }
  statusText() {
    const p = this.staff.filter((e) => this.present(e));
    const n = (st) => p.filter((e) => e.state === st).length;
    if (this.liveOn) {
      const w = this.staff.filter((e) => e.live);
      const now = w.length ? `지금 실제로 일하는 직원은 ${w.map((e) => e.name + (e.live.runs > 1 ? ` ${e.live.runs}건` : '')).join(', ')}이에요.` : '지금 실제로 일하는 직원은 없어요.';
      return `${now} 오늘 끝낸 일은 ${this.liveToday}건, 결재 대기 ${this.cards.filter((k) => k.live).length}건이에요.`;
    }
    return `지금 ${p.length}명 근무 중이에요. 자리 작업 ${n('work')}명, 회의 ${n('meet')}명, 라운지 카페 ${n('break')}명, 이동 중 ${n('walk')}명. 결재 대기 ${this.cards.length}건, 오늘 완료 ${this.done}건이에요.`;
  }
  describe(e) {
    const where = {
      off: '아직 출근 전이에요', walk: '이동하는 중이에요', work: '자리에서 일하는 중이에요', meet: '회의 중이에요',
      report: e.queued ? `${BOSS}실에서 보고 차례를 기다리는 중이에요` : `${BOSS}실에서 보고하는 중이에요`, show: '사내 공연 무대에 올라 있어요', wait: '무대 옆에서 2부 차례를 기다리는 중이에요', watch: '사내 공연을 보는 중이에요', break: '라운지 카페에서 쉬는 중이에요', errand: '팀 자리를 둘러보는 중이에요',
      idle: { water: '물 마시러 갔어요', print: '출력하러 갔어요', books: '자료 찾으러 갔어요', plant: '화분에 물 주는 중이에요', visit: '동료 자리에 말 걸러 갔어요', chat: '수다 떠는 중이에요', stretch: '기지개 켜는 중이에요' }[e.idle?.kind] || '잠깐 자리를 비웠어요',
    }[e.state] || '';
        if (e.state === 'off' && e.wentHome) return '퇴근했어요';
    if (e.live) return `${where}. ${ASSISTANT}${hasBatchim(ASSISTANT) ? '이' : '가'} 맡긴 실제 작업${e.live.runs > 1 ? ` ${e.live.runs}건` : ''}을 하고 있어요${e.live.title ? `: "${e.live.title}"` : ''}.`;
    if (e.task && e.task.live && e.task.done) return `${where}. 실제 작업을 끝내고 보고하러 가요.`;
    if (this.liveOn) return where; // 연결 중에는 지어낸 업무 제목을 보여 주지 않는다
    return e.task ? `${where}. 맡은 일은 "${e.task.title}"이에요.` : where;
  }
  mood(e) {
    if (e.task && e.task.delayed) return 'angry';
    if (this.clock < e.happyUntil) return 'happy';
    if (e.waiting > 0) return 'sulky';
    return 'calm';
  }
  phase() {
    if (this.clock < 9 * 60 + 15) return '출근하는 중';
    if (this.clock >= WORK_END) return '퇴근하는 중';
    if (this.show) return { gather: '공연 무대로 모이는 중', p1: '사내 공연 준비', swap: '사내 공연 준비', p2: '사내 공연 중' }[this.show.phase];
    if (this.meeting) return `${this.meeting.name} 중`;
    return '직원들이 일하는 중';
  }

  // ---- 한 걸음 ----
  step(dt) { // dt = 경과 분
    this.clock += dt;
    const c = this.clock;
    // 정기 회의
    for (const m of MEETINGS) {
      const key = `${this.day}:${m.at}`;
      if (c >= m.at && c < WORK_END && !this.firedMeetings.has(key)) { this.firedMeetings.add(key); this.callMeeting(m.teams, m.name); }
    }
    if (this.meeting) {
      const gathering = this.meeting.members.some((id) => { const e = this.byId[id]; return e.state === 'walk' && e.next === 'meet'; });
      if (gathering) this.meeting.end += dt; // 다 모일 때까지 회의 시간이 흐르지 않게
      if (c >= this.meeting.end) this.endMeeting();
    }
    // 사내 공연 (하루 한 번)
    if (false && c >= SHOW.at && c < WORK_END - 20 && this.showDay !== this.day) { this.showDay = this.day; if (!this.show) this.startShow(); } // 버튼으로 연 공연이 진행 중이면 그날 자동 공연은 건너뜀
    if (this.show) this.stepShow(c);
    // 비서 아침 브리핑
    const j = this.byId.assistant;
    if (this.briefed && j.state === 'work' && c < WORK_END - 30 && this.rand() < dt * 0.012) { // 팀 자리를 한 바퀴
      const m = this.pick(this.staff.filter((x) => x !== j && x.state === 'work'));
      if (m) {
        let side = m.seat.x > j.x ? -24 : 24;
        if (!freeAt(m.seat.x + side, m.seat.y + 6)) side = -side; // 소품 옆이면 반대편
        j.errandText = this.pick(LINES.assistant); this.goTo(j, m.seat.x + side, m.seat.y + 6, 'errand');
      }
    }
    if (!this.briefed && c >= 9 * 60 + 20 && j.state === 'work') {
      this.briefed = this.day; j.errandText = '오늘 일정 브리핑이에요';
      this.goTo(j, ASSIST_BRIEF.x, ASSIST_BRIEF.y, 'errand'); // 대표 책상 오른쪽
    }

    for (const card of this.cards.filter((k) => !k.live && c - k.time > AUTO_APPROVE)) this.approve(card.id);
    this.updateReports();
    for (const e of this.staff) this.stepEmp(e, dt);
    if (this.ceo.stroll) this.stepStroll(this.ceo, dt); // 대표 산책 (뒷문으로)
    if (this.ceo.bubble && c > this.ceo.bubble.until) this.ceo.bubble = null;

    if (c >= DAY_RESET || (c > WORK_END + 10 && this.staff.every((e) => e.state === 'off'))) {
      this.day++; this.briefed = 0; this.startDay();
    }
  }

  stepEmp(e, dt) {
    const c = this.clock;
    if (e.bubble && c > e.bubble.until) e.bubble = null;
    if (e.stageBack) { // 공연 끝, 자기 차례가 오면 뒷문으로 들어와 자리로
      if (c < e.stageBack) return;
      e.stageBack = 0;
      e.path = this.stageRoute(e, e.seat.x, e.seat.y);
      e.state = 'walk'; e.next = 'work'; e.squish = false;
      return;
    }
    if (e.backAt) { // 회의 끝, 자기 차례가 오면 자리로
      if (c < e.backAt) return;
      e.backAt = 0; e.meetSeat = null;
      if (!e.leaving) return this.toDesk(e);
    }
    if (e.meetAt) { // 회의 출발 대기 (자리에서 하던 일을 마저 하는 중)
      if (c < e.meetAt) return;
      e.meetAt = 0;
      if (this.meeting && e.meetSeat && !e.leaving) return this.goTo(e, e.meetSeat.x, e.meetSeat.y, 'meet');
    }
    if (e.state === 'off') {
      if (e.live ? !e.leaving : (c >= e.arriveAt && c < WORK_END && !e.leaving && !e.wentHome)) { // 실제로 일하는 중이면 시각과 상관없이 출근
        e.x = ENTRANCE.x; e.y = ENTRANCE.y;
        this.goTo(e, e.seat.x, e.seat.y, 'work');
        if (this.rand() < 0.3) this.talk(e, this.pick(LINES.arrive), 5);
      }
      return;
    }
    if (e.stroll) { this.stepStroll(e, dt); return; } // 산책 중에는 다른 일에 안 불려 간다
    if (c >= e.leaveAt && !e.live && !e.leaving && e.state !== 'off') {
      if (e.state === 'report' && e.task) this.finishReport(e);
      if (e.stage || e.stageBack || e.y < 0) { // 무대나 관객석에서 바로 퇴근: 뒷문으로 들어와 입구로 (벽을 뚫지 않게)
        e.stageBack = 0; this.releaseSpot(e); this.endIdle(e);
        e.path = this.stageRoute(e, ENTRANCE.x, ENTRANCE.y);
        e.state = 'walk'; e.next = 'gone'; e.leaving = true; e.squish = false;
      } else this.toLeave(e);
      e.wentHome = true;
    }
    switch (e.state) {
      case 'walk': this.move(e, dt * WALK); break;
      case 'work': {
        if (!e.task) { if (e.id !== 'assistant') e.task = this.newTask(e); break; }
        const t = e.task;
        if (this.liveOn && !t.live && t.progress >= t.actual) { e.task = null; if (this.rand() < 0.4) this.toBreak(e); break; } // 연결 중 지어낸 일은 보고 없이 다음 일로
        if (t.progress >= t.actual) { // 끝냈으면 보고하러. 대표실 보고 자리가 다 차 있으면 자리에서 조금 기다린다
          if (this.reportLoad() < REPORT_SPOTS.length) this.toReport(e);
          break;
        }
        t.progress += dt;
        if (!t.delayed && t.progress > t.est) {
          t.delayed = true;
          if (this.rand() < 0.7) this.talk(e, this.pick(LINES.delayed), 8);
        }
        if (!e.bubble && this.rand() < dt * 0.02) this.talk(e, this.pick(e.waiting ? LINES.waiting : LINES.work), 6);
        if (e.id !== 'assistant' && !e.live && !e.chatWith && c < WORK_END - 20 && this.rand() < dt * 0.016) this.startIdle(e);
        break;
      }
      case 'idle': {
        const d = e.idle;
        e.timer -= dt;
        if (d && d.replyAt && c >= d.replyAt && d.partner && d.partner.state === 'work') { this.talk(d.partner, this.pick(LINES.reply), 4); d.replyAt = 0; }
        if (d && d.talkEvery && !e.bubble && this.rand() < dt / d.talkEvery * 0.5) this.talk(e, this.pick(LINES.chat), 3);
        if (e.timer <= 0) this.toDesk(e);
        break;
      }
      case 'report':
        if (!e.reporting) break; // 줄에서 기다리는 중
        e.timer -= dt;
        if (e.timer <= 0) { this.finishReport(e); if (e.live) this.toDesk(e); else this.toBreak(e); }
        break;
      case 'break':
        e.timer -= dt;
        if (e.timer <= 0) this.toDesk(e);
        break;
      case 'meet':
        if (!e.bubble && this.rand() < dt * 0.05) this.talk(e, this.pick(LINES.meeting), 5);
        break;
      case 'show': case 'wait': break; // 무대 위(통통은 렌더러가 같은 박자로), 무대 앞 대기석
      case 'watch':
        if (this.show && this.show.start && !e.bubble && this.showRand() < dt * 0.08) this.talk(e, LINES.cheer[Math.floor(this.showRand() * LINES.cheer.length)], 2);
        break;
      case 'errand':
        e.timer -= dt;
        if (e.timer <= 0) this.toDesk(e);
        break;
    }
  }

  move(e, dist) {
    while (dist > 0 && e.path.length) {
      const p = e.path[0];
      const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy);
      if (Math.abs(dx) > Math.abs(dy) * 0.6) e.dir = dx > 0 ? 'right' : 'left';
      else if (d > 0.01) e.dir = dy < 0 ? 'up' : 'down';
      if (d <= dist) { e.x = p.x; e.y = p.y; e.path.shift(); dist -= d; e.dist += d; }
      else { e.x += (dx / d) * dist; e.y += (dy / d) * dist; e.dist += dist; dist = 0; }
    }
    if (!e.path.length) this.arrive(e);
  }

  // URL ?t=1030 처럼 특정 시각까지 빨리 돌리기 (확인용)
  fastForward(to) {
    const d = this.day; // 모두 퇴근하면 18:45 전에 다음 날로 넘어가서 ?t=1830 같은 목표에 끝내 닿지 않던 것(무한 반복) 방지
    while (this.clock < to && this.day === d) this.step(0.25);
  }
}
