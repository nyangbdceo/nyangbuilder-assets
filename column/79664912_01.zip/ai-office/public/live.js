// 실데이터 받기: /api/live를 몇 초마다 읽어 office.applyLive에 넘긴다.
// 서버가 없거나(정적 파일만 연 경우) 꺼져 있으면(AIO_LIVE=0) 아무것도 바꾸지 않는다 = 예전 시뮬레이션 그대로.
// 두 번 연달아 실패하면 연결 끊김으로 보고 시뮬레이션으로 돌아간다.
const EVERY_MS = 5000;

export function startLive(office, { url = 'api/live', every = EVERY_MS } = {}) {
  let fails = 0, stopped = false, timer = 0;
  async function poll() {
    if (stopped) return;
    try {
      const r = await fetch(url, { cache: 'no-store' });
      const snap = r.ok ? await r.json() : null;
      if (snap && snap.ok) { fails = 0; office.applyLive(snap); }
      else if (snap && snap.reason === 'off') { office.applyLive(null); stopped = true; return; } // 서버에서 끈 경우 다시 묻지 않는다
      else if (++fails >= 2) office.applyLive(null);
    } catch {
      if (++fails >= 2) office.applyLive(null);
    }
    timer = setTimeout(poll, every);
  }
  poll();
  return { stop() { stopped = true; clearTimeout(timer); } };
}

// ---------- 실제 작업 표시 ----------
// 실제로 일하는 직원(e.live) 머리 오른쪽 위에 작은 배지: 하늘색 + 번개(일하는 중), 보고하러 가는 동안은 연두 + 체크(끝남).
// 지어낸 일을 하는 직원에게는 붙지 않는다(e.live, task.live만 본다). ?live=0이면 office.liveOn이 꺼져 있어 안 그린다.
// 도트 화풍: 갈색 외곽선(모서리 깎음), 낮은 채도 채움, 9x9칸. 칸 크기 q는 캐릭터 크기를 따라감. 일하는 중은 0.5초마다 1칸 오르내림
const INK = '#4A342C', PAPER = '#FFFDF9';
const BOLT = ['..##.', '.##..', '#####', '..##.', '.##..'];
const CHECK = ['.....', '....#', '#..##', '.###.', '..#..'];
const DIGITS = { 2: ['##.', '..#', '.#.', '#..', '###'], 3: ['##.', '..#', '.#.', '..#', '##.'], 4: ['#.#', '#.#', '###', '..#', '..#'], 5: ['###', '#..', '##.', '..#', '##.'] };
function badge(g, x, y, q, w, fill, rows, ox) {
  g.fillStyle = INK; g.fillRect(x + q, y, (w - 2) * q, 9 * q); g.fillRect(x, y + q, w * q, 7 * q);
  g.fillStyle = fill; g.fillRect(x + q, y + q, (w - 2) * q, 7 * q);
  g.fillStyle = 'rgba(74,52,44,0.18)'; g.fillRect(x + q, y + 7 * q, (w - 2) * q, q); // 아래 한 줄 그늘
  for (const [rs, dx] of rows) rs.forEach((r, j) => { for (let i = 0; i < r.length; i++) if (r[i] === '#') { g.fillStyle = dx.ink ? INK : PAPER; g.fillRect(x + (dx.x + i) * q, y + (2 + j) * q, q, q); } });
}
export function drawLiveMarks(view, office, t) {
  if (!office.liveOn) return;
  const g = view.g, s = view.zoom * view.dpr, d = Math.max(1, Math.round(view.dpr));
  g.setTransform(1, 0, 0, 1, 0, 0);
  for (const e of office.staff) {
    const done = !e.live && e.task && e.task.live && e.task.done;
    if ((!e.live && !done) || !e._box || e.state === 'off') continue;
    const [x] = view.toDev(e.x, e.y), bw = e._box.w * s;
    const q = Math.min(3 * d, Math.max(d, Math.round(bw * 0.4 / 9))); // 배지 폭 = 캐릭터 몸 폭의 약 40% (보기 배율을 따라감, CSS 4.5~13.5px 칸)
    const n = e.live ? e.live.runs : 0, many = n > 1 && DIGITS[Math.min(n, 5)];
    const w = many ? 13 : 9;
    const bob = !done && Math.floor(t / 500) % 2 ? q : 0;
    const left = e.state === 'report' && e.queued; // 보고 줄 "…" 표시는 오른쪽이라 그때는 왼쪽에
    const bx = left ? Math.round(x - bw * 0.3) - w * q : Math.round(x + bw * 0.3), by = e._box.top - 4 * q - bob; // 머리 오른쪽 위 모서리에 걸쳐 (말풍선 꼬리 자리는 피함)
    const rows = done ? [[CHECK, { x: 2 }]] : many ? [[BOLT, { x: 2 }], [DIGITS[Math.min(n, 5)], { x: 8, ink: true }]] : [[BOLT, { x: 2 }]];
    badge(g, bx, by, q, w, done ? '#A8D3AE' : '#9CC6EF', rows);
  }
}
