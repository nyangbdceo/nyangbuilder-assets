// 왼쪽 '주간 일정' 패널: 요일별 스케줄(schedule.json을 서버가 읽어 줌)과 오늘 할 일 목록.
// 할 일은 이 브라우저(localStorage)에 날짜별로 남는다.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n) => String(n).padStart(2, '0');
const DAYS = ['일', '월', '화', '수', '목', '금', '토'];
const ORDER = [1, 2, 3, 4, 5, 6, 0]; // 월요일부터
const CAT = { work: '본업', content: '콘텐츠', study: '공부', side: '부업', check: '점검·계획', meal: '식사', rest: '휴식' };
const dateKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* 저장 못 해도 화면은 동작 */ } };

document.body.insertAdjacentHTML('beforeend', `
  <button class="sch-tab" id="sch-tab" aria-expanded="false"><b class="sch-ico" aria-hidden="true">📅</b><span>주간 일정</span></button>
  <aside class="sch" id="sch" hidden>
    <div class="sch-head"><b>주간 일정</b><button class="sch-x" id="sch-x" aria-label="닫기">×</button></div>
    <div class="sch-days" id="sch-days"></div>
    <div class="sch-list" id="sch-list"></div>
    <div class="sch-todo">
      <div class="sch-todo-head"><button class="todo-nav" id="todo-prev" aria-label="전날">‹</button><b id="todo-title">오늘 할 일</b><button class="todo-nav" id="todo-next" aria-label="다음 날">›</button><span id="todo-count"></span></div>
      <form id="todo-form"><input id="todo-in" maxlength="80" placeholder="할 일을 적고 Enter" autocomplete="off"><button>추가</button></form>
      <ul id="todo-list"></ul>
      <button class="sch-carry" id="todo-carry" hidden></button>
    </div>
  </aside>`);

let days = [], view = new Date().getDay();
async function loadSchedule() {
  try { const r = await fetch('/api/schedule', { cache: 'no-store' }); if (r.ok) days = (await r.json()).days || []; } catch { days = []; }
  paint();
}
const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
function paint() {
  $('sch-days').innerHTML = ORDER.map((d) => `<button data-d="${d}" class="${d === view ? 'on' : ''} ${d === new Date().getDay() ? 'today' : ''}">${DAYS[d]}</button>`).join('');
  $('sch-days').querySelectorAll('button').forEach((b) => { b.onclick = () => { view = +b.dataset.d; todoOff = ORDER.indexOf(view) - ORDER.indexOf(new Date().getDay()); paint(); }; /* 요일을 고르면 할 일도 이번 주 그 날짜로 */ });
  const list = days[view] || [];
  const now = new Date(), nm = now.getHours() * 60 + now.getMinutes(), isToday = view === now.getDay();
  $('sch-list').innerHTML = list.length ? list.map(([a, b, title, cat]) => {
    const cur = isToday && nm >= toMin(a) && nm < toMin(b), past = isToday && nm >= toMin(b);
    return `<div class="sch-item c-${esc(cat)} ${cur ? 'now' : ''} ${past ? 'past' : ''}" title="${esc(CAT[cat] || '')}"><span class="t">${esc(a)}–${esc(b)}</span><span class="n">${esc(title)}</span>${cur ? '<em>지금</em>' : ''}</div>`;
  }).join('') : '<p class="sch-empty">스케줄을 불러오지 못했어요. ai-office 폴더에 schedule.json이 있는지 확인해 주세요.</p>';
  const cur = $('sch-list').querySelector('.now'); if (cur) cur.scrollIntoView({ block: 'center' });
  paintTodo();
}

// ---------- 오늘 할 일 ----------
let todoOff = 0; // 0 = 오늘, 1 = 내일 (화살표로 다른 날 할 일을 미리 쓰거나 지난 날을 본다)
const todoDate = () => { const d = new Date(); d.setDate(d.getDate() + todoOff); return d; };
const TKEY = () => `todo-${dateKey(todoDate())}`;
function paintTodoTitle() {
  const d = todoDate(), name = { '-1': '어제', 0: '오늘', 1: '내일' }[todoOff];
  $('todo-title').textContent = `${name ? `${name} ` : ''}${d.getMonth() + 1}/${d.getDate()}(${DAYS[d.getDay()]}) 할 일`;
  $('todo-in').placeholder = todoOff > 0 ? '미리 적어 둘 할 일을 적고 Enter' : '할 일을 적고 Enter';
}
$('todo-prev').onclick = () => { todoOff -= 1; view = todoDate().getDay(); paint(); }; // 할 일 날짜를 옮기면 위 일정도 그 요일로
$('todo-next').onclick = () => { todoOff += 1; view = todoDate().getDay(); paint(); };
function paintTodo() {
  paintTodoTitle();
  const items = load(TKEY(), []);
  $('todo-list').innerHTML = items.map((t, i) => `<li class="${t.done ? 'done' : ''}"><label><input type="checkbox" data-i="${i}" ${t.done ? 'checked' : ''}><span>${esc(t.text)}</span></label><button data-ed="${i}" class="mv" title="내용 고치기">수정</button><button data-mv="${i}" class="mv" title="다음 날로 옮기기">내일로</button><button data-del="${i}" aria-label="지우기">×</button></li>`).join('');
  const left = items.filter((t) => !t.done).length;
  $('todo-count').textContent = items.length ? `${items.length - left}/${items.length}` : '';
  $('todo-list').querySelectorAll('input[type=checkbox]').forEach((c) => { c.onchange = () => { const v = load(TKEY(), []).map((t, i) => (i === +c.dataset.i ? { ...t, done: c.checked } : t)); save(TKEY(), v); paintTodo(); }; });
  $('todo-list').querySelectorAll('[data-ed]').forEach((b) => { b.onclick = () => { // 글자 칸으로 바꿔 고치고 Enter(저장)·Esc(취소)
    const i = +b.dataset.ed, li = b.closest('li'), span = li.querySelector('label span'), cur = load(TKEY(), [])[i];
    const inp = document.createElement('input'); inp.className = 'todo-edit'; inp.value = cur.text; inp.maxLength = 80;
    span.replaceWith(inp); inp.focus(); inp.select();
    const done = (keep) => { if (keep && inp.value.trim()) save(TKEY(), load(TKEY(), []).map((t, k) => (k === i ? { ...t, text: inp.value.trim() } : t))); paintTodo(); };
    inp.onkeydown = (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); done(true); } if (ev.key === 'Escape') done(false); };
    inp.onblur = () => done(true); inp.onclick = (ev) => ev.preventDefault();
  }; });
  $('todo-list').querySelectorAll('[data-mv]').forEach((b) => { b.onclick = () => { // 보고 있는 날의 다음 날로 옮김
    const cur = load(TKEY(), []), it = cur[+b.dataset.mv], n = todoDate(); n.setDate(n.getDate() + 1);
    const nKey = `todo-${dateKey(n)}`;
    save(nKey, [...load(nKey, []), { text: it.text, done: false }]); save(TKEY(), cur.filter((_, i) => i !== +b.dataset.mv)); paintTodo();
  }; });
  $('todo-list').querySelectorAll('[data-del]').forEach((b) => { b.onclick = () => { save(TKEY(), load(TKEY(), []).filter((_, i) => i !== +b.dataset.del)); paintTodo(); }; });
  // 어제 못 한 일 가져오기
  const y = new Date(); y.setDate(y.getDate() - 1);
  const yKey = `todo-${dateKey(y)}`, undone = load(yKey, []).filter((t) => !t.done && !t.moved);
  $('todo-carry').hidden = !undone.length || todoOff !== 0; // 오늘 목록일 때만
  $('todo-carry').textContent = `어제 못 한 일 ${undone.length}개 가져오기`;
}
$('todo-carry').onclick = () => {
  const y = new Date(); y.setDate(y.getDate() - 1);
  const yKey = `todo-${dateKey(y)}`, prev = load(yKey, []);
  save(TKEY(), [...load(TKEY(), []), ...prev.filter((t) => !t.done && !t.moved).map((t) => ({ text: t.text, done: false }))]);
  save(yKey, prev.map((t) => (t.done ? t : { ...t, moved: true })));
  paintTodo();
};
$('todo-form').onsubmit = (ev) => {
  ev.preventDefault();
  const text = $('todo-in').value.trim(); if (!text) return;
  save(TKEY(), [...load(TKEY(), []), { text, done: false }]); $('todo-in').value = ''; paintTodo();
};

// ---------- 열고 닫기 ----------
function setOpen(o) {
  $('sch').hidden = !o; $('sch-tab').setAttribute('aria-expanded', String(o)); $('sch-tab').classList.toggle('on', o);
  save('sch-open', o);
  if (o) { view = new Date().getDay(); todoOff = 0; loadSchedule(); }
}
$('sch-tab').onclick = () => setOpen($('sch').hidden);
$('sch-x').onclick = () => setOpen(false);
setInterval(() => { if (!$('sch').hidden) paint(); }, 60000); // 1분마다 '지금' 위치 갱신
if (load('sch-open', false)) setOpen(true);
