// 도트 아트. 사무실 전체를 그림책 같은 부드러운 도트 화풍으로 그린다.
// - 외곽선: 2칸 두께, 갈색 계열 (재질 그림자색에 캐릭터 갈색을 섞음)
// - 선: 곧은 직선과 계단이 고른 곡선 (흔들림 없음, 픽셀 중심 판정, 동심 외곽선). 손그림 느낌은 둥근 모서리와 갈색 선으로만.
// - 명암: 2~3단, 빛은 왼쪽 위 하나, 그림자는 소품 실루엣을 오른쪽 아래로 민 모양.
// - 채도 낮게 (화면에서 캐릭터 흰색이 가장 밝게), 질감 최소, 긴 판자.
// - 구역 구분: 구역마다 바닥색을 조금씩 다르게 (저채도 안에서), 2칸 테두리.
// 배치는 allProps() 한 목록을 렌더러와 바닥 그림자가 함께 쓴다. 바닥, 벽, 창문, 유리벽, 입구, 그림자는 worldArt() 한 장으로 굽는다.
import {
  WORLD, WALL_Y, DOOR_GAP, ENTRANCE, ROOMS, TEAMS, roomById, SOFA, COFFEE, CEO_SEAT, ASSIST_SEAT, MEETING_TABLE,
  PRINTER, BOOKSHELF, WATER, COMMON_TABLE, HALL_PLANTS, REPORT_SPOTS, MEETING_SEATS, CAFE_TABLES, STAGE,
} from './data.js';

// 바닥 무늬: 'long' = 긴 판자 + 드문 이음매(기본), 'plain' = 무늬 거의 없음 (비교용)
export const ART_OPTS = { floor: 'long' };
export function setFloorStyle(v) { ART_OPTS.floor = v; spr.delete('world'); }

const INK = '#4A342C'; // 캐릭터 외곽선
const hexv = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mix = (a, b, t) => { const A = hexv(a), B = hexv(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join('').toUpperCase(); };
// 재질: 기본(b), 그림자(s), 밝은면(l). 외곽선(o)은 그림자에 캐릭터 갈색을 70% 섞는다.
const mat = (b, s, l) => ({ b, s, l, o: mix(s, INK, 0.72) });
export const RAMPS = {
  wood:   mat('#EAD3B4', '#D9BC98', '#F2E2CB'),
  woodDk: mat('#DCC0A0', '#C9A988', '#E6CFB3'),
  sofa:   mat('#F5B8C8', '#E89DB1', '#FAD0DB'),
  leaf:   mat('#F7C3D2', '#EBA6BB', '#FBD9E3'),
  pot:    mat('#E6BBA4', '#D4A38B', '#EECDBA'),
  metal:  mat('#D2CACD', '#BBB1B6', '#E0DADC'),
  white:  mat('#F3EDE7', '#E2D9D1', '#F7F2ED'),
  screen: mat('#D3E5EE', '#BDD5E2', '#E2EEF4'),
  cork:   mat('#E7D0AF', '#D8BD98', '#EEDCC2'),
  coffee: mat('#9E7E68', '#8A6B56', '#B0937D'),
  glass:  mat('#E1EEF2', '#CFE1E8', '#F0F7F9'),
  trim:   mat('#E7D9C7', '#D8C6B0', '#F0E6D8'),
  plaster: mat('#EFE7DC', '#E2D7C8', '#F5EFE7'),
  sky:    mat('#E1EEF3', '#D2E5EC', '#ECF5F8'),
  gold:   mat('#E8D29A', '#D6BC7E', '#F1E2BB'),
  paper:  mat('#F4EFE8', '#E5DDD3', '#F8F4EF'),
};
// 바닥색 (구역마다 조금씩 다르게, 저채도 안에서). kind: plank(긴 판자) / carpet(점 카펫) / tile(큰 타일)
export const ZONE_FLOOR = {
  hall:    { kind: 'plank', b: '#FBF1EE' },
  ceo:     { kind: 'carpet', b: '#F9D7E0' },
  meeting: { kind: 'plank', b: '#F6E4EC' },
  edu:     { kind: 'carpet', b: '#FBE6EA' },
  dev:     { kind: 'carpet', b: '#F1E3F2' },
  cplan:   { kind: 'carpet', b: '#FADCE3' },
  cmake:   { kind: 'carpet', b: '#FBE3E8' },
  ops:     { kind: 'carpet', b: '#FFF0E8' },
  mkt:     { kind: 'carpet', b: '#F4E5EE' },
  lounge:  { kind: 'plank', b: '#F8E6E4' },
  fin:     { kind: 'carpet', b: '#E6F4EC' },
};
const BROWN = '#8A6B56';
const floorPal = (b) => ({ b, b2: mix(b, BROWN, 0.02), seam: mix(b, BROWN, 0.07), faint: mix(b, BROWN, 0.045), motif: mix(b, BROWN, 0.06), band: mix(b, BROWN, 0.08), o: mix(mix(b, '#7A5A48', 0.25), INK, 0.72) });
const FLOOR = { rug: { b: '#FCE3EA', ring: '#F5C9D6', o: mix('#E6A9BB', INK, 0.72) } };

// ---------- 도트 버퍼 (정수 저장: 사무실 전체 한 장도 가볍게) ----------
const C2I = new Map(), I2C = new Map();
const ci = (c) => { let v = C2I.get(c); if (v === undefined) { v = (parseInt(c.slice(1), 16) + 1) | 0; C2I.set(c, v); if (!I2C.has(v)) I2C.set(v, '#' + c.slice(1).toUpperCase()); } return v; };
// o = 원점 이동(칸). 사무실 한 장은 바깥 숲 테두리만큼 원점을 옮겨 두고, 그리는 코드는 사무실 좌표 그대로 쓴다.
class Dots {
  constructor(w, h, o = 0) { this.w = w; this.h = h; this.o = o; this.p = new Int32Array(w * h); }
  set(x, y, c) { x = (x | 0) + this.o; y = (y | 0) + this.o; if (c && x >= 0 && y >= 0 && x < this.w && y < this.h) this.p[y * this.w + x] = ci(c); }
  get(x, y) { x = (x | 0) + this.o; y = (y | 0) + this.o; if (x < 0 || y < 0 || x >= this.w || y >= this.h) return null; const v = this.p[y * this.w + x]; return v ? I2C.get(v) : null; }
  canvas() {
    const c = document.createElement('canvas');
    c.width = this.w; c.height = this.h;
    const g = c.getContext('2d'), img = g.createImageData(this.w, this.h), seen = new Set();
    for (let i = 0; i < this.p.length; i++) {
      const v = this.p[i];
      if (!v) continue;
      const rgb = v - 1; seen.add(rgb);
      img.data[i * 4] = rgb >> 16; img.data[i * 4 + 1] = (rgb >> 8) & 255; img.data[i * 4 + 2] = rgb & 255; img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    c.colors = seen.size;
    return c;
  }
}
const h2 = (x, y, s = 0) => { let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0; h = (h ^ (h >>> 13)) * 1274126177; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
const shadeCache = new Map();
const shadowOf = (c) => { let s = shadeCache.get(c); if (!s) { s = mix(c, '#7A5A48', 0.12); shadeCache.set(c, s); } return s; };

// ---------- 깨끗한 도형 판정 (픽셀 중심 기준, 좌우 위아래 대칭) ----------
// 직선은 끊김 없이 곧게, 둥근 모서리와 타원은 계단이 고르게. 흔들림(손그림 잡음) 없음.
// 2칸 외곽선 = 바깥 도형 안 + 2칸 안쪽으로 줄인 같은 도형 밖 (동심 곡선이라 겹친 점이 생기지 않는다)
function rrect(x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  return (px, py) => {
    const cx = px + 0.5, cy = py + 0.5;
    if (cx < x || cx > x + w || cy < y || cy > y + h) return false;
    const dx = Math.max(0, x + r - cx, cx - (x + w - r)), dy = Math.max(0, y + r - cy, cy - (y + h - r));
    return dx * dx + dy * dy <= r * r;
  };
}
function oval(cx, cy, rx, ry) {
  return (px, py) => { if (rx <= 0 || ry <= 0) return false; const nx = (px + 0.5 - cx) / rx, ny = (py + 0.5 - cy) / ry; return nx * nx + ny * ny <= 1; };
}
// 영역 칠하기: outer 안, inner(2칸 안쪽) 밖이면 외곽선. 나머지는 shade
function paint(D, x0, y0, x1, y1, outer, inner, M, shade) {
  for (let py = y0; py <= y1; py++) for (let px = x0; px <= x1; px++) {
    if (!outer(px, py)) continue;
    D.set(px, py, inner(px, py) ? shade(px, py) : M.o);
  }
}
// 둥근 상자. dark = 아래 그림자 줄 수, lit = 위 밝은 줄 수(기본 0). 음영 경계도 곧은 가로줄과 같은 반지름의 곡선.
function box(D, x, y, w, h, M, o = {}) {
  const r = o.r ?? 5, dark = o.dark ?? 4, lit = o.lit ?? 0;
  const outer = rrect(x, y, w, h, r), inner = rrect(x + 2, y + 2, w - 4, h - 4, r - 2);
  const body = rrect(x + 2, y + 2, w - 4 - 2, h - 4 - dark, r - 2);           // 그림자 아닌 부분: 아래 dark줄, 오른쪽 2줄 비움
  paint(D, x - 1, y - 1, x + w, y + h, outer, inner, M, (px, py) => {
    if (!body(px, py)) return M.s;
    if (lit && py < y + 2 + lit) return M.l;
    return M.b;
  });
}
// 타원. 오른쪽 아래가 그림자: 왼쪽 위로 민 같은 타원 밖이면 그림자 (경계도 곡선)
function ellipse(D, cx, cy, rx, ry, M, o = {}) {
  const c = o.cres ?? 0.2;
  const outer = oval(cx, cy, rx, ry), inner = oval(cx, cy, rx - 2, ry - 2);
  const lightPart = oval(cx - (rx - 2) * c * 0.7, cy - (ry - 2) * c, rx - 2, ry - 2);
  paint(D, Math.floor(cx - rx - 1), Math.floor(cy - ry - 1), Math.ceil(cx + rx + 1), Math.ceil(cy + ry + 1), outer, inner, M, (px, py) => (lightPart(px, py) ? M.b : M.s));
}
function line(D, x0, y0, x1, y1, c) { // 곧은 가는 선 (가로나 세로만 쓴다)
  for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) D.set(x, y, c);
}
// 소품 실루엣 그림자: 소품 모양을 오른쪽 아래로 민 자리의 바닥을 한 단계 진하게 (한 칸은 한 번만)
function castFromArt(D, a, dx, dy, done, ox = 3, oy = 4) {
  const S = a.D;
  for (let j = 0; j < S.h; j++) for (let i = 0; i < S.w; i++) {
    if (!S.p[j * S.w + i]) continue;
    const px = dx + i + ox, py = dy + j + oy, at = (py + D.o) * D.w + px + D.o;
    const c = D.get(px, py); if (!c || done[at]) continue;
    done[at] = 1; D.set(px, py, shadowOf(c));
  }
}

// ---------- 바닥 무늬 (반복, 이음매 없음, 연하게) ----------
// 모두 (x0, y0) 기준 칸 좌표의 주기 무늬라 구역이 어디 있든 이음매가 같은 규칙으로 이어진다.
function plankAt(px, py, seed, F) { // 긴 판자: 줄 간격 18칸, 길이 300~420칸, 끝 이음매 드문드문
  const PH = 18, row = Math.floor(py / PH), iy = py % PH, plain = ART_OPTS.floor === 'plain';
  if (iy === 0) return plain ? F.faint : F.seam;
  const len = 300 + Math.floor(h2(row, 3, seed) * 120), off = Math.floor(h2(row, 7, seed) * len);
  const sx = px + off, seg = Math.floor(sx / len);
  if (!plain && sx % len === 0) return F.seam;
  return plain ? F.b : (h2(seg, row, seed) < 0.5 ? F.b : F.b2);
}
function carpetAt(px, py, F) { // 32칸 주기로 작은 점 하나 (드문드문, 대비 낮게)
  const mx = ((px + 16) % 32) - 16, my = (((py + (Math.floor((px + 16) / 32) % 2) * 16) + 16) % 32) - 16;
  return Math.abs(mx) + Math.abs(my) <= 1 ? F.motif : F.b;
}
function tileAt(px, py, F) { // 36칸 큰 타일, 줄눈은 연하게
  return px % 36 === 0 || py % 36 === 0 ? F.seam : F.b;
}
// 구역 바닥: 둥근 모서리 사각형 안을 무늬로 채우고 2칸 테두리 (카펫은 테두리 안쪽에 띠 한 줄)
function paintZone(D, x0, y0, w, h, spec, seed) {
  const F = floorPal(spec.b), r = 9;
  const outer = rrect(x0, y0, w, h, r), inner = rrect(x0 + 2, y0 + 2, w - 4, h - 4, r - 2), field = rrect(x0 + 5, y0 + 5, w - 10, h - 10, r - 5);
  for (let py = y0; py < y0 + h; py++) for (let px = x0; px < x0 + w; px++) {
    if (!outer(px, py)) continue;
    let c;
    if (!inner(px, py)) c = F.o;
    else if (spec.kind === 'carpet' && !field(px, py)) c = F.band;
    else if (spec.kind === 'plank') c = plankAt(px - x0, py - y0, seed, F);
    else if (spec.kind === 'tile') c = tileAt(px - x0, py - y0, F);
    else c = carpetAt(px - x0, py - y0, F);
    D.set(px, py, c);
  }
}
function ovalRug(D, cx, cy, rx, ry) {
  const F = FLOOR.rug;
  const outer = oval(cx, cy, rx, ry), inner = oval(cx, cy, rx - 2, ry - 2);
  const ring = oval(cx, cy, rx * 0.82, ry * 0.82), ringIn = oval(cx, cy, rx * 0.82 - 1, ry * 0.82 - 1);
  for (let py = Math.floor(cy - ry - 1); py <= cy + ry + 1; py++) for (let px = Math.floor(cx - rx - 1); px <= cx + rx + 1; px++) {
    if (!outer(px, py)) continue;
    let c = F.b;
    if (!inner(px, py)) c = F.o;
    else if (ring(px, py) && !ringIn(px, py)) c = F.ring;
    D.set(px, py, c);
  }
  // 빈 러그에 작은 꽃 무늬 고리 (4칸 꽃잎 + 가운데, 고리 안쪽 0.62 반지름을 따라 고르게)
  const n = Math.max(8, Math.round((rx + ry) / 14));
  for (let k = 0; k < n; k++) {
    const t = (k / n) * Math.PI * 2, fx = Math.round(cx + Math.cos(t) * rx * 0.62), fy = Math.round(cy + Math.sin(t) * ry * 0.62);
    for (const [dx, dy] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(fx + dx + a, fy + dy + b, F.ring);
    for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(fx + a, fy + b, F.o);
  }
}
// 팀 러그: 책상 줄 밑에 둥근 네모 러그. 팀 색을 바닥색에 조금만 섞은 바탕 + 테두리 띠 + 안쪽 가는 선 (질감 없음)
function teamRug(D, x, y, w, h, floorB, tint) {
  const b = mix(floorB, tint, 0.06), band = mix(floorB, tint, 0.15), o = mix(mix(band, '#7A5A48', 0.25), INK, 0.72); // 채도 낮게 (캐릭터 흰색이 가장 밝게)
  const outer = rrect(x, y, w, h, 12), inner = rrect(x + 2, y + 2, w - 4, h - 4, 10), field = rrect(x + 9, y + 9, w - 18, h - 18, 6), line2 = rrect(x + 13, y + 13, w - 26, h - 26, 4), line2in = rrect(x + 15, y + 15, w - 30, h - 30, 3);
  for (let py = y; py < y + h; py++) for (let px = x; px < x + w; px++) {
    if (!outer(px, py)) continue;
    D.set(px, py, !inner(px, py) ? o : !field(px, py) ? band : line2(px, py) && !line2in(px, py) ? band : b);
  }
}
// 띠 모양(벽): ins 안, 2칸 안쪽까지 외곽선. 직선만 쓰므로 4방향 2칸 이웃 판정으로 충분하다.
function paintBand(D, x0, y0, x1, y1, ins, M, lit = true) {
  for (let py = y0; py <= y1; py++) for (let px = x0; px <= x1; px++) {
    if (!ins(px, py)) continue;
    const edge = !ins(px - 1, py) || !ins(px + 1, py) || !ins(px, py - 1) || !ins(px, py + 1) || !ins(px - 2, py) || !ins(px + 2, py) || !ins(px, py - 2) || !ins(px, py + 2);
    D.set(px, py, edge ? M.o : (lit && !ins(px, py - 3)) ? M.l : M.b);
  }
}

// ---------- 소품 스프라이트 ----------
const spr = new Map();
const memo = (key, f) => { let v = spr.get(key); if (!v) { v = f(); spr.set(key, v); } return v; };

export function deskArt(team, on, deco) {
  return memo(`desk|${team}|${on}|${deco || ''}`, () => {
    const W = 128, H = 50, D = new Dots(W, H), wd = RAMPS.wood, dk = RAMPS.woodDk;
    box(D, 2, 26, W - 4, 22, dk, { r: 4, dark: 3 });                     // 앞판
    line(D, W / 2, 31, W / 2, 42, dk.s, 2);
    for (const x of [W / 2 - 10, W / 2 + 8]) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + dx, 36 + dy, dk.o);
    box(D, 2, 2, W - 4, 30, wd, { r: 6, dark: 3, lit: 1 });              // 상판
    // 노트북 (뒷면)
    box(D, 14, 21, 44, 8, RAMPS.white, { r: 3, dark: 2 });
    box(D, 17, 3, 38, 21, RAMPS.white, { r: 4, dark: 3 });
    if (on) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(48 + dx, 17 + dy, '#9BD3AE');
    // 서류
    box(D, 66, 11, 24, 15, RAMPS.white, { r: 2, dark: 2 });
    line(D, 71, 17, 84, 17, RAMPS.white.s, 4); line(D, 71, 20, 81, 20, RAMPS.white.s, 6);
    // 머그 (팀 색 띠, 채도 낮게)
    const tc = mix(TEAMS[team] && TEAMS[team].tint || '#F28CA8', '#F3EDE7', 0.35);
    box(D, 98, 6, 15, 19, RAMPS.white, { r: 3, dark: 2 });
    for (let py = 13; py < 17; py++) for (let px = 101; px < 110; px++) D.set(px, py, tc);
    for (let px = 101; px < 110; px++) D.set(px, 9, '#B39A86');
    for (let py = 11; py < 20; py++) { D.set(114, py, RAMPS.white.o); D.set(115, py, RAMPS.white.o); }
    if (deco === 'plant') { // 책상 위 작은 화분 (왼쪽 위 빈 자리)
      ellipse(D, 9, 6, 6, 5, RAMPS.leaf);
      box(D, 4, 9, 11, 11, RAMPS.pot, { r: 3, dark: 2 });
    }
    return { D, cv: D.canvas(), ax: 64, ay: 28 };
  });
}

export function plantArt(big) {
  return memo(`plant|${big}`, () => {
    const W = big ? 74 : 58, H = big ? 106 : 86, D = new Dots(W, H), cx = Math.floor(W / 2);
    const pw = big ? 34 : 26, ph = big ? 30 : 24, py0 = H - ph - 2;
    const L = RAMPS.leaf, k = big ? 1.25 : 1, base = py0 - 1;
    for (const [dx, dy, rx, ry] of [[0, -36, 12, 10], [-13, -22, 13, 11], [13, -22, 13, 11], [0, -12, 16, 11]]) ellipse(D, cx + dx * k, base + dy * k, rx * k, ry * k, L);
    box(D, cx - pw / 2, py0, pw, ph, RAMPS.pot, { r: 4, dark: 4 });
    box(D, cx - pw / 2 - 3, py0 - 3, pw + 6, 9, RAMPS.pot, { r: 4, dark: 2, lit: 1 });
    return { D, cv: D.canvas(), ax: cx, ay: H - 2 };
  });
}

export function sofaArt() {
  return memo('sofa', () => {
    const W = SOFA.w * 3 + 12, H = SOFA.h * 3 + 10, D = new Dots(W, H), F = RAMPS.sofa;
    for (const x of [16, W - 24]) box(D, x, H - 11, 8, 10, RAMPS.woodDk, { r: 2, dark: 2 });
    box(D, 8, 2, W - 16, 44, F, { r: 12, dark: 5, lit: 1 });             // 등받이
    box(D, 8, 34, W - 16, H - 44, F, { r: 9, dark: 6 });                // 앉는 판
    const cw = Math.round((W - 48) / 2);
    for (let k = 0; k < 2; k++) box(D, 24 + k * (cw + 1), 32, cw, 38, F, { r: 10, dark: 5, lit: 1 });
    box(D, 1, 18, 24, H - 28, F, { r: 10, dark: 6, lit: 1 });          // 팔걸이
    box(D, W - 25, 18, 24, H - 28, F, { r: 10, dark: 6, lit: 1 });
    // 쿠션 두 개 (팔걸이 쪽, 앉는 자리는 비워 둔다)
    box(D, 26, 20, 30, 28, mat('#EDD8CE', '#DDC3B7', '#F3E4DC'), { r: 8, dark: 4, lit: 1 });
    box(D, W - 56, 22, 30, 28, mat('#D9E1E7', '#C4CFD8', '#E4EAEF'), { r: 8, dark: 4, lit: 1 });
    return { D, cv: D.canvas(), ax: 6, ay: 0 };
  });
}

export function roundTableArt(cupTint, cookies) {
  return memo(`table|${cupTint}|${!!cookies}`, () => {
    const W = 88, H = 58, D = new Dots(W, H), wd = RAMPS.wood, dk = RAMPS.woodDk;
    box(D, 38, 26, 12, 24, dk, { r: 3, dark: 2 });
    ellipse(D, 44, 51, 16, 5, dk, { cres: 0.35 });
    ellipse(D, 44, 21, 40, 16, wd, { cres: 0.14 });
    if (cookies) { // 간식 접시
      ellipse(D, 58, 21, 13, 6, RAMPS.white, { cres: 0.25 });
      for (const [x, y] of [[53, 20], [62, 19], [58, 23]]) ellipse(D, x, y, 4, 3, mat('#E2C29C', '#D0AC82', '#ECD3B4'), { cres: 0.3 });
    }
    for (const [x, y, t] of (cookies ? [[28, 15, null]] : [[28, 15, null], [58, 21, cupTint]])) {
      box(D, x - 7, y - 5, 14, 13, RAMPS.white, { r: 4, dark: 2 });
      for (let px = x - 3; px < x + 3; px++) D.set(px, y - 2, '#B39A86');
      if (t) for (let px = x - 4; px < x + 4; px++) { D.set(px, y + 3, mix(t, '#F3EDE7', 0.35)); D.set(px, y + 4, mix(t, '#F3EDE7', 0.35)); }
    }
    return { D, cv: D.canvas(), ax: 44, ay: 21 };
  });
}

export function coffeeArt() {
  return memo('coffee', () => {
    const W = 198, H = 98, D = new Dots(W, H), M = RAMPS.metal;
    box(D, 76, 36, 120, 60, RAMPS.woodDk, { r: 5, dark: 5 });           // 카운터 앞
    line(D, 116, 44, 116, 88, RAMPS.woodDk.s, 3); line(D, 156, 44, 156, 88, RAMPS.woodDk.s, 5);
    box(D, 76, 26, 120, 18, RAMPS.wood, { r: 5, dark: 2, lit: 1 });      // 상판
    const cups = ['#F28CA8', '#8DD3EE', '#F6D364'];
    for (let k = 0; k < 3; k++) {
      const x = 94 + k * 18;
      box(D, x - 7, 11, 14, 17, RAMPS.white, { r: 4, dark: 2 });
      for (let px = x - 4; px < x + 4; px++) { D.set(px, 17, mix(cups[k], '#F3EDE7', 0.35)); D.set(px, 18, mix(cups[k], '#F3EDE7', 0.35)); }
    }
    box(D, 150, 7, 22, 22, RAMPS.white, { r: 6, dark: 3 });             // 원두 통
    ellipse(D, 161, 17, 5, 5, RAMPS.coffee, { cres: 0.25 });
    ellipse(D, 182, 18, 9, 8, RAMPS.leaf);                            // 작은 잎
    box(D, 1, 1, 68, 94, M, { r: 8, dark: 5, lit: 1 });                  // 커피머신
    box(D, 10, 9, 50, 18, RAMPS.screen, { r: 4, dark: 2 });
    box(D, 12, 36, 46, 40, mat('#A79DA2', '#958A90', '#B4ABAF'), { r: 6, dark: 2 });
    box(D, 26, 52, 18, 22, RAMPS.white, { r: 4, dark: 3 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}

export function corkArt() {
  return memo('cork', () => {
    const W = 122, H = 72, D = new Dots(W, H), C = RAMPS.cork;
    for (const x of [16, W - 20]) box(D, x, H - 10, 6, 9, RAMPS.woodDk, { r: 2, dark: 2 });
    box(D, 1, 1, W - 2, H - 8, RAMPS.wood, { r: 6, dark: 3, lit: 1 });   // 나무 틀
    box(D, 7, 7, W - 14, H - 20, C, { r: 3, dark: 2 });                  // 코르크
    for (let i = 0; i < 18; i++) { const x = 12 + Math.floor(h2(i, 1, 9) * (W - 26)), y = 12 + Math.floor(h2(i, 2, 9) * (H - 32)); D.set(x, y, C.s); } // 알갱이 몇 개
    const notes = [[14, 12, '#FFD6DF'], [46, 15, '#D3E8FA'], [80, 11, '#FFF0BC'], [26, 32, '#D8F0D6'], [64, 34, '#FFD6DF']];
    for (const [x, y, t] of notes) {
      const N = mat(mix(t, '#F3EDE7', 0.35), mix(mix(t, '#F3EDE7', 0.35), '#8A6B56', 0.12), mix(t, '#F3EDE7', 0.55));
      box(D, x, y, 26, 18, N, { r: 2, dark: 2 });
      line(D, x + 6, y + 9, x + 19, y + 9, N.s, x);
      ellipse(D, x + 13, y + 3, 2.2, 2.2, mat('#E7A3AE', '#D38A96', '#F1BEC6'), { cres: 0.3 });
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}

// ---------- 작은 소품 (흩어 두는 것: 캐릭터 동선 밖, 캐릭터보다 눈에 덜 띄게) ----------
const KRAFT = mat('#E3CBA8', '#D1B58F', '#ECD8BC');
export function slippersArt() {
  return memo('slippers', () => {
    // 옆으로 놓인 슬리퍼 한 켤레: 앞쪽 3분의 1에 발등 끈
    const D = new Dots(34, 30), S = mat('#EFDCDC', '#DEC4C4', '#F5E7E7'), Bd = mat('#E3C1C4', '#D1A9AD', '#EDD3D5');
    for (const [x, y] of [[1, 2], [6, 16]]) {
      box(D, x, y, 27, 13, S, { r: 6, dark: 2, lit: 1 });
      box(D, x + 14, y - 1, 8, 15, Bd, { r: 2, dark: 2 });   // 발등 끈
    }
    return { D, cv: D.canvas(), ax: 17, ay: 30 };
  });
}
export function bookStackArt(v = 0) {
  return memo(`books|${v}`, () => {
    const D = new Dots(40, 30), cols = v ? ['#D8E3D0', '#EAD7C3', '#DCD6E8'] : ['#D6E1EA', '#F0D6DB', '#EEE2C4'];
    [[3, 20, 34], [6, 12, 30], [2, 4, 32]].forEach(([x, y, w], k) => {
      const c = cols[k], M = mat(c, mix(c, '#8A6B56', 0.14), mix(c, '#FFFFFF', 0.3));
      box(D, x, y, w, 10, M, { r: 2, dark: 2 });
      for (let px = x + w - 8; px < x + w - 2; px++) { D.set(px, y + 4, '#F7F2EC'); D.set(px, y + 5, '#F7F2EC'); }
    });
    return { D, cv: D.canvas(), ax: 20, ay: 30 };
  });
}
export function lampArt() {
  return memo('lamp', () => {
    const D = new Dots(36, 76), M = mat('#CDBFB2', '#B8A89A', '#DACFC4');
    ellipse(D, 18, 71, 10, 4, M, { cres: 0.3 });
    box(D, 16, 24, 4, 46, M, { r: 1, dark: 0 });
    box(D, 3, 2, 30, 24, mat('#F2E6CF', '#E2D2B6', '#F7EFDF'), { r: 8, dark: 4, lit: 2 });
    return { D, cv: D.canvas(), ax: 18, ay: 76 };
  });
}
export function basketArt() {
  return memo('basket', () => {
    const D = new Dots(30, 28), B = mat('#DCC3A2', '#C9AC88', '#E6D3B9');
    box(D, 9, 0, 9, 14, mat('#D6E1EA', '#C1CFDA', '#E2EAF0'), { r: 2, dark: 2 });
    box(D, 15, 2, 9, 12, mat('#F0D6DB', '#DFC0C6', '#F5E3E6'), { r: 2, dark: 2 });
    box(D, 2, 10, 26, 18, B, { r: 4, dark: 3 });
    for (let px = 6; px < 25; px += 5) for (let py = 13; py < 24; py++) D.set(px, py, B.s);
    return { D, cv: D.canvas(), ax: 15, ay: 28 };
  });
}
export function plushArt() {
  return memo('plush', () => {
    const D = new Dots(28, 28), P = mat('#EADFD3', '#D9CBBD', '#F2EAE2');
    ellipse(D, 7, 7, 5, 5, P); ellipse(D, 21, 7, 5, 5, P);
    ellipse(D, 14, 16, 12, 11, P, { cres: 0.22 });
    for (const x of [10, 18]) { D.set(x, 15, INK); D.set(x, 16, INK); }
    for (const x of [7, 20]) { D.set(x, 19, '#EDBFC4'); D.set(x + 1, 19, '#EDBFC4'); }
    return { D, cv: D.canvas(), ax: 14, ay: 28 };
  });
}
export function boxStackArt() {
  return memo('boxes', () => {
    const D = new Dots(44, 44);
    box(D, 1, 18, 36, 26, KRAFT, { r: 3, dark: 4, lit: 1 });
    box(D, 9, 2, 32, 20, KRAFT, { r: 3, dark: 3, lit: 1 });
    for (let py = 20; py < 42; py++) { D.set(18, py, '#EFE3CF'); D.set(19, py, '#EFE3CF'); }
    for (let py = 4; py < 20; py++) { D.set(24, py, '#EFE3CF'); D.set(25, py, '#EFE3CF'); }
    return { D, cv: D.canvas(), ax: 22, ay: 44 };
  });
}
export function binArt() {
  return memo('bin', () => {
    const D = new Dots(24, 30), B = mat('#D3DCE0', '#BDC9CF', '#E0E7EA');
    box(D, 3, 6, 18, 24, B, { r: 4, dark: 4 });
    box(D, 1, 4, 22, 6, B, { r: 3, dark: 1, lit: 1 });
    ellipse(D, 12, 4, 6, 4, RAMPS.white, { cres: 0.3 });
    return { D, cv: D.canvas(), ax: 12, ay: 30 };
  });
}

export function floorCushionArt() {
  return memo('zabuton', () => {
    const D = new Dots(36, 28), C = mat('#EAD9C8', '#D9C3AE', '#F1E5D9');
    box(D, 1, 1, 34, 26, C, { r: 9, dark: 4, lit: 1 });
    for (const [x, y] of [[17, 13]]) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + dx, y + dy, C.o);
    return { D, cv: D.canvas(), ax: 18, ay: 28 };
  });
}
export function cactusArt() {
  return memo('cactus', () => {
    const D = new Dots(24, 36), L = mat('#C3D8AE', '#A8C292', '#D4E4C4');
    box(D, 7, 2, 10, 20, L, { r: 5, dark: 2 });
    box(D, 1, 9, 7, 9, L, { r: 3, dark: 2 });
    box(D, 4, 22, 16, 13, RAMPS.pot, { r: 3, dark: 3 });
    return { D, cv: D.canvas(), ax: 12, ay: 36 };
  });
}

// ---------- 구역별 큰 소품 ----------
const COFFEE_DOT = ['#4A2E20', '#5E3A26', '#6E4530', '#7E5236', '#8E6040', '#A0724E'];
export function ceoDeskArt(on) {
  return memo(`ceodesk|${on}`, () => {
    const W = 220, H = 54, D = new Dots(W, H), wd = mat('#E3C6A2', '#D2AF88', '#EDD7BC'), dk = mat('#D6B590', '#C39F78', '#E2C8A8');
    box(D, 2, 28, W - 4, 24, dk, { r: 4, dark: 3 });
    for (const x of [72, 146]) line(D, x, 33, x, 46, dk.s);
    for (const x of [36, 110, 182]) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + dx, 39 + dy, dk.o);
    box(D, 2, 2, W - 4, 32, wd, { r: 7, dark: 3, lit: 1 });
    box(D, 20, 22, 48, 8, RAMPS.white, { r: 3, dark: 2 });                 // 노트북 뒷면
    box(D, 23, 3, 42, 21, RAMPS.white, { r: 4, dark: 3 });
    if (on) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(58 + dx, 18 + dy, '#9BD3AE');
    for (let k = 2; k >= 0; k--) box(D, 84 + k, 9 + k * 2, 26, 15, RAMPS.paper, { r: 2, dark: 2 }); // 서류
    box(D, 124, 15, 38, 11, RAMPS.gold, { r: 2, dark: 2, lit: 1 });      // 명패
    line(D, 132, 20, 154, 20, RAMPS.gold.s);
    box(D, 176, 6, 15, 19, RAMPS.white, { r: 3, dark: 2 });              // 머그
    for (let px = 179; px < 188; px++) D.set(px, 9, '#B39A86');
    ellipse(D, 203, 10, 7, 6, RAMPS.leaf); box(D, 197, 13, 13, 12, RAMPS.pot, { r: 3, dark: 2 }); // 작은 화분
    return { D, cv: D.canvas(), ax: 110, ay: 28 };
  });
}
export function assistDeskArt(on) {
  return memo(`jdesk|${on}`, () => {
    const W = 160, H = 50, D = new Dots(W, H), top = mat('#E4E7EC', '#D2D7DF', '#EFF1F4'), front = mat('#D8DDE5', '#C5CCD7', '#E4E8EE');
    box(D, 2, 26, W - 4, 22, front, { r: 4, dark: 3 });
    line(D, W / 2, 31, W / 2, 42, front.s);
    box(D, 2, 2, W - 4, 30, top, { r: 7, dark: 3, lit: 1 });
    box(D, 14, 21, 44, 8, RAMPS.white, { r: 3, dark: 2 });
    box(D, 17, 3, 38, 21, RAMPS.white, { r: 4, dark: 3 });
    if (on) for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(48 + dx, 17 + dy, '#9BD3AE');
    box(D, 70, 10, 30, 16, mat('#DCE6F0', '#C8D6E4', '#E8EFF6'), { r: 2, dark: 2 });   // 서류함
    box(D, 74, 7, 22, 6, RAMPS.paper, { r: 1, dark: 1 });
    box(D, 112, 4, 22, 22, mat('#C9D9EB', '#B4C8DE', '#DAE6F2'), { r: 8, dark: 3 });   // 수화기 받침
    box(D, 140, 8, 12, 17, RAMPS.white, { r: 3, dark: 2 });
    return { D, cv: D.canvas(), ax: 80, ay: 27 };
  });
}
export function meetingTableArt() {
  return memo('mtable', () => {
    const W = MEETING_TABLE.w * 3 + 12, H = MEETING_TABLE.h * 3 + 14, D = new Dots(W, H), wd = mat('#E6CBA6', '#D5B48D', '#EFDAC0'), dk = mat('#D8B994', '#C5A27C', '#E3CAAB');
    box(D, 6, 16, W - 12, H - 18, dk, { r: 8, dark: 4 });
    box(D, 6, 6, W - 12, H - 22, wd, { r: 10, dark: 3, lit: 1 });
    for (const s of MEETING_SEATS.filter((q) => q.side === 'far')) {
      const x = Math.round(W / 2 + 4 + (s.x - MEETING_TABLE.x - MEETING_TABLE.w / 2) * 3);
      box(D, x - 14, 18, 28, 20, RAMPS.paper, { r: 2, dark: 2 });
      line(D, x - 8, 25, x + 8, 25, RAMPS.paper.s); line(D, x - 8, 29, x + 4, 29, RAMPS.paper.s);
      box(D, x + 20, 16, 12, 13, RAMPS.white, { r: 3, dark: 2 });
      for (let px = x + 23; px < x + 29; px++) D.set(px, 19, '#B39A86');
    }
    box(D, W / 2 - 9, 26, 18, 26, mat('#DCEAF0', '#C8DCE6', '#EAF3F7'), { r: 5, dark: 3, lit: 1 }); // 물병
    return { D, cv: D.canvas(), ax: 6, ay: 6 };
  });
}
export function whiteboardArt() {
  return memo('wboard', () => {
    const W = 276, H = 50, D = new Dots(W, H);
    box(D, 0, 0, W, H, mat('#F5F3EF', '#E6E1DA', '#FAF8F5'), { r: 4, dark: 3 });
    line(D, 18, 14, 100, 15, '#B9CEE2'); line(D, 18, 15, 100, 15, '#B9CEE2');
    line(D, 18, 26, 140, 27, '#BFD9C6'); line(D, 18, 27, 140, 27, '#BFD9C6');
    line(D, 18, 36, 80, 37, '#E6C3CB'); line(D, 18, 37, 80, 37, '#E6C3CB');
    box(D, 196, 9, 34, 26, mat('#F6DDE2', '#E9C9CF', '#FAEAED'), { r: 2, dark: 2 });
    box(D, 236, 13, 26, 20, mat('#F4ECCB', '#E6DBB3', '#F9F3DD'), { r: 2, dark: 2 });
    box(D, 150, H - 7, 40, 5, RAMPS.metal, { r: 1, dark: 1 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function mobileBoardArt() {
  return memo('mboard', () => {
    const W = 122, H = 84, D = new Dots(W, H);
    for (const x of [16, W - 22]) { box(D, x, 60, 6, 20, RAMPS.metal, { r: 1, dark: 1 }); ellipse(D, x + 3, 80, 5, 3, RAMPS.metal); }
    box(D, 0, 0, W, 66, mat('#F5F3EF', '#E6E1DA', '#FAF8F5'), { r: 5, dark: 3 });
    line(D, 14, 16, 70, 16, '#BFD9C6'); line(D, 14, 17, 70, 17, '#BFD9C6');
    line(D, 14, 28, 96, 28, '#E6C3CB'); line(D, 14, 29, 96, 29, '#E6C3CB');
    line(D, 14, 40, 60, 40, '#B9CEE2'); line(D, 14, 41, 60, 41, '#B9CEE2');
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function rackArt() {
  return memo('rack', () => {
    const W = 42, H = 120, D = new Dots(W, H), M = mat('#C3BCC6', '#AEA6B2', '#D2CCD5'), slot = mat('#9C94A0', '#8B8390', '#AAA3AD');
    box(D, 0, 0, W, H, M, { r: 4, dark: 4, lit: 1 });
    for (let i = 0; i < 5; i++) box(D, 6, 10 + i * 20, W - 12, 14, slot, { r: 2, dark: 1 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function ringLightArt() {
  return memo('ring', () => {
    const W = 48, H = 110, D = new Dots(W, H), L = mat('#F5EAD2', '#E6D7B8', '#FAF3E4'), M = mat('#CDBFB2', '#B8A89A', '#DACFC4');
    paint(D, 0, 0, W, 48, (px, py) => oval(24, 24, 22, 22)(px, py) && !oval(24, 24, 11, 11)(px, py), (px, py) => oval(24, 24, 20, 20)(px, py) && !oval(24, 24, 13, 13)(px, py), L, (px, py) => (px + py > 52 ? L.s : L.b));
    box(D, 22, 46, 5, 54, M, { r: 1, dark: 0 });
    box(D, 10, 98, 29, 9, M, { r: 3, dark: 2 });
    return { D, cv: D.canvas(), ax: 24, ay: 108 };
  });
}
export function cabinetArt() {
  return memo('cabinet', () => {
    const W = 52, H = 80, D = new Dots(W, H), M = mat('#E4DCCD', '#D3C8B5', '#EEE8DC');
    box(D, 0, 0, W, H, M, { r: 4, dark: 4, lit: 1 });
    for (let i = 0; i < 3; i++) { box(D, 5, 6 + i * 23, W - 10, 20, M, { r: 2, dark: 2 }); box(D, W / 2 - 7, 12 + i * 23, 14, 5, mat('#C9B9A2', '#B8A68D', '#D6C8B4'), { r: 2, dark: 1 }); }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function posterBoardArt() {
  return memo('poster', () => {
    const W = 104, H = 90, D = new Dots(W, H), M = mat('#CDBFB2', '#B8A89A', '#DACFC4');
    for (const x of [14, W - 20]) box(D, x, 58, 6, 30, M, { r: 1, dark: 1 });
    box(D, 0, 0, W, 66, RAMPS.wood, { r: 4, dark: 3, lit: 1 });
    box(D, 7, 7, W - 14, 52, RAMPS.paper, { r: 2, dark: 2 });
    box(D, 13, 12, W - 26, 24, mat('#D9E8EF', '#C6DAE4', '#E7F1F5'), { r: 2, dark: 2 });
    box(D, 13, 40, 36, 7, mat('#F0D6DB', '#E2C1C7', '#F6E4E7'), { r: 1, dark: 1 });
    line(D, 54, 43, 88, 43, RAMPS.paper.s); line(D, 13, 51, 70, 51, RAMPS.paper.s);
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function printerArt() {
  return memo('printer', () => {
    const W = 86, H = 80, D = new Dots(W, H), M = mat('#E7E2DB', '#D6CFC6', '#F1EDE8');
    box(D, 0, 18, W, 60, M, { r: 6, dark: 5, lit: 1 });
    box(D, 16, 2, 54, 26, RAMPS.paper, { r: 2, dark: 2 });
    box(D, 10, 46, 66, 8, mat('#B9B0BE', '#A79EAC', '#C8C0CC'), { r: 2, dark: 1 });
    box(D, 18, 60, 50, 10, RAMPS.paper, { r: 1, dark: 1 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function bookshelfArt() {
  return memo('shelf', () => {
    const W = BOOKSHELF.w * 3, H = BOOKSHELF.h * 3, D = new Dots(W, H), wd = mat('#DCC0A0', '#C9A988', '#E6CFB3');
    box(D, 0, 0, W, H, wd, { r: 4, dark: 3, lit: 1 });
    const cols = ['#EBD3D8', '#D6E1EA', '#EEE2C4', '#D8E6D8', '#E3DAEE', '#F0DCCB'];
    for (const row of [0, 1]) {
      const y0 = 6 + row * 41;
      box(D, 5, y0, W - 10, 38, mat('#CFB394', '#BC9E7E', '#DAC2A6'), { r: 2, dark: 0 });
      let x = 9;
      for (let i = 0; x < W - 20; i++) {
        const w = 12 + (i * 5 + row * 3) % 6, h = 26 + (i * 7 + row) % 8, c = cols[(i + row * 2) % cols.length];
        box(D, x, y0 + 36 - h, w, h, mat(c, mix(c, BROWN, 0.14), mix(c, '#FFFFFF', 0.3)), { r: 2, dark: 2 });
        x += w + 1;
      }
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function waterArt() {
  return memo('water', () => {
    const W = 48, H = 104, D = new Dots(W, H);
    box(D, 3, 38, 42, 64, mat('#EDE8E2', '#DDD5CC', '#F4F0EC'), { r: 5, dark: 4, lit: 1 });
    box(D, 14, 58, 20, 7, mat('#C9D9EB', '#B4C8DE', '#DAE6F2'), { r: 2, dark: 1 });
    ellipse(D, 24, 22, 17, 20, mat('#DCEBF2', '#C8DDE8', '#EAF4F8'), { cres: 0.22 });
    box(D, 18, 38, 12, 6, mat('#C9D9EB', '#B4C8DE', '#DAE6F2'), { r: 1, dark: 1 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function commonTableArt() {
  return memo('ctable', () => {
    const W = 104, H = 62, D = new Dots(W, H), wd = mat('#E6CBA6', '#D5B48D', '#EFDAC0'), dk = mat('#D8B994', '#C5A27C', '#E3CAAB');
    box(D, 46, 28, 12, 26, dk, { r: 3, dark: 2 });
    ellipse(D, 52, 56, 18, 5, dk, { cres: 0.35 });
    ellipse(D, 52, 24, 48, 19, wd, { cres: 0.14 });
    box(D, 40, 14, 24, 16, RAMPS.paper, { r: 2, dark: 2 });
    box(D, 70, 18, 12, 13, RAMPS.white, { r: 3, dark: 2 });
    return { D, cv: D.canvas(), ax: 52, ay: 24 };
  });
}
export function trophyCabinetArt() {
  return memo('trophy', () => {
    const W = 100, H = 70, D = new Dots(W, H), wd = mat('#DCC0A0', '#C9A988', '#E6CFB3');
    box(D, 0, 26, W, 42, wd, { r: 5, dark: 4, lit: 1 });
    line(D, W / 2, 32, W / 2, 62, wd.s);
    ellipse(D, 24, 12, 10, 9, RAMPS.gold, { cres: 0.25 });                 // 트로피 컵
    box(D, 21, 19, 7, 6, RAMPS.gold, { r: 1, dark: 1 }); box(D, 15, 24, 19, 5, RAMPS.gold, { r: 2, dark: 1 });
    box(D, 58, 4, 30, 24, RAMPS.wood, { r: 3, dark: 2 });                 // 액자
    box(D, 63, 9, 20, 14, mat('#D9E8EF', '#C6DAE4', '#E7F1F5'), { r: 1, dark: 1 });
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}

// ---------- 배치 (렌더러와 바닥 그림자가 같은 목록을 쓴다) ----------
// { name, make(), x, y (기준 칸을 맞출 월드 좌표), sortY, lights?: [[wx, wy, on, off, phase]] }
// ---------- 사무실 업그레이드 소품 ----------
// 팀마다 성격을 보여 주는 서 있는 소품과 화분 종류. 같은 도트 규칙(2칸 갈색 외곽선, 명암 2~3단, 낮은 채도, 왼쪽 위 빛).
// 모두 바닥 가운데가 기준점(ax = 가운데, ay = 바닥). 자리는 2일 시뮬레이션에서 사람이 거의 안 지나가는 칸(zoneProps 주석)
const pastel = (c) => mat(c, mix(c, BROWN, 0.16), mix(c, '#FFFFFF', 0.32));
export function chalkboardArt() { // 구역 소품: 초록 칠판 (다리 둘, 분필 받침, 분필 글씨 몇 줄)
  return memo('chalk', () => {
    const W = 150, H = 104, D = new Dots(W, H), gr = mat('#AFC6B3', '#9DB6A2', '#BED2C1');
    for (const x of [18, W - 26]) box(D, x, 70, 8, 34, RAMPS.woodDk, { r: 2, dark: 2 });
    box(D, 0, 0, W, 78, RAMPS.wood, { r: 5, dark: 3, lit: 1 });
    box(D, 8, 8, W - 16, 58, gr, { r: 3, dark: 0 });
    for (const [y, x0, x1] of [[20, 20, 90], [32, 20, 120], [44, 20, 70]]) { line(D, x0, y, x1, y, '#E3ECE2'); line(D, x0, y + 1, x1, y + 1, '#E3ECE2'); }
    box(D, 6, 66, W - 12, 7, RAMPS.wood, { r: 2, dark: 2 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function textbookShelfArt() { // 구역 소품: 낮은 교재 책장 (두 칸, 색 책등)
  return memo('tshelf', () => {
    const W = 96, H = 84, D = new Dots(W, H), wd = RAMPS.woodDk, cols = ['#D8E6D8', '#EEE2C4', '#D6E1EA', '#EBD3D8', '#E3DAEE'];
    box(D, 0, 0, W, H, wd, { r: 4, dark: 3, lit: 1 });
    for (const row of [0, 1]) {
      const y0 = 7 + row * 38; box(D, 6, y0, W - 12, 34, mat('#CFB394', '#BC9E7E', '#DAC2A6'), { r: 2, dark: 0 });
      let x = 10; for (let i = 0; x < W - 22; i++) { const w = 11 + (i * 3 + row) % 5, h = 22 + (i * 5 + row * 3) % 8; box(D, x, y0 + 32 - h, w, h, pastel(cols[(i + row) % cols.length]), { r: 2, dark: 2 }); x += w + 1; }
    }
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function easelArt() { // 구역 소품: 이젤 위 포스터 (하늘색 판, 동그라미와 글씨 줄)
  return memo('easel', () => {
    const W = 84, H = 132, D = new Dots(W, H);
    for (const [x0, x1] of [[18, 10], [W - 18, W - 10]]) for (let y = 40; y < H; y++) { const x = Math.round(x0 + (x1 - x0) * (y - 40) / (H - 40)); for (const dx of [0, 1, 2, 3]) D.set(x + dx - 2, y, dx === 0 || dx === 3 ? RAMPS.woodDk.o : RAMPS.woodDk.b); }
    box(D, 4, 6, W - 8, 92, mat('#D9E8EF', '#C5DAE4', '#E6F0F4'), { r: 4, dark: 3, lit: 1 });
    ellipse(D, W / 2, 38, 18, 18, pastel('#F1D9A8'));
    for (const [y, w] of [[66, 46], [76, 34]]) box(D, (W - w) / 2, y, w, 6, pastel('#E8B9C4'), { r: 2, dark: 0 });
    box(D, 2, 94, W - 4, 8, RAMPS.wood, { r: 2, dark: 2 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function memoWallArt() { // 구역 소품: 아이디어 메모 벽 (코르크 판 + 색 메모지 여러 장, 실로 연결)
  return memo('memowall', () => {
    const W = 150, H = 108, D = new Dots(W, H); // 둘째 줄 책상 옆 빈자리(50)에 맞춰 폭 50
    for (const x of [16, W - 24]) box(D, x, 78, 8, 30, RAMPS.woodDk, { r: 2, dark: 2 });
    box(D, 0, 0, W, 84, RAMPS.cork, { r: 5, dark: 3, lit: 1 });
    const notes = [[12, 12, '#F2E3A6'], [44, 22, '#EBC9D2'], [78, 10, '#CFE2C8'], [112, 22, '#CFE0EC'], [20, 48, '#CFE0EC'], [56, 52, '#F2E3A6'], [92, 48, '#EBC9D2']];
    for (let i = 0; i < notes.length - 1; i++) if (i !== 4) { const [x0, y0] = notes[i], [x1, y1] = notes[i + 1]; const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)); for (let k = 0; k <= n; k++) D.set(Math.round(x0 + 10 + (x1 - x0) * k / n), Math.round(y0 + 4 + (y1 - y0) * k / n), '#C99A8E'); }
    for (const [x, y, c] of notes) { box(D, x, y, 22, 22, pastel(c), { r: 2, dark: 2 }); box(D, x + 8, y - 2, 6, 5, pastel('#E59AA8'), { r: 2, dark: 0 }); }
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function tripodArt() { // 구역 소품: 카메라 삼각대
  return memo('tripod', () => {
    const W = 50, H = 110, D = new Dots(W, H), mt = mat('#BDB6BE', '#A69FA8', '#CCC6CD');
    for (const [x1] of [[6], [W / 2], [W - 6]]) for (let y = 44; y < H; y++) { const x = Math.round(W / 2 + (x1 - W / 2) * (y - 44) / (H - 44)); D.set(x - 1, y, mt.o); D.set(x, y, mt.o); }
    box(D, W / 2 - 4, 36, 8, 12, mt, { r: 2, dark: 2 });
    box(D, 5, 8, 40, 30, mat('#8E8792', '#7B747F', '#A099A3'), { r: 5, dark: 3, lit: 1 });
    ellipse(D, W / 2 + 4, 23, 9, 9, mat('#B9C9D6', '#A4B7C6', '#CAD7E1'));
    box(D, 10, 2, 12, 8, mat('#8E8792', '#7B747F', '#A099A3'), { r: 2, dark: 0 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function paperBackdropArt() { // 구역 소품: 촬영 배경지 (기둥 둘 + 위 막대 + 늘어진 연분홍 종이)
  return memo('backpaper', () => {
    const W = 90, H = 112, D = new Dots(W, H), mt = mat('#BDB6BE', '#A69FA8', '#CCC6CD'); // 둘째 줄 책상 옆 빈자리(31)에 맞춰 폭 30
    for (const x of [4, W - 10]) box(D, x, 4, 6, H - 8, mt, { r: 2, dark: 1 });
    box(D, 0, 0, W, 9, mt, { r: 3, dark: 2 });
    box(D, 14, 8, W - 28, H - 22, pastel('#F1DBD8'), { r: 4, dark: 4, lit: 1 });
    for (const x of [-2, W - 12]) box(D, x, H - 8, 14, 7, mt, { r: 2, dark: 2 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function deskCalendarArt() { // 구역 소품: 큰 벽 달력 (스탠드, 빨간 고리, 날짜 칸)
  return memo('calendar', () => {
    const W = 84, H = 116, D = new Dots(W, H);
    for (const x of [16, W - 22]) box(D, x, 82, 6, 34, RAMPS.woodDk, { r: 2, dark: 2 });
    box(D, 0, 6, W, 82, RAMPS.paper, { r: 4, dark: 3, lit: 1 });
    box(D, 0, 6, W, 20, pastel('#E9B9AE'), { r: 4, dark: 2 });
    for (const x of [16, W - 22]) box(D, x, 0, 6, 12, RAMPS.metal, { r: 2, dark: 1 });
    for (let j = 0; j < 4; j++) for (let i = 0; i < 5; i++) { const c = i === 2 && j === 1 ? '#EBC0B5' : '#E5DDD3'; box(D, 8 + i * 14, 32 + j * 13, 11, 10, mat(c, mix(c, BROWN, 0.1), c), { r: 1, dark: 0 }); }
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function monitorStationArt() { // 구역 소품: 모니터 세 대가 놓인 낮은 장 (코드 화면)
  return memo('monitors', () => {
    const W = 96, H = 108, D = new Dots(W, H), sc = mat('#C7D6E2', '#B3C6D5', '#D8E3EC'), fr = mat('#9C94A0', '#8B8390', '#AAA3AD'); // 오른쪽 빈자리(32)에 맞춰 두 대를 위아래로 비켜
    box(D, 4, 64, W - 8, 44, RAMPS.woodDk, { r: 4, dark: 4, lit: 1 });
    for (const [x, y, w] of [[4, 18, 44], [48, 6, 44]]) {
      box(D, x + w / 2 - 3, y + 34, 6, 64 - y - 32, fr, { r: 1, dark: 0 });
      box(D, x, y, w, 38, fr, { r: 3, dark: 2 });
      box(D, x + 4, y + 4, w - 8, 28, sc, { r: 2, dark: 0 });
      for (let k = 0; k < 4; k++) { const ww = 8 + ((x + k * 7) % 14); line(D, x + 8, y + 9 + k * 6, x + 8 + ww, y + 9 + k * 6, k % 2 ? '#B8D8C3' : '#E3C9D1'); }
    }
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function tallPlantArt() { // 화분 종류 1: 키 큰 산세베리아 (뾰족한 잎 셋, 원통 화분)
  return memo('tallplant', () => {
    const W = 50, H = 110, D = new Dots(W, H), L = RAMPS.leaf;
    for (const [cx, top, hw] of [[16, 26, 6], [26, 8, 7], [35, 30, 6]]) {
      const leaf = (px, py) => py >= top && py < 84 && Math.abs(px + 0.5 - cx) <= hw * Math.min(1, (py - top) / 22 + 0.25);
      const inner = (px, py) => py >= top + 3 && py < 84 && Math.abs(px + 0.5 - cx) <= hw * Math.min(1, (py - top) / 22 + 0.25) - 2;
      paint(D, cx - hw - 1, top - 1, cx + hw + 1, 85, leaf, inner, L, (px) => (px > cx + 1 ? L.s : L.b));
    }
    box(D, 8, 78, 34, 32, pastel('#E2D5C8'), { r: 5, dark: 4 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
export function roundPlantArt() { // 화분 종류 2: 둥근 덤불 화분 (낮고 넓은 잎 덩어리, 하늘색 화분)
  return memo('roundplant', () => {
    const W = 64, H = 70, D = new Dots(W, H), L = mat('#C8D9B2', '#AFC69A', '#D8E5C6');
    for (const [dx, dy, rx, ry] of [[-12, -8, 13, 11], [12, -8, 13, 11], [0, -16, 15, 12], [0, -2, 18, 11]]) ellipse(D, W / 2 + dx, 34 + dy, rx, ry, L);
    box(D, 14, 40, 36, 28, pastel('#CBDCE6'), { r: 7, dark: 4 });
    box(D, 10, 38, 44, 8, pastel('#CBDCE6'), { r: 4, dark: 2, lit: 1 });
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}

export function zoneProps(id, staff) {
  const r = roomById[id], list = [];
  const add = (name, make, x, y, sortY = y, extra) => list.push({ name, make, x, y, sortY, ...extra });
  // 구석 화분은 방마다 종류를 바꾼다
  const cornerKind = { edu: 'round', ops: 'tall', dev: 'round', cplan: 'tall' }[id];
  const corner = () => add('plant', () => (cornerKind === 'round' ? roundPlantArt() : cornerKind === 'tall' ? tallPlantArt() : plantArt(false)), r.x + r.w - 14, r.y + r.h - 6);
  const desks = () => { for (const e of staff) if (e.team === id && e.id !== 'assistant') list.push({ name: 'desk', make: () => deskArt(e.team, e.state === 'work', e.lead ? 'plant' : ''), x: e.seat.x, y: e.seat.y, sortY: e.seat.y + 6 }); };
  const tr = { x: r.x + r.w - 50, y: r.y + 10 };
  // 방을 줄여 위아래 빈 띠가 없어졌다. 팀 소품은 둘째 줄 책상 양옆 빈자리(첫 줄 책상 아래)와 구석에만.
  // 자리는 2일 시뮬레이션 사람 지나간 칸 지도로 확인 (README "사무실 디자인 업그레이드")
  const R = r.x + r.w, B = r.y + r.h;
  if (id === 'ceo') { // 대표 책상(왼쪽) + 비서 책상(오른쪽, 문 위). 위쪽 벽 가운데 x 110은 공연 무대 뒷문
    const j = staff.find((e) => e.id === 'assistant');
    add('ceodesk', () => ceoDeskArt(true), CEO_SEAT.x, CEO_SEAT.y, CEO_SEAT.y + 8);
    add('jdesk', () => assistDeskArt(!j || j.state === 'work'), ASSIST_SEAT.x, ASSIST_SEAT.y, ASSIST_SEAT.y + 6);
    add('trophy', () => trophyCabinetArt(), R - 40, r.y + 6, r.y + 29);
    add('plant', () => plantArt(false), r.x + 14, r.y + 46);
    add('cactus', () => cactusArt(), r.x + 150, r.y + 30);
  }
  if (id === 'meeting') {
    add('mtable', () => meetingTableArt(), MEETING_TABLE.x, MEETING_TABLE.y, MEETING_TABLE.y + MEETING_TABLE.h);
    add('plant', () => plantArt(false), r.x + 10, r.y + 30);           // 위 두 모서리 (앞줄 자리 바깥)
    add('plant', () => plantArt(false), R - 10, r.y + 30);
  }
  if (id === 'edu') {
    desks();
    add('chalk', () => chalkboardArt(), r.x + 28, r.y + 100);          // 둘째 줄 왼쪽: 칠판
    add('tshelf', () => textbookShelfArt(), R - 30, r.y + 104);         // 둘째 줄 오른쪽: 교재 책장
    add('plant', () => tallPlantArt(), R - 10, r.y + 60);              // 첫 줄 오른쪽 끝
  }
  if (id === 'dev') {
    desks();
    for (const k of [0, 1]) {
      const x = r.x + 6 + k * 15, y = r.y + 22;
      add('rack', () => rackArt(), x, y, y + 40, { lights: [0, 1, 2, 3, 4].map((i) => [x + 10, y + 5 + i * 20 / 3, i % 2 ? '#A9DBB8' : '#B5D3EE', '#9C94A0', i * 1.7 + k * 3]) });
    }
    add('monitors', () => monitorStationArt(), R - 17, r.y + 44);       // 오른쪽: 모니터 장
    add('plant', () => tallPlantArt(), R - 12, B - 4);
    add('boxes', () => boxStackArt(), r.x + 22, B - 4);
  }
  if (id === 'fin') { // 재무팀: 책상 + 서류 상자 + 화분
    desks();
    add('boxes', () => boxStackArt(), r.x + 16, B - 4);
    add('plant', () => tallPlantArt(), R - 10, B - 4);
  }
  if (id === 'cplan') {
    desks();
    add('memowall', () => memoWallArt(), r.x + 28, r.y + 100);          // 둘째 줄 왼쪽: 아이디어 메모 벽
    add('cork', () => corkArt(), R - 46, r.y + 72, r.y + 96);           // 둘째 줄 오른쪽: 코르크 판
    add('plant', () => tallPlantArt(), R - 10, r.y + 60);
  }
  if (id === 'cmake') {
    desks();
    add('backpaper', () => paperBackdropArt(), r.x + 16, r.y + 100);    // 둘째 줄 왼쪽: 촬영 배경지
    add('ring', () => ringLightArt(), R - 14, r.y + 44, r.y + 44);      // 첫 줄 오른쪽: 링 조명
    add('tripod', () => tripodArt(), R - 14, r.y + 100);                // 둘째 줄 오른쪽: 카메라 삼각대
  }
  if (id === 'ops') {
    desks();
    add('cabinet', () => cabinetArt(), R - 24, r.y + 8, r.y + 35);      // 첫 줄 오른쪽: 서류함
    add('calendar', () => deskCalendarArt(), R - 16, r.y + 100);        // 둘째 줄 오른쪽: 큰 달력
    add('plant', () => tallPlantArt(), r.x + 12, r.y + 100);
  }
  if (id === 'mkt') {
    desks();
    add('poster', () => posterBoardArt(), r.x + 6, r.y + 64, r.y + 94); // 둘째 줄 왼쪽: 포스터 보드
    add('easel', () => easelArt(), R - 22, r.y + 100);                 // 둘째 줄 오른쪽: 이젤 포스터
    add('plant', () => roundPlantArt(), R - 14, r.y + 40);
  }
  if (id === 'lounge') { // 라운지 카페: 커피 코너와 정수기(왼쪽 위), 소파(왼쪽 아래), 카페 테이블 셋(가운데 러그), 자료 코너(오른쪽: 책장, 프린터, 테이블)
    corner();
    add('coffee', () => coffeeArt(), COFFEE.x, COFFEE.y, COFFEE.y + 30, { lights: [[COFFEE.x + 17, COFFEE.y + 5, '#9BD3AE', '#BDD5E2', 0]] });
    add('water', () => waterArt(), WATER.x, WATER.y, WATER.y + 34);
    add('shelf', () => bookshelfArt(), BOOKSHELF.x, BOOKSHELF.y, BOOKSHELF.y + BOOKSHELF.h);
    add('printer', () => printerArt(), PRINTER.x, PRINTER.y, PRINTER.y + 26, { lights: [[PRINTER.x + 22, PRINTER.y + 10, '#9BD3AE', '#D6CFC6', 0.5]] });
    add('ctable', () => commonTableArt(), COMMON_TABLE.x, COMMON_TABLE.y, COMMON_TABLE.y + 6);
    add('sofa', () => sofaArt(), SOFA.x, SOFA.y, SOFA.y + SOFA.h - 20);
    CAFE_TABLES.forEach((tb, i) => add('table', () => roundTableArt(['#F6D364', '#F28CA8', '#8DD3EE'][i], i === 2), tb.x, tb.y, tb.y + 6));
    add('plush', () => plushArt(), SOFA.x + SOFA.w + 2, SOFA.y + 30);
    add('basket', () => basketArt(), r.x + 120, r.y + 18);
  }
  return list;
}
// 복도 소품 (입구 양옆 화분, 로비 큰 화분 둘)
function hallProps() {
  return [
    { name: 'plant', make: () => plantArt(false), x: DOOR_GAP.x0 - 12, y: WALL_Y - 4, sortY: WALL_Y - 4 },
    { name: 'plant', make: () => plantArt(false), x: DOOR_GAP.x1 + 12, y: WALL_Y - 4, sortY: WALL_Y - 4 },
    ...HALL_PLANTS.map((p) => ({ name: 'plantBig', make: () => plantArt(true), x: p.x, y: p.y, sortY: p.y })), // 입구 로비 화분 (물 주러 오는 곳)
  ];
}
export function allProps(staff) {
  return [...ROOMS.flatMap((r) => zoneProps(r.id, staff)), ...hallProps()];
}
// 장식 소품의 바닥 상자 (월드 단위): 그림 아래 끝에서 최대 12, 그림 높이의 35%까지. 길찾기(sim.js blockAreas)가 이 칸을 피한다.
const SEATED = new Set(['desk', 'ceodesk', 'jdesk', 'mtable', 'table', 'sofa']);
export function propFootprints(staff) {
  return allProps(staff).filter((q) => !SEATED.has(q.name)).map((q) => {
    const a = q.make(), w = a.cv.width / 3, h = a.cv.height / 3, x0 = q.x - a.ax / 3, y1 = q.y - a.ay / 3 + h;
    return { name: q.name, x0, x1: x0 + w, y0: y1 - Math.min(12, h * 0.35), y1 };
  });
}

// ---------- 사무실 밖: 숲 속 풀밭 ----------
// 들판과 숲 분위기: 옅은 풀밭, 짧은 풀 무늬, 작은 꽃, 둥근 덤불, 베이지 줄기의 둥근 나무, 모래빛 길.
// 같은 도트 규칙(2칸 외곽선, 깨끗한 곡선, 명암 2~3단, 낮은 채도)을 쓰되 외곽선을 더 옅게 해서 캐릭터보다 눈에 덜 띄게 한다.
// - 풀밭: 주기 GP칸 반복 무늬 한 장(grassTile). 렌더러가 화면 전체를 이 무늬로 칠하고, 사무실 한 장도 같은 무늬로 테두리를 채워 이음매가 없다.
// - 사무실 한 장(worldArt)에 사무실 둘레 RING만큼 풀밭, 입구 앞 길, 건물 그림자를 함께 굽는다.
// - 나무, 덤불, 디딤돌, 꽃 무더기는 소품 목록(outdoorProps). 사무실 밖에만 있어서 직원과 겹치지 않는다.
export const RING = 60;                 // 사무실 한 장에 함께 굽는 바깥 테두리 (월드 단위)
const GP = 240;                         // 풀밭 무늬 주기 (칸)
export const GRASS = { b: '#CDE8B0', s: '#B8DB98', l: '#DCF0C4', flower: '#FFFFFF', flower2: '#F29BB4', bud: '#F7E3A8' };
const soft = (b, s, l) => ({ b, s, l, o: mix(s, INK, 0.46) }); // 바깥 소품용 옅은 외곽선
const OUT = {
  leaf:  soft('#A9D58E', '#90C477', '#C2E3AA'),
  leaf2: soft('#F7C3D2', '#EBA6BB', '#FBD9E3'),
  trunk: soft('#E3D3BD', '#D2BEA4', '#ECE1D1'),
  path:  { b: '#ECE3D1', o: '#D8C9AF', mark: '#E0D4BE' },
  stone: soft('#E4DDD1', '#D3C9BA', '#EDE8DF'),
};
const wrapSet = (D, x, y, c) => D.set(((x % D.w) + D.w) % D.w, ((y % D.h) + D.h) % D.h, c);
export function grassTile() {
  return memo('grass', () => {
    const D = new Dots(GP, GP);
    D.p.fill(ci(GRASS.b));
    // 짧은 풀 무늬: 2칸 두께 잎 셋 (가운데가 가장 길다). 드문드문
    for (let k = 0; k < 14; k++) {
      const x = Math.floor(h2(k, 1, 41) * GP), y = Math.floor(h2(k, 2, 41) * GP), tall = 4 + Math.floor(h2(k, 3, 41) * 2);
      for (const [dx, h] of [[0, tall - 2], [3, tall], [6, tall - 3]]) for (let j = 0; j < h; j++) for (const ddx of [0, 1]) wrapSet(D, x + dx + ddx, y - j, GRASS.s);
    }
    // 작은 꽃 (분홍과 흰색, 가운데 노랑). 더 드물게
    for (let k = 0; k < 4; k++) {
      const x = Math.floor(h2(k, 4, 43) * GP), y = Math.floor(h2(k, 5, 43) * GP), c = k % 2 ? GRASS.flower2 : GRASS.flower;
      for (const [dx, dy] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) wrapSet(D, x + dx + a, y + dy + b, c);
      for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) wrapSet(D, x + a, y + b, GRASS.bud);
    }
    return { D, cv: D.canvas() };
  });
}
const grassAt = (gx, gy) => { const T = grassTile().D; return T.get(((gx % GP) + GP) % GP, ((gy % GP) + GP) % GP); };

// 동그라미 여러 개를 합친 모양(덤불, 나무 잎). 바깥 2칸은 외곽선(반지름 2칸 작은 같은 동그라미들 밖), 왼쪽 위로 민 모양 밖은 그림자
function blobs(D, list, M, o = {}) {
  const cut = o.cut ?? Infinity, sh = o.shift ?? [5, 6];
  const U = (px, py, d = 0) => py + 0.5 <= cut - d && list.some(([cx, cy, r]) => oval(cx, cy, r - d, r - d)(px, py));
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [cx, cy, r] of list) { x0 = Math.min(x0, cx - r); y0 = Math.min(y0, cy - r); x1 = Math.max(x1, cx + r); y1 = Math.max(y1, cy + r); }
  paint(D, Math.floor(x0) - 1, Math.floor(y0) - 1, Math.ceil(x1) + 1, Math.ceil(y1) + 1, (px, py) => U(px, py), (px, py) => U(px, py, 2), M,
    (px, py) => (U(px + sh[0], py + sh[1], 2) ? M.b : M.s));
  for (const [x, y] of o.marks || []) for (const [dx, dy] of [[0, 3], [1, 2], [2, 1], [3, 0], [4, 1], [5, 2], [6, 3]]) { D.set(x + dx, y + dy, M.s); D.set(x + dx, y + dy + 1, M.s); } // 잎 결 (ㅅ 모양 짧은 선)
}
function groundShadow(D, cx, cy, rx, ry) { const f = oval(cx, cy, rx, ry); for (let py = Math.floor(cy - ry); py <= cy + ry; py++) for (let px = Math.floor(cx - rx); px <= cx + rx; px++) if (f(px, py)) D.set(px, py, GRASS.s); }
// 나무 (캐릭터보다 훨씬 크게): 베이지 줄기 + 둥근 잎 덩어리 여러 개. v0 둥근 나무, v1 키 큰 나무, v2 연두 작은 나무
const TREES = [
  { W: 216, H: 236, trunk: [36, 150], c: [[108, 80, 70], [46, 132, 44], [170, 132, 44], [84, 152, 48], [134, 154, 46]], marks: [[78, 58], [124, 44], [52, 124], [150, 120], [98, 108]] },
  { W: 168, H: 232, trunk: [30, 130], c: [[84, 74, 56], [44, 118, 36], [124, 118, 36], [84, 140, 40]], marks: [[64, 56], [100, 42], [48, 112], [112, 104]] },
  { W: 176, H: 196, trunk: [30, 116], c: [[88, 66, 56], [40, 106, 36], [136, 106, 36], [88, 122, 40]], marks: [[66, 50], [104, 40], [50, 100]] },
];
export function treeArt(v = 0) {
  return memo(`tree|${v}`, () => {
    const T = TREES[v], D = new Dots(T.W, T.H), cx = T.W / 2, [tw, ty] = T.trunk;
    groundShadow(D, cx + 14, T.H - 9, tw * 1.9, 9);
    box(D, cx - tw / 2, ty, tw, T.H - ty - 8, OUT.trunk, { r: 6, dark: 0 });                       // 줄기
    for (let py = ty + 4; py < T.H - 12; py++) for (let k = 0; k < 4; k++) D.set(cx + tw / 2 - 7 + k, py, OUT.trunk.s); // 줄기 오른쪽 그늘
    box(D, cx - tw / 2 - 8, T.H - 18, 14, 10, OUT.trunk, { r: 4, dark: 0 });                        // 뿌리 두 갈래
    box(D, cx + tw / 2 - 6, T.H - 18, 14, 10, OUT.trunk, { r: 4, dark: 0 });
    blobs(D, T.c, v === 2 ? OUT.leaf2 : OUT.leaf, { shift: [10, 12], marks: T.marks });
    return { D, cv: D.canvas(), ax: Math.round(cx), ay: T.H - 9 };
  });
}
export function bushArt(v = 0) {
  return memo(`bush|${v}`, () => {
    const W = v ? 52 : 74, H = 44, D = new Dots(W, H);
    groundShadow(D, W / 2 + 5, H - 5, W / 2 - 6, 4);
    const c = v ? [[15, 28, 13], [31, 22, 16], [40, 30, 11]] : [[15, 30, 13], [33, 22, 17], [52, 26, 15], [62, 32, 10]];
    blobs(D, c, v ? OUT.leaf2 : OUT.leaf, { cut: H - 6, marks: v ? [[22, 20]] : [[26, 18], [46, 24]] });
    return { D, cv: D.canvas(), ax: Math.round(W / 2), ay: H - 6 };
  });
}
export function flowerPatchArt(v = 0) {
  return memo(`flowers|${v}`, () => {
    const D = new Dots(30, 24), c = v ? GRASS.flower2 : GRASS.flower;
    for (const [x, y] of [[6, 8], [16, 5], [23, 13], [11, 15]]) {
      for (let j = 3; j < 7; j++) { D.set(x, y + j, GRASS.s); D.set(x + 1, y + j, GRASS.s); }
      for (const [dx, dy] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + dx + a, y + dy + b, c);
      for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + a, y + b, GRASS.bud);
    }
    return { D, cv: D.canvas(), ax: 15, ay: 22 };
  });
}
// ---------- 바닷가 마을 (사무실 위쪽 = 바다, 모래사장, 빨간 지붕 집) ----------
export const SEA_Y = -190;              // 이 위는 바다. 아래로 모래사장 띠(32), 그 아래 마을 집 한 줄
const SEA = { b: '#8ED2EE', wave: '#C2E8F7', shallow: '#B5E4F4', foam: '#FFFFFF', wet: '#EAD7AE', sand: '#F7E8C6', speck: '#E9D6AE' };
export function seaTile() {
  return memo('sea', () => {
    const N = 180, D = new Dots(N, N);
    D.p.fill(ci(SEA.b));
    for (let k = 0; k < 9; k++) { // 물결 (︶ 모양 짧은 곡선)
      const x = Math.floor(h2(k, 1, 61) * N), y = Math.floor(h2(k, 2, 61) * N);
      for (let dx = -6; dx <= 6; dx++) { const yy = y + Math.round((dx * dx) / 12); wrapSet(D, x + dx, yy, SEA.wave); wrapSet(D, x + dx, yy + 1, SEA.wave); }
    }
    for (let k = 0; k < 4; k++) { const x = Math.floor(h2(k, 3, 62) * N), y = Math.floor(h2(k, 4, 62) * N); for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) wrapSet(D, x + a, y + b, SEA.foam); }
    return { D, cv: D.canvas() };
  });
}
export const SHORE_W = 120;             // 해변 띠 한 장 폭 (월드). 가로로 반복해 붙인다
export function shoreStrip() {
  return memo('shore', () => {
    const W = SHORE_W * 3, H = 96, D = new Dots(W, H);
    for (let px = 0; px < W; px++) {
      const ft = 22 + Math.round(5 * Math.sin((2 * Math.PI * px) / 120)), ge = 82 + Math.round(4 * Math.sin((2 * Math.PI * px) / 90 + 1));
      for (let py = Math.max(0, ft - 12); py < ge + 2; py++) {
        const c = py < ft ? SEA.shallow : py < ft + 4 ? SEA.foam : py < ft + 8 ? SEA.wet : py < ge ? (h2(px, py, 77) < 0.012 ? SEA.speck : SEA.sand) : GRASS.s;
        D.set(px, py, c);
      }
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
const WALLS = [mat('#FFFFFF', '#EEE6E8', '#FFFFFF'), mat('#FFE8EF', '#F5CCD9', '#FFF4F7'), mat('#FAD3DC', '#EDB7C4', '#FDE4EA'), mat('#FFF5DC', '#F2E2B8', '#FFFBEE'), mat('#E4F1FB', '#C9DFF0', '#F1F8FD')];
const ROOF_RED = mat('#E85A55', '#CC4440', '#F07C76');
const ROOFS = [mat('#F7A9BA', '#EA8DA3', '#FBC6D2'), mat('#F28AA0', '#E06E86', '#F7A9BA'), ROOF_RED, mat('#FBC6D2', '#F2A6B8', '#FDDDE5'), mat('#F28AA0', '#E06E86', '#F7A9BA')];
const GLASS = mat('#CFE9F5', '#B3D9EC', '#E6F4FA');
export function houseArt(v = 0, small = false) {
  return memo(`house|${v}|${small}`, () => {
    const k = small ? 0.72 : 1, q = (n) => Math.round(n * k);
    const W = q(180), H = q(198), D = new Dots(W, H), WM = WALLS[v % WALLS.length], RM = ROOFS[(v * 3 + 1) % ROOFS.length], cx = W / 2;
    groundShadow(D, cx + q(8), H - 8, q(82), 8);
    if (v % 2) box(D, q(124), q(24), q(16), q(34), mat('#E8E0D6', '#D6CBBD', '#F2ECE5'), { r: 2, dark: 2 });
    box(D, q(20), q(88), q(140), H - q(88) - 8, WM, { r: 6, dark: 6, lit: 2 });
    const top = q(8), base = q(100), half = q(84);
    const tri = (d) => (px, py) => py >= top + d && py <= base - d && Math.abs(px + 0.5 - cx) <= half * (py - top) / (base - top) - d * 1.2;
    paint(D, 2, top - 2, W - 2, base + 2, tri(0), tri(2), RM, (px, py) => ((py - top) % 14 < 2 && py > top + 14 ? RM.s : px + 0.5 > cx ? RM.s : RM.b));
    if (!small) ellipse(D, cx, q(62), 11, 11, GLASS, { cres: 0.3 });
    const dw = q(36), dh = q(54);
    box(D, cx - dw / 2, H - 8 - dh, dw, dh, mat('#E3B27E', '#CF9A64', '#EEC79C'), { r: 4, dark: 3, lit: 1 });
    for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(cx + dw / 2 - 7 + a, H - 8 - dh / 2 + b, '#F2C94C');
    const ws = q(30);
    for (const x of small ? [q(30)] : [q(32), q(118)]) {
      const y = q(116);
      box(D, x, y, ws, ws, GLASS, { r: 3, dark: 2, lit: 2 });
      line(D, x + ws / 2 - 1, y + 2, x + ws / 2, y + ws - 3, '#FFFFFF'); line(D, x + 2, y + ws / 2 - 1, x + ws - 3, y + ws / 2, '#FFFFFF');
      box(D, x - 2, y + ws + 4, ws + 4, 9, mat('#C98E62', '#B07750', '#DBA77F'), { r: 2, dark: 2 });
      for (let i = 0; i < 4; i++) for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(x + 3 + i * Math.floor(ws / 4) + a, y + ws + 1 + b, ['#F29BB4', '#E85A55', '#F7D35C', '#FFFFFF'][(i + v) % 4]);
    }
    return { D, cv: D.canvas(), ax: Math.round(cx), ay: H - 8 };
  });
}
// 구불구불한 마을 길 (바닥 그림 한 장, 집보다 먼저 그린다): 가로 길 + 대표실 뒷문으로 내려가는 갈림길
export const ROAD = { x0: -280, x1: 990, y0: -128, y1: 6, cy: (x) => -96 + 7 * Math.sin(x / 46) + 4 * Math.sin(x / 17), hw: 10 };
export function roadArt() {
  return memo('road', () => {
    const R = ROAD, W = (R.x1 - R.x0) * 3, H = (R.y1 - R.y0) * 3, D = new Dots(W, H);
    const base = '#B9B6BC', edge = '#F1E9E2', stone = '#B1AEB5', dash = '#FFFFFF', curb = '#DCD2CC';
    for (let px = 0; px < W; px++) {
      const wx = R.x0 + px / 3, c = (R.cy(wx) - R.y0) * 3, hw = R.hw * 3;
      for (let py = Math.floor(c - hw); py <= c + hw; py++) {
        if (py < 0 || py >= H) continue;
        const d = Math.abs(py - c);
        D.set(px, py, d > hw - 2 ? curb : d > hw - 9 ? edge : (h2(px >> 3, py >> 3, 55) < 0.12 && (px + py) % 9 < 5 ? stone : base));
      }
      if (Math.abs(((px / 3) % 26)) < 12) for (const k of [0, 1]) D.set(px, Math.round(c) + k, dash); // 가운데 점선
    }
    for (const cx of [-46, 150, 420, 756]) { // 횡단보도: 차도를 가로지르는 흰 줄무늬 (뒷문 꼬불길은 뺐다)
      const px0 = Math.round((cx - 9 - R.x0) * 3), px1 = Math.round((cx + 9 - R.x0) * 3);
      for (let px = px0; px <= px1; px++) {
        const c = (R.cy(R.x0 + px / 3) - R.y0) * 3, hw = (R.hw - 3) * 3;
        for (let py = Math.floor(c - hw); py <= c + hw; py++) if (((py - Math.floor(c - hw)) % 8) < 4) D.set(px, py, '#FFFFFF');
      }
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
// 산책길 (흙길): 입구에서 왼쪽 길로 나가 사무실을 돌아 위쪽 차도로, 차도에서 바닷가로 내려갔다가 오른쪽 길로 돌아온다.
// 굵은 점을 몇 개 찍고 부드러운 곡선(캣멀롬)으로 이어 물결처럼 휘게 한다. 시뮬레이션(산책)도 이 점을 그대로 걷는다.
function smooth(pts, per = 6) {
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    for (let k = 0; k < per; k++) {
      const t = k / per, t2 = t * t, t3 = t2 * t;
      const f = (a, b, c, d) => 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1])]);
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}
const PATH_L = (() => { // 입구 → 아래 → 왼쪽 → 위로 차도까지
  const c = [[216, 384], [210, 404], [180, 420]];
  for (let x = 140; x >= 0; x -= 40) c.push([x, 424 + 7 * Math.sin(x / 26)]);
  c.push([-40, 414]);
  for (let y = 370; y >= -50; y -= 42) c.push([-60 + 12 * Math.sin(y / 30), y]);
  c.push([-50, -84]);
  return smooth(c);
})();
const PATH_R = (() => { // 입구 → 아래 → 오른쪽 → 위로 차도까지
  const c = [[216, 384], [226, 404], [262, 422]];
  for (let x = 300; x <= 700; x += 40) c.push([x, 424 + 7 * Math.sin(x / 26 + 1)]);
  c.push([744, 414]);
  for (let y = 370; y >= -50; y -= 42) c.push([764 + 12 * Math.sin(y / 30 + 2), y]);
  c.push([756, -88]);
  return smooth(c);
})();
const PATH_B = smooth([[150, -96], [158, -118], [144, -138], [156, -156], [150, -170]]); // 차도 → 바닷가
export const STROLL_OUT = PATH_L, STROLL_BEACH = PATH_B, STROLL_BACK = PATH_R;
// 바닷가 모래사장을 따라 걷기 (물가 쪽으로 살짝 오르내리며, 중간에 멈춰 바다 구경)
function beachWalk(a, b) {
  const r = [], s = a < b ? 22 : -22;
  for (let x = a; s > 0 ? x <= b : x >= b; x += s) r.push([x, -168 + 4 * Math.sin(x / 40)]);
  const m = r[Math.floor(r.length / 2)]; r.splice(Math.floor(r.length / 2), 0, [m[0], -176], [m[0] + 2, -177], [m[0], -176]); // 물가에서 잠깐 바다 보기
  return r;
}
const roadPts = (a, b) => { const r = [], s = a < b ? 20 : -20; for (let x = a; s > 0 ? x <= b : x >= b; x += s) r.push([x, ROAD.cy(x)]); return r; };
const P = (pts) => pts.map(([x, y]) => ({ x, y }));
// 직원: 입구 → 왼쪽으로 돌아 차도 → 바닷가 / 바닷가 x에서 → 차도 → 오른쪽으로 돌아 입구
export const strollToBeach = () => P([...PATH_L, ...roadPts(-46, 150), ...PATH_B]);
export const strollFromBeach = (x) => { const X = Math.round(x); return P([[X, -150], [X, ROAD.cy(X)], ...roadPts(X, 756), ...[...PATH_R].reverse()]); };
// 대표: 대표실 뒷문 → 차도 건너 바닷가 / 바닷가 x에서 → 뒷문
const BOSS_UP = () => { const X = STAGE.door.x; return [[X, STAGE.door.inY], [X, 8], [X, STAGE.door.outY], [X + 4, -40], [X - 4, ROAD.cy(X) + 14], [X, ROAD.cy(X)], [X + 6, -130], [X, -166]]; };
export const bossToBeach = () => P(BOSS_UP());
export const bossFromBeach = (x) => P([[x, -166], ...[...BOSS_UP()].reverse()]);
// 바닷가에서 다음에 걸어갈 곳 (모래사장 위 아무 데나, 가끔 물가에 서서 바다 보기)
export function beachSpot(fromX, rnd) {
  const nx = Math.max(-60, Math.min(760, fromX + (rnd() < 0.5 ? -1 : 1) * (50 + rnd() * 110)));
  return rnd() < 0.25 ? { x: nx, y: -177, look: true } : { x: nx, y: -170 + rnd() * 12 };
}
export function dirtPathArt() {
  return memo('dirtpath', () => {
    const X0 = -110, Y0 = -190, X1 = 810, Y1 = 450, W = (X1 - X0) * 3, H = (Y1 - Y0) * 3, D = new Dots(W, H);
    const base = '#EBD7B4', edge = '#D9BF95', pebble = '#DCC7A2', R = 7 * 3;
    const disk = (cx, cy, r, colorAt) => { for (let y = Math.floor(cy - r); y <= cy + r; y++) for (let x = Math.floor(cx - r); x <= cx + r; x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) D.set(x, y, colorAt(x, y)); };
    for (const pass of [0, 1]) for (const pts of [PATH_L, PATH_R, PATH_B]) for (let i = 0; i < pts.length - 1; i++) {
      const [ax, ay] = pts[i], [bx, by] = pts[i + 1], n = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) * 1.5));
      for (let k = 0; k <= n; k++) {
        const t = k / n, cx = (ax + (bx - ax) * t - X0) * 3, cy = (ay + (by - ay) * t - Y0) * 3;
        if (pass === 0) disk(cx, cy, R, () => edge);
        else disk(cx, cy, R - 3, (x, y) => (h2(x >> 2, y >> 2, 81) < 0.05 ? pebble : base));
      }
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0 };
  });
}
export function cruiseArt() { // 분홍 크루즈 배
  return memo('cruise', () => {
    const W = 210, H = 90, D = new Dots(W, H), wh = mat('#FFFFFF', '#E9E4EA', '#FFFFFF'), pk = mat('#F7A9BA', '#EA8DA3', '#FBC6D2');
    ellipse(D, 105, 82, 96, 7, mat('#C2E8F7', '#ADDDF1', '#D6F0FA'));
    const hull = (d) => (px, py) => py >= 50 + d && py <= 80 - d && px >= 6 + d + (py - 50) * 0.5 && px <= 204 - d - (py - 50) * 0.25;
    paint(D, 4, 48, 206, 82, hull(0), hull(2), pk, (px, py) => (py < 58 ? '#FFFFFF' : px > 150 ? pk.s : pk.b));
    for (let x = 22; x < 190; x += 12) box(D, x, 60, 6, 6, mat('#CFE9F5', '#B3D9EC', '#E6F4FA'), { r: 2, dark: 1 });
    box(D, 34, 30, 140, 22, wh, { r: 6, dark: 3, lit: 2 });
    box(D, 60, 12, 84, 20, wh, { r: 6, dark: 3, lit: 2 });
    for (let x = 42; x < 168; x += 10) box(D, x, 36, 6, 6, mat('#CFE9F5', '#B3D9EC', '#E6F4FA'), { r: 2, dark: 1 });
    box(D, 112, 0, 18, 16, pk, { r: 4, dark: 2 });                                              // 굴뚝
    return { D, cv: D.canvas(), ax: 105, ay: 82 };
  });
}
export function cloudArt(v = 0) { // 몽글몽글 구름 (바다 위에 떠 있음)
  return memo(`cloud|${v}`, () => {
    const W = v ? 120 : 160, H = 60, D = new Dots(W, H), M = soft('#FFFFFF', '#EEF4F8', '#FFFFFF');
    const list = v ? [[30, 38, 18], [58, 28, 24], [88, 38, 18]] : [[30, 40, 18], [60, 28, 24], [96, 26, 26], [128, 40, 18]];
    blobs(D, list, M, { shift: [4, 5] });
    return { D, cv: D.canvas(), ax: Math.round(W / 2), ay: H - 6 };
  });
}
export function berryBushArt(v = 0) { // 라즈베리 덤불
  return memo(`berry|${v}`, () => {
    const W = v ? 56 : 76, H = 46, D = new Dots(W, H);
    groundShadow(D, W / 2 + 4, H - 5, W / 2 - 6, 4);
    const c = v ? [[16, 28, 13], [32, 22, 15], [42, 30, 11]] : [[16, 30, 13], [34, 22, 17], [54, 26, 15], [64, 32, 10]];
    blobs(D, c, soft('#9CD27E', '#82BE66', '#B6E19C'), { cut: H - 6 });
    const B = mat('#F0567E', '#D33C64', '#F784A2');
    for (let k = 0; k < (v ? 4 : 6); k++) { const x = 10 + Math.floor(h2(k, v, 71) * (W - 20)), y = 14 + Math.floor(h2(k, v, 72) * 20); ellipse(D, x, y, 4, 4, B, { cres: 0.4 }); }
    return { D, cv: D.canvas(), ax: Math.round(W / 2), ay: H - 6 };
  });
}
export function vanArt(v = 0) { // 핑크 캠핑 밴 (옆모습)
  return memo(`van|${v}`, () => {
    const W = 120, H = 72, D = new Dots(W, H), body = v ? mat('#F7B3C4', '#EA93A8', '#FBCFDA') : mat('#FFFFFF', '#E6E0D8', '#FFFFFF'), top = v ? mat('#FFFFFF', '#E6E0D8', '#FFFFFF') : mat('#F7B3C4', '#EA93A8', '#FBCFDA');
    groundShadow(D, 64, H - 6, 52, 5);
    box(D, 6, 8, 108, 26, top, { r: 14, dark: 3, lit: 2 });
    box(D, 4, 28, 112, 30, body, { r: 8, dark: 5, lit: 1 });
    for (const x of [16, 44, 72]) box(D, x, 14, 22, 16, GLASS, { r: 4, dark: 2, lit: 2 });
    box(D, 96, 14, 16, 18, GLASS, { r: 5, dark: 2 });
    ellipse(D, 60, 42, 7, 7, mat('#F7D35C', '#E8BF3C', '#FBE490'));                                           // 웃는 얼굴 스티커
    for (const x of [26, 92]) ellipse(D, x, 60, 9, 9, mat('#5B4A48', '#463836', '#6E5C59'), { cres: 0.3 });
    return { D, cv: D.canvas(), ax: 60, ay: H - 6 };
  });
}
function berryTop(D, cx, cy) { // 가게 지붕 위 큰 라즈베리
  const B = mat('#E8577A', '#C93E62', '#F27C99');
  for (const [dx, dy] of [[-10, 6], [0, 6], [10, 6], [-5, -2], [5, -2], [0, -10], [-14, -2], [14, -2]]) ellipse(D, cx + dx, cy + dy, 7, 7, B, { cres: 0.35 });
  ellipse(D, cx - 8, cy - 18, 8, 4, mat('#8CCB6A', '#72B355', '#A6DA88')); ellipse(D, cx + 8, cy - 18, 8, 4, mat('#8CCB6A', '#72B355', '#A6DA88'));
}
export function shopArt(v = 0) { // 줄무늬 차양 가게 (평지붕), v=1은 지붕 위 라즈베리
  return memo(`shop|${v}`, () => {
    const W = 168, H = 150, D = new Dots(W, H), WM = v ? WALLS[2] : WALLS[0], aw = v ? mat('#F28AA0', '#E06E86', '#F7A9BA') : ROOF_RED;
    groundShadow(D, 92, H - 8, 78, 8);
    box(D, 10, 20, 148, H - 28, WM, { r: 4, dark: 6, lit: 2 });
    box(D, 6, 12, 156, 16, mat('#FFFFFF', '#E9E2DA', '#FFFFFF'), { r: 3, dark: 2 });                     // 간판 띠
    for (let i = 0; i < 5; i++) for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) D.set(40 + i * 22 + a, 19 + b, aw.b);
    const awn = (d) => (px, py) => py >= 30 + d && py <= 58 - d && px >= 4 + d && px <= 163 - d;
    paint(D, 3, 29, 164, 59, awn(0), awn(2), aw, (px, py) => (py > 50 ? aw.s : Math.floor(px / 14) % 2 ? '#FFFFFF' : aw.b)); // 차양
    for (let x = 6; x < 162; x += 14) for (let j = 0; j < 4; j++) for (let a = 0; a < 7 - j * 2; a++) D.set(x + j + a, 58 + j, Math.floor(x / 14) % 2 ? '#FFFFFF' : aw.b); // 차양 끝 물결
    box(D, 18, 70, 60, 48, GLASS, { r: 3, dark: 2, lit: 2 });                                             // 큰 창
    for (const [x, c] of [[26, '#F7D35C'], [40, '#F29BB4'], [54, '#E85A55'], [66, '#8ED2EE']]) box(D, x, 100, 8, 14, mat(c, mix(c, '#7A5A48', 0.15), mix(c, '#FFFFFF', 0.3)), { r: 2, dark: 2 }); // 진열된 물건
    box(D, 100, 72, 40, H - 80, mat('#F7A9BA', '#E88FA3', '#FBC6D2'), { r: 4, dark: 3, lit: 1 });     // 문
    box(D, 106, 80, 28, 22, GLASS, { r: 3, dark: 2 });
    if (!v) return { D, cv: D.canvas(), ax: 84, ay: H - 8 };
    const T = new Dots(W, H + 36); T.p.set(D.p, W * 36); berryTop(T, 84, 22);
    return { D: T, cv: T.canvas(), ax: 84, ay: H + 36 - 8 };
  });
}
export function fenceArt() {
  return memo('fence', () => {
    const W = 90, H = 30, D = new Dots(W, H), M = mat('#FFFFFF', '#E6E0D8', '#FFFFFF');
    box(D, 0, 12, W, 6, M, { r: 2, dark: 2 });
    for (let x = 2; x < W - 6; x += 14) box(D, x, 0, 8, 26, M, { r: 3, dark: 2 });
    return { D, cv: D.canvas(), ax: 45, ay: 26 };
  });
}
export function streetLampArt() {
  return memo('streetlamp', () => {
    const D = new Dots(20, 66);
    line(D, 9, 14, 10, 60, '#7E8C9A');
    box(D, 3, 2, 14, 14, mat('#FFF1B8', '#F2DC86', '#FFFAE0'), { r: 4, dark: 2 });
    box(D, 4, 58, 12, 6, mat('#9AA6B2', '#7E8C9A', '#B4BEC8'), { r: 2, dark: 2 });
    return { D, cv: D.canvas(), ax: 10, ay: 62 };
  });
}
export function boatArt(v = 0) {
  return memo(`boat|${v}`, () => {
    const W = 72, H = 64, D = new Dots(W, H), hull = mat('#FFFFFF', '#E3E8EE', '#FFFFFF'), sail = mat('#FFFFFF', '#EEF1F4', '#FFFFFF');
    const sail2 = v ? mat('#F7C3D2', '#EBA6BB', '#FBD9E3') : mat('#F7D35C', '#E8BF3C', '#FBE490');
    ellipse(D, 36, 56, 32, 6, mat('#C2E8F7', '#ADDDF1', '#D6F0FA'));                                      // 물결 그림자
    const hl = (d) => (px, py) => py >= 42 + d && py <= 56 - d && Math.abs(px + 0.5 - 36) <= 30 - (py - 42) * 0.6 - d;
    paint(D, 4, 40, 68, 58, hl(0), hl(2), hull, (px, py) => (py >= 47 && py <= 49 ? '#E85A55' : px > 40 ? hull.s : hull.b));
    line(D, 36, 4, 37, 42, '#9A7A62');
    const s1 = (d) => (px, py) => py >= 6 + d && py <= 38 - d && px >= 39 + d && px + 0.5 <= 39 + (py - 6) * 0.8 - d;
    paint(D, 38, 5, 66, 39, s1(0), s1(2), sail, () => sail.b);
    const s2 = (d) => (px, py) => py >= 14 + d && py <= 38 - d && px <= 34 - d && px + 0.5 >= 34 - (py - 14) * 0.7 + d;
    paint(D, 14, 13, 35, 39, s2(0), s2(2), sail2, () => sail2.b);
    return { D, cv: D.canvas(), ax: 36, ay: 56 };
  });
}
export function parasolArt(v = 0) {
  return memo(`parasol|${v}`, () => {
    const W = 76, H = 84, D = new Dots(W, H), R = v ? mat('#F28AA0', '#E06E86', '#F7A9BA') : ROOF_RED;
    box(D, 6, 62, 40, 16, v ? mat('#8ED2EE', '#74C2E2', '#B5E4F4') : mat('#F7D35C', '#E8BF3C', '#FBE490'), { r: 3, dark: 2 }); // 비치 타월
    line(D, 37, 28, 38, 76, '#9A7A62');
    paint(D, 3, 9, 72, 43, oval(38, 26, 34, 16), oval(38, 26, 32, 14), R, (px) => (Math.floor((px + 2) / 9) % 2 ? '#FFFFFF' : R.b));
    return { D, cv: D.canvas(), ax: 38, ay: 76 };
  });
}
export function stoneArt(v = 0) {
  return memo(`stone|${v}`, () => {
    const W = v ? 26 : 36, H = v ? 16 : 20, D = new Dots(W, H);
    ellipse(D, W / 2, H / 2, W / 2 - 1, H / 2 - 1, OUT.stone, { cres: 0.3 });
    return { D, cv: D.canvas(), ax: Math.round(W / 2), ay: Math.round(H / 2) };
  });
}
// 바깥 소품 배치 (격자 칸마다 흔든 자리에 하나, 한 번 만들어 y 순으로 정렬): 사무실 둘레는 풀밭 공터(덤불과 꽃만 드문드문),
// 그 바깥은 덩어리진 숲(성긴 격자 + 낮은 주파수 잡음으로 무리와 빈터). 입구 길과 디딤돌 자리는 비운다.
const PATH_HW = 22;                                  // 입구 길 반폭 (월드)
export function outdoorProps() {
  return memo('outdoor', () => {
    const list = [], doorX = ENTRANCE.x, Wd = WORLD.w, Hd = WORLD.h;
    const add = (make, x, y, kind) => list.push({ make, x, y, sortY: y, kind });
    const distOut = (x, y) => Math.hypot(Math.max(0, -x, x - Wd), Math.max(0, -y, y - Hd));
    const nearPath = (x, y, pad) => (y > WALL_Y - 30 && Math.abs(x - doorX) < PATH_HW + pad) || inStage(x, y, pad);
    const inStage = () => false; // 공연 무대 없음
    const clump = (x, y) => { // 0~1, 약 260단위 크기의 덩어리
      const gx = x / 260, gy = y / 260, i = Math.floor(gx), j = Math.floor(gy), fx = gx - i, fy = gy - j, sm = (t) => t * t * (3 - 2 * t);
      const v = (a, b) => h2(a, b, 31), u = sm(fx), w = sm(fy);
      return (v(i, j) * (1 - u) + v(i + 1, j) * u) * (1 - w) + (v(i, j + 1) * (1 - u) + v(i + 1, j + 1) * u) * w;
    };
    // 디딤돌: 길이 끝난 자리부터 아래로, 살짝 좌우로 흔들리며
    // 공터: 덤불과 꽃 (촘촘한 격자, 벽에서 110 안쪽)
    const C1 = 40;
    for (let j = -4; j <= Math.ceil(Hd / C1) + 4; j++) for (let i = -4; i <= Math.ceil(Wd / C1) + 4; i++) {
      const x = i * C1 + (h2(i, j, 5) - 0.5) * 30, y = j * C1 + (h2(i, j, 6) - 0.5) * 30, d = distOut(x, y), r = h2(i, j, 7);
      if (d < 10 || d > 110 || nearPath(x, y, 30)) continue;
      if (r < 0.2) add(() => bushArt(r < 0.1 ? 1 : 0), x, y, 'bush');
      else if (r < 0.3) add(() => flowerPatchArt(r < 0.25 ? 0 : 1), x, y, 'flowers');
    }
    // 숲: 나무 (성긴 격자, 멀수록 빽빽, 무리 잡음)
    const C2 = 66;
    for (let j = -12; j <= Math.ceil((Hd + 640) / C2); j++) for (let i = -12; i <= Math.ceil((Wd + 760) / C2); i++) {
      const x = i * C2 + (h2(i, j, 15) - 0.5) * 44, y = j * C2 + (h2(i, j, 16) - 0.5) * 44, d = distOut(x, y), r = h2(i, j, 17);
      if (d < 60 || d > 700 || nearPath(x, y, 70)) continue;
      const p = Math.min(0.9, (d - 60) / 140) * (0.35 + 0.9 * clump(x, y));
      if (r < p) add(() => treeArt(Math.floor(h2(i, j, 18) * 3)), x, y, 'tree');
      else if (r < p + 0.1) add(() => bushArt(h2(i, j, 19) < 0.5 ? 1 : 0), x, y, 'bush');
    }
    // 바닷가 마을: 앞줄(큰 집·가게)과 뒷줄(작은 집)을 엇갈려 놓고 사이에 나무, 울타리, 가로등. 사무실 위 띠의 숲 소품은 치운다
    const houses = [], deco = [];
    const kinds = ['house', 'house', 'shop', 'house', 'house', 'shop'];
    for (let i = 0, x = -30; x < Wd + 60; i++) {
      const r = h2(i, 0, 91), kind = kinds[i % kinds.length];
      houses.push({ x, y: -14 + Math.round((r - 0.5) * 6), v: Math.floor(h2(i, 2, 91) * 5), kind, small: false });
      const gap = 86 + Math.floor(h2(i, 3, 91) * 48);
      const mx = x + gap / 2;
      if (i % 3 === 1) deco.push({ make: () => treeArt(2), x: mx, y: -8 });
      else if (i % 3 === 2) deco.push({ make: () => fenceArt(), x: mx, y: -6 });
      else deco.push({ make: () => streetLampArt(), x: mx, y: -74 });
      if (h2(i, 4, 91) < 0.8) houses.push({ x: mx + (h2(i, 5, 91) - 0.5) * 16, y: -116, v: Math.floor(h2(i, 6, 91) * 5), kind: i % 4 === 0 ? 'shop' : 'house', small: true });
      x += gap;
    }
    for (let j = 0; j < 6; j++) for (const side of [-1, 1]) { // 양옆 마을 (넓은 화면)
      const x = side < 0 ? -150 - Math.floor(h2(j, side, 92) * 90) : Wd + 150 + Math.floor(h2(j, side, 92) * 90), y = -40 + j * 95;
      houses.push({ x, y, v: Math.floor(h2(j, side, 93) * 5), kind: j % 3 === 2 ? 'shop' : 'house', small: j % 2 === 1 });
    }
    const nearHouse = (x, y) => houses.some((hh) => Math.abs(hh.x - x) < 58 && y > hh.y - 60 && y < hh.y + 40);
    for (let k = list.length - 1; k >= 0; k--) { const q = list[k]; if (q.y < SEA_Y + 60 || (q.y < -46 && q.x > -60 && q.x < Wd + 60) || nearHouse(q.x, q.y)) list.splice(k, 1); }
    for (let k = houses.length - 1; k >= 0; k--) if (houses[k].y > -60 && Math.abs(houses[k].x - STAGE.door.x) < 46) houses.splice(k, 1); // 뒷문 꼬불길 자리 비우기
    for (const hh of houses) add(() => (hh.kind === 'shop' ? shopArt(hh.v % 2) : houseArt(hh.v, hh.small)), hh.x, hh.y, 'house');
    list.push({ make: () => roadArt(), x: ROAD.x0, y: ROAD.y0, sortY: -1e9, kind: 'road' });
    { const segs = [STROLL_OUT, STROLL_BEACH, STROLL_BACK], near = (x, y, pad) => segs.some((p) => p.some(([px, py], i) => i < p.length - 1 && (() => { const [qx, qy] = p[i + 1], L = (qx - px) ** 2 + (qy - py) ** 2, t = Math.max(0, Math.min(1, ((x - px) * (qx - px) + (y - py) * (qy - py)) / (L || 1))); return Math.hypot(x - px - t * (qx - px), y - py - t * (qy - py)) < pad; })()));
      for (let k = list.length - 1; k >= 0; k--) { const q = list[k]; if (q.kind !== 'road' && q.kind !== 'boat' && q.kind !== 'cloud' && near(q.x, q.y, q.kind === 'house' ? 40 : 18)) list.splice(k, 1); }
      // 흙길 그림은 뺐다: 산책은 잔디 위를 자유롭게 걷고, 걷는 자리만 나무를 비워 둔다
      const plant = (i, x, y) => { const r = h2(i, Math.round(y), 97); add(r < 0.3 ? () => berryBushArt(r < 0.15 ? 1 : 0) : r < 0.6 ? () => bushArt(r < 0.45 ? 1 : 0) : () => flowerPatchArt(r < 0.8 ? 0 : 1), x, y, 'garden'); };
      for (let i = 0, y = 40; y < 380; i++, y += 38) { plant(i, -24 + (i % 2) * 6, y); plant(i + 50, 728 - (i % 2) * 6, y); } // 길과 사무실 사이 양옆
      for (let i = 0, x = 20; x < 700; i++, x += 46) if (Math.abs(x - ENTRANCE.x) > 40) plant(i + 100, x, 404); } // 사무실 아래
    for (const [i, x] of [120, 470, 860].entries()) add(() => vanArt(i % 2 ? 0 : 1), x, ROAD.cy(x) + 4, 'van');
    for (const d of deco) add(d.make, d.x, d.y, 'deco');
    for (const [i, x] of [-40, 150, 330, 520, 700, 880].entries()) add(() => parasolArt(i % 2), x, SEA_Y + 25, 'parasol');
    for (const [i, [x, y]] of [[-120, -232], [90, -214], [480, -210], [860, -218]].entries()) add(() => boatArt(i % 2), x, y, 'boat');
    add(() => cruiseArt(), 300, -214, 'cruise');
    for (const [i, [x, y]] of [[-60, -250], [180, -246], [420, -252], [620, -244], [880, -250]].entries()) list.push({ make: () => cloudArt(i % 2), x, y, sortY: 1e9, kind: 'cloud' }); // 구름은 맨 위에
    for (let x = ROAD.x0 + 20; x < ROAD.x1; x += 64) { // 길 양옆 라즈베리 덤불 (집·밴 자리 피함)
      const j = Math.round(x), side = h2(j, 1, 73) < 0.5 ? -1 : 1, y = ROAD.cy(x) + side * (ROAD.hw + 8);
      if (h2(j, 2, 73) < 0.65 && !nearHouse(x, y) && Math.abs(x - STAGE.door.x) > 30) add(() => berryBushArt(h2(j, 3, 73) < 0.5 ? 1 : 0), x, y + (side > 0 ? 10 : 0), 'berry');
    }
    list.sort((a, b) => a.sortY - b.sortY);
    return list;
  });
}
// ---------- 사내 공연 무대 ----------
// 대표실 뒷문 밖 숲 공터. 흙 마당 위에 노란 배경막(위가 둥근 판, 가랜드), 흰 무대 단(앞면 두께), 관객석 방석.
// 같은 도트 규칙: 2칸 외곽선(갈색 계열), 명암 2~3단, 왼쪽 위 빛, 낮은 채도(노랑, 흰색도 캐릭터 흰색보다 어둡게).
// 렌더러가 sortY 순서로 사람과 섞어 그린다(배경막과 무대 단은 공연자보다 먼저, 방석은 그 위에 서는 사람보다 먼저).
const STG = {
  soil: soft('#E6DCC7', '#D8CBB1', '#EEE6D6'),
  back: mat('#F1DC97', '#E3C978', '#F7EAB8'),
  backIn: mat('#F6E6AE', '#EAD48D', '#FAF0CC'),
  floor: mat('#F2EEE6', '#E1DACE', '#F7F4EE'),
  edge: mat('#E2D3BE', '#CDBAA0', '#EBE0D0'),
  cushion: mat('#CDD4DD', '#B8C1CD', '#DCE1E8'),
  flags: [mat('#EDB9C3', '#DDA0AC', '#F4CDD4'), mat('#B8D7E6', '#9EC4D7', '#CDE3EE'), mat('#EFE0A4', '#DECB86', '#F5EAC0')],
};
function stageGroundArt() {
  return memo('stageGround', () => {
    const S = STAGE, x0 = S.yard.x0, x1 = S.yard.x1, y0 = S.backdrop.y - 8, y1 = S.yard.y1; // 아래로 사무실 벽까지는 풀밭과 디딤돌 길
    const W = (x1 - x0) * 3, H = (y1 - y0) * 3, D = new Dots(W, H);
    paint(D, 0, 0, W - 1, H - 1, rrect(0, 0, W, H, 36), rrect(2, 2, W - 4, H - 4, 34), STG.soil, () => STG.soil.b);
    return { D, cv: D.canvas(), ax: (S.x - x0) * 3, ay: H };
  });
}
function backdropArt() {
  return memo('backdrop', () => {
    const B = STAGE.backdrop, W = B.w * 3, H = B.h * 3, D = new Dots(W + 2, H + 2), r = 54;
    box(D, 0, 0, W, H + 30, STG.back, { r, dark: 0, lit: 2 });
    box(D, 14, 14, W - 28, H + 30, STG.backIn, { r: r - 14, dark: 0 });
    // 가랜드: 처지는 줄 + 삼각 깃발 (분홍, 하늘, 노랑)
    const sag = (x) => 22 + Math.round(16 * Math.sin(Math.PI * x / W));
    for (let x = 18; x < W - 18; x++) for (const k of [0, 1]) D.set(x, sag(x) + k, STG.back.o);
    for (let i = 0, x = 36; x < W - 40; i++, x += 34) {
      const M = STG.flags[i % 3], y = sag(x + 7) + 1;
      const tri = (px, py) => py >= y && py <= y + 15 && Math.abs(px + 0.5 - (x + 8)) <= 8 * (1 - (py - y) / 16);
      const inner = (px, py) => py >= y + 2 && py <= y + 12 && Math.abs(px + 0.5 - (x + 8)) <= 8 * (1 - (py - y) / 16) - 2.2;
      paint(D, x - 1, y - 1, x + 18, y + 17, tri, inner, M, (px, py) => (px > x + 9 ? M.s : M.b));
    }
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
function stageFloorArt() {
  return memo('stageFloor', () => {
    const F = STAGE.floor, W = F.w * 3, H = (F.h + F.edge) * 3, D = new Dots(W, H), top = F.h * 3;
    box(D, 0, top - 30, W, H - top + 30, STG.edge, { r: 10, dark: 6 });              // 앞면 (두께)
    box(D, 0, 0, W, top, STG.floor, { r: 12, dark: 3, lit: 2 });                     // 무대 윗면
    for (const y of [42, 84, 120]) for (let x = 14; x < W - 14; x++) if ((x + y) % 210 > 6) D.set(x, y, STG.floor.s); // 긴 판자 이음매 (드물게)
    return { D, cv: D.canvas(), ax: W / 2, ay: H };
  });
}
function waitCushionArt() { // 2부 공연자 대기석: 관객 방석보다 조금 작고 연노랑 (무대 배경막과 같은 계열)
  return memo('waitCushion', () => {
    const D = new Dots(40, 20);
    ellipse(D, 20, 10, 19, 9, mat('#EFE3B8', '#E0D09C', '#F5ECCB'));
    return { D, cv: D.canvas(), ax: 20, ay: 14 };
  });
}
function cushionArt() {
  return memo('cushion', () => {
    const D = new Dots(46, 22);
    ellipse(D, 23, 11, 22, 10, STG.cushion);
    return { D, cv: D.canvas(), ax: 23, ay: 15 };
  });
}
export function stageProps() {
  return memo('stageProps', () => {
    const S = STAGE, list = [];
    list.push({ make: stageGroundArt, x: S.x, y: S.yard.y1, sortY: -9999 });
    S.path.forEach((p, i) => list.push({ make: () => stoneArt(i % 2), x: p.x, y: p.y, sortY: -9998 })); // 뒷문에서 마당까지 디딤돌
    for (const w of S.wings) list.push({ make: waitCushionArt, x: w.x, y: w.y + 2, sortY: w.y - 8 }); // 2부 공연자 대기석 (무대 앞 한 줄)
    list.push({ make: backdropArt, x: S.x, y: S.backdrop.y + S.backdrop.h, sortY: -9000 });
    list.push({ make: stageFloorArt, x: S.x, y: S.floor.y + S.floor.h + S.floor.edge, sortY: -8000 });
    for (const a of S.aud) list.push({ make: cushionArt, x: a.x, y: a.y + 2, sortY: a.y - 8 });
    return list;
  });
}

// 입구 앞 길 (사무실 한 장에 굽는다): 현관 앞 둥근 마당 + 아래로 곧게, 끝은 둥글게. 길 무늬는 짧은 가로선 몇 개
function paintPath(D, wy) {
  const cx = ENTRANCE.x * 3, hw = PATH_HW * 3, y0 = wy + 10, y1 = (WORLD.h + RING - 10) * 3;
  const U = (px, py, d = 0) => rrect(cx - hw + d, y0 + d, 2 * (hw - d), y1 - y0 - 2 * d, hw - d)(px, py) || oval(cx, wy + 50, 120 - d, 30 - d)(px, py);
  const P = OUT.path;
  for (let py = y0 - 2; py <= y1 + 2; py++) for (let px = cx - 124; px <= cx + 124; px++) {
    if (!U(px, py)) continue;
    D.set(px, py, U(px, py, 2) ? P.b : P.o);
  }
  for (let k = 0; k < 9; k++) { const x = cx - 40 + Math.floor(h2(k, 1, 77) * 80), y = wy + 60 + Math.floor(h2(k, 2, 77) * (y1 - wy - 80)); if (U(x - 4, y, 4) && U(x + 6, y, 4)) for (let a = 0; a < 6; a++) D.set(x + a, y, P.mark); }
}

// ---------- 사무실 전체 한 장 (바닥, 벽, 창문, 유리벽, 입구, 바깥 풀밭 테두리와 길, 그림자) ----------
export function worldArt(staff) {
  return memo('world', () => {
    const O = RING * 3, W = WORLD.w * 3, H = WORLD.h * 3, D = new Dots(W + 2 * O, H + 2 * O, O), wy = WALL_Y * 3;
    // 바깥 풀밭 (렌더러 배경과 같은 무늬라 이음매가 없다) + 복도 바닥 (벽 안쪽 전체)
    for (let py = -O; py < H + O; py++) for (let px = -O; px < W + O; px++) D.set(px, py, grassAt(px, py));
    const hall = floorPal(ZONE_FLOOR.hall.b);
    for (let py = 0; py < wy + 18; py++) for (let px = 0; px < W; px++) D.set(px, py, plankAt(px, py, 11, hall));
    paintPath(D, wy);
    // 구역 바닥
    ROOMS.forEach((r, i) => paintZone(D, r.x * 3, r.y * 3, r.w * 3, r.h * 3, ZONE_FLOOR[r.id], 3 + i));
    // 팀 러그: 팀 자리(책상 줄)를 감싸는 크기, 구역 안쪽으로 맞춤
    for (const r of ROOMS) {
      const seats = (staff || []).filter((e) => e.team === r.id && e.id !== 'assistant').map((e) => e.seat);
      if (!seats.length || !TEAMS[r.id].tint) continue;
      const x0 = Math.max(r.x + 8, Math.min(...seats.map((q) => q.x)) - 34), x1 = Math.min(r.x + r.w - 8, Math.max(...seats.map((q) => q.x)) + 34);
      const y0 = Math.max(r.y + 8, Math.min(...seats.map((q) => q.y)) - 28), y1 = Math.min(r.y + r.h - 8, Math.max(...seats.map((q) => q.y)) + 16);
      teamRug(D, x0 * 3, y0 * 3, (x1 - x0) * 3, (y1 - y0) * 3, ZONE_FLOOR[r.id].b, TEAMS[r.id].tint);
    }
    // 러그
    const lg = roomById.lounge, ct = CAFE_TABLES;
    { const R0 = FLOOR.rug; FLOOR.rug = { b: '#F0DFD2', ring: '#E6D0C0', o: mix('#D6BBA6', INK, 0.72) }; ovalRug(D, ((ct[0].x + ct[1].x) / 2) * 3, (lg.y + 56) * 3, 64 * 3, 22 * 3); /* 탕비실 안에 들어가는 작은 러그 */ FLOOR.rug = R0; } // 카페 테이블 밑 러그
    { const R0 = FLOOR.rug; FLOOR.rug = { b: '#EED8D6', ring: '#E4C9C6', o: mix('#D9B5B1', INK, 0.72) }; ovalRug(D, CEO_SEAT.x * 3, (REPORT_SPOTS[0].y + 1) * 3, 58 * 3, 14 * 3); FLOOR.rug = R0; } // 보고 자리 타원 매트
    // 유리벽 (대표실, 회의실): 9칸 두께 띠 + 나무 기둥, 문 자리 비움
    for (const r of ROOMS) {
      if (!r.walled) continue;
      const x0 = r.x * 3, y0 = r.y * 3, x1 = (r.x + r.w) * 3 - 1, y1 = (r.y + r.h) * 3 - 1, d0 = (r.door.x - 18) * 3, d1 = (r.door.x + 18) * 3, T = 9;
      const top = r.door.side === 'top', inGap = (py) => (top ? py < y0 + T : py > y1 - T);
      const ring = (px, py) => px >= x0 && px <= x1 && py >= y0 && py <= y1 && (px < x0 + T || px > x1 - T || py < y0 + T || py > y1 - T) && !(inGap(py) && px >= d0 && px < d1);
      paintBand(D, x0, y0, x1, y1, ring, RAMPS.glass);
      const dy = top ? y0 : y1 - T + 1, posts = [[d0 - 8, dy], [d1, dy]];          // 문 양쪽 기둥
      for (let x = x0 + 120; x < x1 - 30; x += 138) {
        if (!top || x + 8 < d0 - 10 || x > d1 + 10) posts.push([x, y0]);
        if (top || x + 8 < d0 - 10 || x > d1 + 10) posts.push([x, y1 - T + 1]);
      }
      for (const [x, y] of posts) box(D, x, y - 2, 8, T + 4, RAMPS.trim, { r: 1, dark: 0 });
    }
    // 위쪽 벽 (회반죽) + 창문 (바깥 나무)
    paintBand(D, -2, -2, W + 1, 41, (px, py) => py <= 41 && px >= -2 && px <= W + 1 && py >= -2, RAMPS.plaster, false);
    for (let x = 30; x < WORLD.w - 70; x += 116) {
      const X = x * 3, Y = 3;
      box(D, X, Y, 186, 33, RAMPS.wood, { r: 3, dark: 2 });
      const glass = (px, py) => px >= X + 6 && px < X + 180 && py >= Y + 6 && py < Y + 27;
      for (let py = Y + 6; py < Y + 27; py++) for (let px = X + 6; px < X + 180; px++) D.set(px, py, py < Y + 12 ? RAMPS.sky.l : RAMPS.sky.b);
      for (const [dx, rx] of [[30, 22], [76, 28], [130, 24], [168, 18]]) paint(D, X + dx - rx - 1, Y + 10, X + dx + rx + 1, Y + 27, (px, py) => glass(px, py) && oval(X + dx, Y + 32, rx, 16)(px, py), (px, py) => glass(px, py) && oval(X + dx, Y + 32, rx - 2, 14)(px, py) && py >= Y + 6, mat('#CFE0C2', '#BCD2AD', '#DDE9D3'), (px, py) => (px > X + dx + rx * 0.4 ? '#BCD2AD' : '#CFE0C2'));
      box(D, X + 90, Y + 3, 6, 27, RAMPS.wood, { r: 1, dark: 0 });
    }
    // 벽 장식: 창문 양옆 커튼, 창문 사이 벽에 액자와 시계
    const curtain = pastel('#F0DCD5');
    for (let x = 30; x < WORLD.w - 70; x += 116) {
      const X = x * 3;
      for (const cx of [X - 6, X + 176]) { box(D, cx, 0, 16, 40, curtain, { r: 5, dark: 3, lit: 1 }); box(D, cx + 2, 22, 12, 5, pastel('#E2C3B6'), { r: 2, dark: 0 }); } // 묶은 끈
    }
    const frameAt = (cx, kind) => {
      const X = cx * 3 - 16, Y = 6;
      box(D, X, Y, 32, 28, RAMPS.wood, { r: 3, dark: 2 });
      if (kind === 'clock') { box(D, X, Y, 32, 28, RAMPS.plaster, { r: 3, dark: 0 }); ellipse(D, cx * 3, Y + 14, 13, 13, RAMPS.white); line(D, cx * 3, Y + 6, cx * 3, Y + 14, INK); line(D, cx * 3 + 1, Y + 6, cx * 3 + 1, Y + 14, INK); line(D, cx * 3, Y + 14, cx * 3 + 7, Y + 14, INK); line(D, cx * 3, Y + 15, cx * 3 + 7, Y + 15, INK); return; }
      const inside = (px, py) => px >= X + 5 && px < X + 27 && py >= Y + 5 && py < Y + 23;
      for (let py = Y + 5; py < Y + 23; py++) for (let px = X + 5; px < X + 27; px++) D.set(px, py, kind === 'sea' ? (py < Y + 15 ? '#E1EEF3' : '#C9DDE6') : py < Y + 13 ? '#EAF1F3' : '#D3E2C4');
      if (kind === 'field') paint(D, X + 4, Y + 8, X + 28, Y + 23, (px, py) => inside(px, py) && oval(X + 16, Y + 26, 12, 10)(px, py), (px, py) => inside(px, py) && oval(X + 16, Y + 26, 10, 8)(px, py), mat('#C3D6AE', '#AFC59A', '#D0E0BE'), () => '#C3D6AE');
      if (kind === 'sea') ellipse(D, X + 20, Y + 11, 3, 3, mat('#F2DC9C', '#E2C981', '#F7E8BC'));
    };
    { const gaps = []; for (let x = 30; x + 116 < WORLD.w - 70; x += 116) gaps.push(x + 62 + 27); // 창문 사이 빈 벽 가운데
      gaps.filter((g) => Math.abs(g - STAGE.door.x) > 30).forEach((g, i, a) => frameAt(g, i === Math.floor(a.length / 2) ? 'clock' : i % 2 ? 'sea' : 'field')); }
    // 대표실 뒷문: 위쪽 벽과 대표실 유리벽 위쪽을 문 폭만큼 비우고 복도 판자, 양옆 나무 문틀
    { const dx0 = (STAGE.door.x - STAGE.door.w / 2) * 3, dx1 = (STAGE.door.x + STAGE.door.w / 2) * 3, yb = (roomById.ceo.y + 4) * 3;
      for (let py = -2; py < yb; py++) for (let px = dx0; px < dx1; px++) D.set(px, py, plankAt(px, py, 11, hall));
      for (const x of [dx0 - 8, dx1]) box(D, x, -2, 8, yb + 4, RAMPS.trim, { r: 1, dark: 0 }); }
    // 옆벽과 아래벽 (입구 빈칸), 현관 매트
    const wall = (px, py) => py >= 36 && py < wy + 18 && (px < 18 || px >= W - 18 || (py >= wy && !(px >= DOOR_GAP.x0 * 3 && px < DOOR_GAP.x1 * 3)));
    paintBand(D, 0, 36, W - 1, wy + 17, wall, RAMPS.trim);
    const mx = (DOOR_GAP.x0 + 4) * 3, mw = (DOOR_GAP.x1 - DOOR_GAP.x0 - 8) * 3, mt = mat('#DFCBAE', '#CDB693', '#E8D9C3');
    box(D, mx, wy - 6, mw, 42, mt, { r: 5, dark: 3 });
    for (let x = mx + 8; x < mx + mw - 8; x += 7) line(D, x, wy, x, wy + 28, mt.s);
    // 사무실 건물 그림자 (빛은 왼쪽 위): 오른쪽 벽 바깥과 아래 벽 바깥 풀밭을 한 단계 진하게
    for (let py = 12; py < wy + 18 + 12; py++) for (let px = 0; px < W + 12; px++) {
      if ((px < W && py < wy + 18) || (py >= wy + 18 && px < 12)) continue;
      if (py >= wy + 18 && px >= DOOR_GAP.x0 * 3 && px < DOOR_GAP.x1 * 3) continue;
      const c = D.get(px, py); if (c) D.set(px, py, shadowOf(c));
    }
    // 소품 그림자 (실루엣을 오른쪽 아래로, 한 칸은 한 번만)
    const done = new Uint8Array(D.w * D.h);
    for (const p of allProps(staff)) {
      const a = p.make();
      castFromArt(D, a, Math.round((p.x - a.ax / 3) * 3), Math.round((p.y - a.ay / 3) * 3), done);
    }
    return { D, cv: D.canvas(), ax: 0, ay: 0, wx: -RING, wy: -RING }; // wx, wy = 이 그림 0번 칸의 월드 좌표
  });
}
