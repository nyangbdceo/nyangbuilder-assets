// 캔버스 렌더러.
// 단계: 전체 보기(화면에 맞는 배율 자동) / 넓게(배율 1.5, 전체 보기보다 클 때만, 있으면 기본) / 보통(배율 3, 원본 도트 1칸 = 1 CSS px) / 가까이(배율 6, 1칸 = 2 CSS px).
// 캐릭터는 도트 1칸이 늘 정수 기기 픽셀이 되도록 원본, 1/2판, 1/3판 중 하나를 고른다 (소수배 렌더 금지).
// 바닥, 벽, 소품 그림은 art.js(사무실 전체 한 장 worldArt + 소품 목록 allProps). 여기서는 붙이고 정렬만 한다.
// 모든 월드 사각형은 wg(기기 픽셀로 반올림하는 래퍼)로만 그린다.
import { WORLD, ROOMS, TEAMS, ENTRANCE, roomById, LINES, charOf, STAGE, CHAR_SCALE } from './data.js';
import { worldArt, allProps, outdoorProps, grassTile, ZONE_FLOOR, GRASS, stageProps, seaTile, shoreStrip, SEA_Y, SHORE_W } from './art.js';

const SP = window.AIO_SPRITES || {};
// 확대: 맞춤 + 50%, 100%, 150%.
// 100% = 캐릭터 원본 도트 1칸이 화면 1 CSS px (배율 3, 캐릭터 70x80, 예전 "보통"). 도트 그림을 원래 크기로 보는 값이라 이미지 보기의 100%와 같다.
// 퍼센트 단계는 모두 원본 그림(축소판 없음)이고 원본 1칸이 정수 기기 px여야 한다. 그렇지 않은 화면에서는 20%p 안의 가장 가까운
// 원본 배율로 바꾸고(dpr 3: 50 -> 67, 150 -> 133, 같은 거리면 100% 쪽), 그것도 없으면 그 단계를 뺀다(dpr 1: 50, 150 없음).
// 맞춤(사무실 전체)은 퍼센트 단계가 아닌 별도 버튼이고 예전 "전체"처럼 축소판(1/2, 1/3판)을 쓸 수 있다(overviewZoom). 맞춤 이하 단계는 뺀다.
// 이름 단계(level)는 글자 크기용으로 배율에서 나온다: all = 맞춤, wide = 100% 미만, normal = 100% 이상.
export const LEVELS = ['all', 'wide', 'normal', 'close'];
const LEVEL_ZOOM = { wide: 1.5, normal: 3, close: 6 }; // 이름으로 고를 때: 넓게 50%, 보통 100%, 가까이 200%
export const ZOOM_100 = 3;
const PCT_STEPS = [50, 100, 150];
export const pctOf = (z) => Math.round((z / ZOOM_100) * 100);
const D = 1 / 3; // 도트 1칸 = 월드 1/3단위
const LINE = '#7B5B4B';
const BUBBLES_PER_ZONE = 2; // 한 구역에 동시에 뜨는 말풍선 수 (쌓임 방지)     // 소품 외곽선 (따뜻한 갈색)
const INK = '#4A342C';      // 캐릭터 외곽선, 말풍선 테두리
const FONT = '-apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Pretendard", sans-serif';

const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mix = (a, b, t) => { const A = hex(a), B = hex(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
const hash = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h % 997) / 997; };
const snap = (v) => Math.round(v * 3) / 3;

// ---------- 캐릭터 도트 ----------
// 그림은 characters 폴더의 PNG(1px = 도트 1칸)를 boot.js가 읽어 { w, h, rows, palette } 꼴로 window.AIO_SPRITES에 넣는다.
// 키: '<이름>' = 앞모습(꼭 있어야 함), '<이름>_happy' 기쁨, '<이름>_sad' 속상함, '<이름>_walk' 걷기, '<이름>_rest' 쉬기 (없으면 앞모습으로).
// 화면에서는 원본, 1/2판, 1/3판 중 도트 1칸이 정수 기기 픽셀이 되는 것을 고른다 (소수배 금지).
export const GEAR_PAD = 0;
export const GEAR_SIDE = 0;

// 작은 그림의 정수배 확대는 축소판을 만들기 전에 칸을 늘려서 한다 (확대한 뒤 줄여야 작게 볼 때도 얼굴이 뭉개지지 않는다)
const keyScale = (key) => CHAR_SCALE[key.split('_')[0]] || 1;
function baseGrid(key) {
  const sp = SP[key], s = keyScale(key);
  const g = Array.from({ length: sp.h * s }, (_, y) => Array.from({ length: sp.w * s }, (_, x) => { const ch = sp.rows[Math.floor(y / s)][Math.floor(x / s)]; return ch === '.' ? null : sp.palette[ch]; }));
  return { w: sp.w * s, h: sp.h * s, g };
}

function downGrid(G, k, lines = 'keep') { // k x k 묶음 축소: 진한 선 우선, 투명 과반이면 투명, 나머지는 최빈색
  if (k === 1) return G;
  const w = Math.ceil(G.w / k), h = Math.ceil(G.h / k), g = [];
  const dark = (c) => { const [r, gg, b] = hex(c); return r * 0.3 + gg * 0.59 + b * 0.11 < 115; };
  // lines 'thin' = 안쪽 1칸 선이 많은 그림: 묶음의 절반쯤이 진해야 선으로 (2칸 바깥 외곽선은 남고 안쪽 잔선은 옅어진다)
  const need = lines === 'thin' ? (k === 2 ? 2 : 3) : k === 2 ? 1 : 2;
  for (let y = 0; y < h; y++) {
    const row = [];
    for (let x = 0; x < w; x++) {
      const cnt = new Map(), dk = new Map(); let t = 0, n = 0;
      for (let yy = y * k; yy < Math.min(G.h, y * k + k); yy++) for (let xx = x * k; xx < Math.min(G.w, x * k + k); xx++) {
        const c = G.g[yy][xx]; n++;
        if (!c) { t++; continue; }
        cnt.set(c, (cnt.get(c) || 0) + 1);
        if (dark(c)) dk.set(c, (dk.get(c) || 0) + 1);
      }
      const dsum = [...dk.values()].reduce((a, b) => a + b, 0);
      if (dsum >= need) row.push([...dk].sort((a, b) => b[1] - a[1])[0][0]);
      else if (t * 2 > n) row.push(null);
      else row.push([...cnt].sort((a, b) => b[1] - a[1])[0][0]);
    }
    g.push(row);
  }
  return { w, h, g };
}

const cache = new Map();
// key = 포즈 그림 키, k = 1(원본) 2(1/2판) 3(1/3판)
export function spriteCanvas(key, team, flip, k = 1) {
  const id = `${key}|${flip}|${k}`;
  let c = cache.get(id);
  if (c) return c;
  const S = downGrid(baseGrid(key), k, 'thin'); // 'thin' = 칸의 절반쯤이 진해야 선으로 (1칸 선이 많은 그림에서 얼굴이 뭉개지지 않게)
  c = document.createElement('canvas');
  c.width = S.w; c.height = S.h;
  const g2 = c.getContext('2d');
  const img = g2.createImageData(S.w, S.h);
  for (let y = 0; y < S.h; y++) for (let x = 0; x < S.w; x++) {
    const col = S.g[y][x];
    if (!col) continue;
    const [r, gg, b] = hex(col), o = (y * S.w + (flip ? S.w - 1 - x : x)) * 4;
    img.data[o] = r; img.data[o + 1] = gg; img.data[o + 2] = b; img.data[o + 3] = 255;
  }
  g2.putImageData(img, 0, 0);
  const W = SP[key].w * keyScale(key);
  c.ax = Math.round(W / 2 / k); // 발 자리 = 그림 가운데
  c.pad = 0; c.bw = Math.ceil(W / k);
  cache.set(id, c);
  return c;
}

// 캐릭터별 상태 그림. walk 걷기, front 자리 작업과 기본(사원증 사진, 대사 창 얼굴), happy 승인 직후와 인사, angry 지연, sulky 결재 대기,
// rest 라운지 카페 휴식, sofa 소파 위, jump 기지개. 없는 그림은 앞모습으로 (옆으로 걸을 땐 방향 따라 좌우 반전)
const has = (k) => !!SP[k];
export function posesOf(name) {
  const p = (suf) => (has(`${name}_${suf}`) ? `${name}_${suf}` : name);
  return { front: name, walk: p('walk'), happy: p('happy'), angry: p('sad'), sulky: p('sad'), rest: p('rest'), sofa: p('rest'), jump: p('happy') };
}
export { charOf };
export const scaleOf = () => 1; // 확대는 그림에 미리 넣는다 (baseGrid)
export const baseKeyOf = (e) => charOf(e); // 사원증 사진, 대사 창 얼굴 (그림이 없으면 null)
const GREET = new Set([...LINES.arrive, ...LINES.approved]);

// 직원 상태 -> 포즈와 표정 (key = 그림 키)
export function poseOf(e, mood) {
  const S = posesOf(charOf(e));
  const happy = mood === 'happy' || (e.bubble && GREET.has(e.bubble.text)); // 승인 직후, 인사할 때
  const moodKey = mood === 'angry' ? S.angry : mood === 'sulky' ? S.sulky : happy ? S.happy : null;
  if (e.state === 'walk') return { key: moodKey || S.walk, flip: e.dir === 'left' };
  if (e.state === 'show') return { key: S.happy }; // 공연
  if (e.state === 'watch') return { key: e.bubble ? S.happy : moodKey === S.angry ? S.front : moodKey || S.front };
  if (e.state === 'break') return { key: e.squish ? S.sofa : mood === 'angry' ? S.sulky : S.rest };
  if (e.state === 'idle') return { key: e.idle && e.idle.kind === 'stretch' ? S.jump : moodKey || S.front };
  return { key: moodKey || S.front };
}

// 위아래 움직임 (원본 도트 칸 단위). 걷기는 통통, 일할 땐 1칸 까딱, 수다는 들썩, 기지개와 승인 직후는 깡총.
function bobOf(e, office, t) {
  const h = hash(e.id) * 10;
  if (e.state === 'show') return office.show && office.show.start ? Math.round(Math.abs(Math.sin(t * Math.PI / 480)) * 8) : 0; // 공연: 모두 같은 박자(0.48초)로 통통
  if (e.state === 'watch') return e.bubble ? Math.floor(t / 180) % 2 * 3 : Math.floor(t / 960 + h) % 2; // 관객: 환호할 때 들썩
  if (e.id !== 'ceo' && office.clock < e.happyUntil && e.state !== 'walk') return Math.round(Math.abs(Math.sin(t / 140 + h)) * 6);
  if (e.state === 'walk') return [0, 3, 4, 3][Math.floor(e.dist / 2.5) % 4];
  if (e.state === 'idle') {
    const k = e.idle && e.idle.kind;
    if (k === 'stretch') return Math.round(Math.abs(Math.sin(t / 300 + h)) * 7);
    if (k === 'visit' || k === 'chat') return e.bubble ? Math.floor(t / 200) % 2 * 2 : Math.floor(t / 700 + h) % 2;
    return Math.floor(t / 800 + h) % 2;
  }
  if (e.state === 'work') return e.chatWith && e.bubble ? Math.floor(t / 200) % 2 * 2 : Math.floor(t / 420 + h) % 2;
  if (e.state === 'meet') return e.bubble ? Math.floor(t / 220) % 2 * 2 : Math.floor(t / 900 + h) % 2;
  if (e.state === 'break' && !e.squish) return Math.floor(t / 1000 + h) % 2;
  return 0;
}

// 도트 칸 크기 고르기: 배율에서 원본(1), 1/2판(2), 1/3판(3) 중 한 칸이 정수 기기 픽셀인 것
export function lodFor(zoom, dpr) {
  const n = zoom * dpr;
  for (const k of [1, 2, 3]) {
    const c = (n * k) / 3;
    if (Math.abs(c - Math.round(c)) < 1e-6 && Math.round(c) >= 1) return { k, cell: Math.round(c) };
  }
  return { k: 3, cell: Math.max(1, Math.round(n)) }; // 정수 칸이 안 나오는 배율일 때
}

export class Renderer {
  constructor(canvas) {
    this.cv = canvas;
    this.g = canvas.getContext('2d');
    this.cam = { x: 0, y: 0 };
    this.dpr = 1;
    this.hover = null;
    this.selected = null;
    this.office = null;
    this.level = 'all';
    this.zoom = 1;
    this.safe = { top: 58, bottom: 66, side: 14 }; // 전체 보기에서 HUD(위 시계 띠, 아래 조작 바)를 피할 여백
    const self = this;
    this.wg = {
      set fillStyle(v) { self.g.fillStyle = v; },
      fillRect(x, y, w, h) {
        const s = self.zoom * self.dpr, ox = Math.round(self.cam.x * s), oy = Math.round(self.cam.y * s);
        const x0 = Math.round(x * s) - ox, y0 = Math.round(y * s) - oy;
        let x1 = Math.round((x + w) * s) - ox, y1 = Math.round((y + h) * s) - oy;
        if (w > 0 && x1 === x0) x1++; if (h > 0 && y1 === y0) y1++;
        if (x1 < 0 || y1 < 0 || x0 > self.cv.width || y0 > self.cv.height) return;
        if (x1 > x0 && y1 > y0) self.g.fillRect(x0, y0, x1 - x0, y1 - y0);
      },
    };
  }

  resize(cssW, cssH) {
    this.dpr = Math.max(1, Math.round(window.devicePixelRatio || 1));
    const c = this.cssW ? this.center() : { x: WORLD.w / 2, y: WORLD.h / 2 };
    const was = this.level, z0 = this.zoom;
    this.cssW = cssW; this.cssH = cssH;
    this.cv.width = cssW * this.dpr; this.cv.height = cssH * this.dpr;
    this.cv.style.width = cssW + 'px'; this.cv.style.height = cssH + 'px';
    this.setZoom(was === 'all' ? this.overviewZoom() : this.nearestStep(z0), c.x, c.y); // 맞춤이면 새 화면에 다시 맞추고, 아니면 가장 가까운 단계
  }
  // 전체 보기 배율: 후보 = 캐릭터 도트 1칸이 정수 기기 픽셀이 되는 배율(3c/(k*dpr)). 안전 영역에 맞는 것 중 가장 큰 값.
  overviewZoom() {
    const fit = Math.min((this.cssW - this.safe.side * 2) / WORLD.w, (this.cssH - this.safe.top - this.safe.bottom) / (WORLD.h - STAGE.top)); // 바다까지 한 화면에
    const cands = [];
    for (const k of [1, 2, 3]) for (let c = 1; c <= 12; c++) { const z = (3 * c) / (k * this.dpr); if (z < LEVEL_ZOOM.normal - 1e-9) cands.push(z); }
    const okz = cands.filter((z) => z <= fit + 1e-9);
    return okz.length ? Math.max(...okz) : Math.min(...cands);
  }
  // 이 화면의 퍼센트 단계 (맞춤 제외) [{ z, p }]: 원본 1칸이 정수 기기 px인 배율만
  pctSteps() {
    const d = this.dpr, fit = this.overviewZoom(), out = [];
    for (const t of PCT_STEPS) {
      let p = t;
      if (Math.abs((t * d) / 100 - Math.round((t * d) / 100)) > 1e-9) { // 정수 기기 px가 아니면 가까운 원본 배율 (100m/dpr)
        const lo = (100 * Math.floor((t * d) / 100)) / d, hi = (100 * Math.ceil((t * d) / 100)) / d;
        const near = [lo, hi].filter((q) => q > 0 && Math.abs(q - t) <= 20 + 1e-9).sort((a, b) => { const da = Math.abs(a - t) - Math.abs(b - t); return Math.abs(da) > 1e-6 ? da : Math.abs(a - 100) - Math.abs(b - 100); });
        if (!near.length) continue;
        p = near[0];
      }
      const z = (p * ZOOM_100) / 100;
      if (z > fit + 1e-9 && !out.some((o) => Math.abs(o.z - z) < 1e-9)) out.push({ z, p });
    }
    return out;
  }
  // 고를 수 있는 배율 목록 [{ z, p?, fit? }]: 첫 칸이 맞춤, 그다음 퍼센트 단계 (−/+, 휠, 키가 이 순서로 움직인다)
  steps() { return [{ z: this.overviewZoom(), fit: true }, ...this.pctSteps()]; }
  // 처음 열 때, Esc로 돌아올 때: 50%가 맞춤보다 크면 50%, 아니면 맞춤
  defaultZoom() { const s50 = this.pctSteps().find((s) => s.p === 50); return s50 ? s50.z : this.overviewZoom(); }
  nearestStep(z) { return this.steps().reduce((a, b) => (Math.abs(b.z - z) < Math.abs(a.z - z) ? b : a)).z; }
  setLevel(level, cx, cy) { // 이름으로 (확인용, 호환): all = 맞춤, wide = 50%, normal = 100%, close = 가장 큰 단계
    const st = this.steps(), z = level === 'all' ? st[0].z : level === 'close' ? st[st.length - 1].z : LEVEL_ZOOM[level] ?? st[0].z;
    this.setZoom(Math.max(z, st[0].z), cx, cy);
  }
  setZoom(z, cx, cy) {
    this.zoom = z;
    this.level = Math.abs(z - this.overviewZoom()) < 1e-9 ? 'all' : z < ZOOM_100 - 1e-9 ? 'wide' : 'normal';
    const L = lodFor(this.zoom, this.dpr);
    this.mini = L.k !== 1; this.cell = L.cell; // (그리기는 lodFor로 매번 계산)
    this.setCenter(cx ?? WORLD.w / 2, cy ?? WORLD.h / 2);
  }
  viewW() { return this.cssW / this.zoom; }
  viewH() { return this.cssH / this.zoom; }
  clampCam() {
    // 마을까지 끌어서 볼 수 있는 범위: 사무실 양옆 PAN_X, 위로 바다(STAGE.top), 아래로 PAN_Y. 범위보다 화면이 크면 그 방향은 가운데 고정
    const vw = this.viewW(), vh = this.viewH(), PAN_X = 420, PAN_Y = 160, T = STAGE.top;
    const x0 = -PAN_X, x1 = WORLD.w + PAN_X, y0 = T - this.safe.top / this.zoom, y1 = WORLD.h + PAN_Y;
    this.cam.x = vw >= x1 - x0 ? (WORLD.w - vw) / 2 : Math.max(x0, Math.min(x1 - vw, this.cam.x));
    this.cam.y = vh >= y1 - y0 ? (T + WORLD.h - vh) / 2 : Math.max(y0, Math.min(y1 - vh, this.cam.y));
  }
  center() { return { x: this.cam.x + this.viewW() / 2, y: this.cam.y + this.viewH() / 2 }; }
  setCenter(x, y) { this.cam.x = x - this.viewW() / 2; this.cam.y = y - this.viewH() / 2; this.clampCam(); }
  toWorld(px, py) { return { x: this.cam.x + px / this.zoom, y: this.cam.y + py / this.zoom }; }
  toDev(x, y) {
    const s = this.zoom * this.dpr;
    return [Math.round(x * s) - Math.round(this.cam.x * s), Math.round(y * s) - Math.round(this.cam.y * s)];
  }
  // 도트 아트(art.js) 그리기: 기준 칸(ax, ay)을 월드 (wx, wy)에 맞춘다. 도트 1칸 = 배율 x dpr / 3 기기 픽셀.
  blit(a, wx, wy) {
    const s = this.zoom * this.dpr, k = s / 3;
    const x = Math.round(snap(wx - a.ax / 3) * s) - Math.round(this.cam.x * s);
    const y = Math.round(snap(wy - a.ay / 3) * s) - Math.round(this.cam.y * s);
    const w = Math.round(a.cv.width * k), h = Math.round(a.cv.height * k);
    if (x > this.cv.width || y > this.cv.height || x + w < 0 || y + h < 0) return;
    this.g.drawImage(a.cv, x, y, w, h);
  }

  // 큰 도트 그림(사무실 전체 한 장): 화면에 보이는 칸만 잘라 그린다. a.wx, a.wy = 그림 0번 칸의 월드 좌표 (바깥 테두리만큼 음수)
  blitWorld(a) {
    const s = this.zoom * this.dpr, k = s / 3;
    const ox = Math.round(this.cam.x * s) - Math.round((a.wx || 0) * s), oy = Math.round(this.cam.y * s) - Math.round((a.wy || 0) * s);
    const i0 = Math.max(0, Math.floor(ox / k)), j0 = Math.max(0, Math.floor(oy / k));
    const i1 = Math.min(a.cv.width, Math.ceil((ox + this.cv.width) / k) + 1), j1 = Math.min(a.cv.height, Math.ceil((oy + this.cv.height) / k) + 1);
    if (i1 <= i0 || j1 <= j0) return;
    this.g.drawImage(a.cv, i0, j0, i1 - i0, j1 - j0, i0 * k - ox, j0 * k - oy, (i1 - i0) * k, (j1 - j0) * k);
  }

  draw(office, t) {
    const g = this.g;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.imageSmoothingEnabled = false;
    // 바깥 풀밭: 반복 무늬 한 장으로 화면 전체 (도트 1칸 = 배율 x dpr / 3 기기 픽셀, 월드 원점에 맞춤)
    const s = this.zoom * this.dpr, k = s / 3;
    if (!this._grass) this._grass = g.createPattern(grassTile().cv, 'repeat');
    this._grass.setTransform(new DOMMatrix([k, 0, 0, k, -Math.round(this.cam.x * s), -Math.round(this.cam.y * s)]));
    g.fillStyle = this._grass;
    g.fillRect(0, 0, this.cv.width, this.cv.height);
    { // 바다 (SEA_Y 위) + 해변 띠
      const seaB = Math.round((SEA_Y + 2) * s) - Math.round(this.cam.y * s);
      if (seaB > 0) { if (!this._sea) this._sea = g.createPattern(seaTile().cv, 'repeat'); this._sea.setTransform(new DOMMatrix([k, 0, 0, k, -Math.round(this.cam.x * s), -Math.round(this.cam.y * s)])); g.fillStyle = this._sea; g.fillRect(0, 0, this.cv.width, Math.min(seaB, this.cv.height)); }
      const sh = shoreStrip(); for (let x = Math.floor(this.cam.x / SHORE_W) * SHORE_W; x < this.cam.x + this.viewW() + SHORE_W; x += SHORE_W) this.blit(sh, x, SEA_Y);
    }
    this.blitWorld(worldArt(office.staff));
    for (const p of outdoorProps()) this.blit(p.make(), p.x, p.y); // 나무, 덤불, 꽃, 디딤돌 (사무실 밖이라 직원과 안 겹친다)
    if (office.meeting) { const m = roomById.meeting; fill(this.wg, m.x + 3, m.y + 3, m.w - 6, m.h - 6, 'rgba(255,214,120,0.12)'); }
    const items = [];
    for (const p of allProps(office.staff)) {
      items.push({ y: p.sortY, draw: () => {
        this.blit(p.make(), p.x, p.y);
        if (p.lights) for (const [x, y, on, off, ph] of p.lights) fill(this.wg, x, y, 2 * D, 2 * D, Math.floor(t / 600 + ph) % 3 !== 0 ? on : off);
      } });
    }
    if (false) for (const p of stageProps()) items.push({ y: p.sortY, draw: () => this.blit(p.make(), p.x, p.y) }); // 사내 공연 무대 (대표실 뒷문 밖)
    const people = peopleOf(office);
    for (const e of people) items.push({ y: e.y, person: e });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) {
      if (it.person) this.drawPerson(it.person, office, t);
      else it.draw();
    }
    if (office.show && office.show.start) this.drawConfetti(t);
    this._signs = this.layoutSigns(office);
    this.drawOverlays(people, office, t);
    this.drawSigns(office); // 간판은 말풍선보다 위 (말풍선은 간판 자리를 피해 놓인다)
  }

  // ---------- 사내 공연: 색종이(분홍, 하늘, 노랑)와 음표(초록, 분홍)가 무대 위로 흩날린다 ----------
  // 시각 t만으로 정해지는 입자 (도트 1칸 = 월드 1/3, wg 반올림으로 그려 번지지 않게)
  drawConfetti(t) {
    const B = STAGE.backdrop, F = STAGE.floor, x0 = F.x - 6, w = F.w + 12, y0 = B.y - 4, h = F.y + F.h - y0;
    const COL = ['#EDB1BE', '#A9D2E6', '#EFD98E', '#F4C6CF', '#BCDDEB'];
    for (let i = 0; i < 64; i++) {
      const r1 = hash(`c${i}`), r2 = hash(`d${i}`), sp = 0.012 + r2 * 0.012, ph = r1 * 1000;
      const y = y0 + ((t * sp + ph) % h), x = x0 + ((r1 * 997 + Math.sin(t / 700 + i) * 6) % w + w) % w;
      const tall = Math.floor(t / 260 + i) % 2; // 빙글 도는 느낌: 가로 세로가 번갈아
      fill(this.wg, snap(x), snap(y), (tall ? 3 : 5) * D, (tall ? 5 : 3) * D, COL[i % COL.length]);
    }
    for (let i = 0; i < 7; i++) { // 음표: 동그란 머리 + 기둥 + 꼬리, 천천히 위로 떠오르며 좌우로 흔들림
      const r1 = hash(`n${i}`), c = i % 2 ? '#E7A6B6' : '#9FCB97', o = i % 2 ? '#B97F8E' : '#76A16E';
      const y = F.y + F.h - 8 - ((t * 0.01 + r1 * 400) % (h - 10)), x = snap(x0 + r1 * w + Math.sin(t / 500 + i) * 5);
      const yy = snap(y), U = 2 * D, px = (dx, dy, ww, hh, col) => fill(this.wg, x + dx * U, yy + dy * U, ww * U, hh * U, col); // 음표는 2칸 단위
      px(0, 6, 5, 4, o); px(1, 6, 3, 3, c); px(4, -2, 2, 9, o); px(6, -2, 3, 2, o); px(6, 0, 2, 2, o);
    }
  }

  // ---------- 사람 ----------
  drawPerson(e, office, t) {
    const mood = e.id === 'ceo' ? (e.bubble ? 'happy' : 'calm') : office.mood(e);
    const p = poseOf(e, mood);
    const L = lodFor(this.zoom, this.dpr), sc = scaleOf(e);
    const c = spriteCanvas(p.key, e.team, !!p.flip, L.k);
    const d = L.cell * sc, g = this.g, unit = (L.k / 3) * sc; // unit = 도트 1칸의 월드 크기
    const bob = Math.round(bobOf(e, office, t) / L.k);
    const [fx, fy] = this.toDev(e.x, e.y);
    // 바닥 그림자 (점프해도 바닥에 남는다)
    const sw = Math.round(c.bw * 0.62), sh = Math.max(1, Math.round(2 / L.k));
    g.fillStyle = 'rgba(90,60,40,0.18)';
    [[0.55, -2], [1, -1], [1, 0], [0.55, 1]].forEach(([k, row]) => {
      const w = Math.round(sw * k);
      g.fillRect(fx - Math.round(w / 2) * d, fy + row * sh * d, w * d, sh * d);
    });
    const x0 = fx - c.ax * d, y0 = fy - (c.height + bob) * d;
    g.drawImage(c, x0, y0, c.width * d, c.height * d);
    const pad = Math.round(GEAR_PAD / L.k) * unit;
    e._pose = p;
    e._box = { x: e.x - (c.ax - c.pad) * unit, y: e.y - c.height * unit + pad, w: c.bw * unit, h: c.height * unit - pad, top: y0 + Math.round(GEAR_PAD / L.k) * d };
  }

  // ---------- 구역 표지판 ----------
  // 구역 표지판: 구역 위 테두리에 걸친 작은 나무 간판(갈색 2칸 외곽선, 계단 모서리, 못 두 개, 매단 끈).
  // 소품은 구역 안쪽에 있어 테두리 위 자리는 비고, 말풍선은 간판 자리를 피해 놓이며, 간판은 맨 마지막에 그린다.
  layoutSigns(office) {
    const g = this.g, d = this.dpr;
    g.setTransform(1, 0, 0, 1, 0, 0);
    const fs = Math.round(({ all: 10.5, wide: 11 }[this.level] || 12) * d);
    g.font = `700 ${fs}px ${FONT}`;
    return ROOMS.map((r) => {
      const on = r.id === 'meeting' && !!office.meeting;
      const label = on ? `${office.meeting.name} 중` : TEAMS[r.id].name;
      const tw = Math.ceil(g.measureText(label).width), pad = 10 * d, w = tw + pad * 2, h = fs + 10 * d;
      const [zx, zy] = this.toDev(r.x, r.y), [zx2] = this.toDev(r.x + r.w, r.y);
      const x = w > zx2 - zx - 16 * d ? Math.round((zx + zx2) / 2 - w / 2) : zx + Math.round(8 * d);
      return { x, y: Math.round(zy - h / 2), w, h, label, on, fs, pad };
    });
  }
  drawSigns(office) {
    const g = this.g, d = this.dpr, u = Math.max(1, Math.round(d));
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.textBaseline = 'middle';
    const notch = (x, y, w, h, c) => { g.fillStyle = c; g.fillRect(x + 2 * u, y, w - 4 * u, h); g.fillRect(x + u, y + u, w - 2 * u, h - 2 * u); g.fillRect(x, y + 2 * u, w, h - 4 * u); };
    for (const s of this._signs || this.layoutSigns(office)) {
      const { x, y, w, h } = s;
      for (const sx of [x + 9 * u, x + w - 10 * u]) { g.fillStyle = '#8B6B57'; g.fillRect(sx, y - 5 * u, u, 5 * u); g.fillRect(sx - u, y - 6 * u, 3 * u, 2 * u); } // 매단 끈과 못
      notch(x, y, w, h, '#6B4E3D');
      notch(x + 2 * u, y + 2 * u, w - 4 * u, h - 4 * u, s.on ? '#FFF1C9' : '#F5E6CC');
      g.fillStyle = s.on ? '#F2DCA0' : '#E6D0AC'; g.fillRect(x + 3 * u, y + h - 4 * u, w - 6 * u, 2 * u);         // 아래 그늘
      g.fillStyle = s.on ? '#FFF8E2' : '#FBF2E2'; g.fillRect(x + 4 * u, y + 3 * u, w - 8 * u, u);                 // 위 밝은 줄
      g.fillStyle = '#B08A6A'; for (const nx of [x + 4 * u, x + w - 6 * u]) g.fillRect(nx, y + Math.round(h / 2) - u, 2 * u, 2 * u);
      g.font = `700 ${s.fs}px ${FONT}`;
      g.fillStyle = s.on ? '#8A5A1E' : '#5B4034';
      g.fillText(s.label, x + s.pad, y + h / 2 + d * 0.5);
    }
    const fs = Math.round(({ all: 10.5, wide: 11 }[this.level] || 12) * d);
    g.font = `700 ${fs}px ${FONT}`;
    const [ex, ey] = this.toDev(ENTRANCE.x, ENTRANCE.y + 4);
    g.textAlign = 'center'; g.fillStyle = '#8B6B57'; g.fillText('입구', ex, ey); g.textAlign = 'left';
  }

  // ---------- 이름표, 선택 표시, 말풍선 ----------
  drawOverlays(people, office, t) {
    const g = this.g, d = this.dpr;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.textBaseline = 'middle'; g.textAlign = 'center';
    const sorted = [...people].sort((a, b) => a.y - b.y);
    const fz = { all: 0.9, wide: 0.95, normal: 1, close: 1.15 }[this.level] || 1;
    const nfs = Math.round(11 * fz * d);
    g.font = `600 ${nfs}px ${FONT}`;
    for (const e of sorted) {
      if (e !== this.selected && e !== this.hover) continue; // 이름은 마우스를 올리거나 골랐을 때만
      const [x, y] = this.toDev(e.x, e.y + 4);
      const tw = Math.ceil(g.measureText(e.name).width), pad = 4 * d, h = nfs + 5 * d;
      g.fillStyle = 'rgba(58,40,32,.88)';
      g.fillRect(x - Math.round(tw / 2) - pad, y, tw + pad * 2, h);
      g.fillStyle = '#FFFFFF'; g.fillText(e.name, x, y + h / 2 + d * 0.5);
    }
    const sel = this.selected;
    if (sel && sel._box && sel.state !== 'off') {
      const [x] = this.toDev(sel.x, sel.y);
      const m = this.level === 'close' ? 2 : 1, q = d * m;
      const top = sel._box.top - (10 + Math.round(Math.abs(Math.sin(t / 260)) * 4)) * q;
      const rows = [9, 7, 5, 3, 1];
      rows.forEach((w, i) => { g.fillStyle = INK; g.fillRect(x - Math.round((w + 2) / 2) * q, top + i * 2 * q - q, (w + 2) * q, 3 * q); });
      rows.forEach((w, i) => { g.fillStyle = '#4A9EFF'; g.fillRect(x - Math.round(w / 2) * q, top + i * 2 * q, w * q, 2 * q); });
    }
    const fs = Math.round(12.5 * fz * d);
    const placed = (this._signs || []).map((s) => ({ x: s.x - 2 * d, y: s.y - 7 * d, w: s.w + 4 * d, h: s.h + 9 * d }));
    const hits = (b) => placed.some((o) => b.x < o.x + o.w && b.x + b.w > o.x && b.y < o.y + o.h && b.y + b.h > o.y);
    // 말풍선: 구역마다 동시에 최대 BUBBLES_PER_ZONE개, 쌓지 않는다 (겹치면 한 번만 위로 비켜 보고, 그래도 겹치면 이번엔 안 띄움).
    // 우선순위: 고른 직원 > 마우스 > 대표 > 보고 중인 사람 > 최근에 말한 사람
    g.font = `600 ${fs}px ${FONT}`;
    const zoneOf = (e) => (ROOMS.find((r) => e.x >= r.x && e.x <= r.x + r.w && e.y >= r.y && e.y <= r.y + r.h) || { id: 'hall' }).id;
    const rank = (e) => (e === this.selected ? 0 : e === this.hover ? 1 : e.id === 'ceo' ? 2 : e.state === 'report' ? 3 : 4);
    const talking = sorted.filter((e) => e.bubble && e._box && !(e.state === 'report' && e.queued)).sort((a, b) => rank(a) - rank(b) || b.bubble.until - a.bubble.until);
    const perZone = {}; this._bubbles = perZone; // (확인용: 구역별로 띄운 말풍선 수)
    for (const e of talking) {
      const z = zoneOf(e), must = rank(e) < 2;
      if (!must && (perZone[z] || 0) >= BUBBLES_PER_ZONE) continue;
      const [x] = this.toDev(e.x, e.y);
      const text = e.bubble.text;
      const tw = Math.ceil(g.measureText(text).width), pad = 7 * d, h = fs + 10 * d;
      const bw = tw + pad * 2, bx = Math.max(4 * d, Math.min(this.cv.width - bw - 4 * d, x - Math.round(tw / 2) - pad)); // 화면 밖으로 안 나가게
      const tailY = e._box.top - 2 * d;
      let by = tailY - h - 5 * d;
      const area = () => ({ x: bx - 3 * d, y: by - 3 * d, w: bw + 6 * d, h: h + 6 * d });
      if (hits(area())) { by -= h + 4 * d; if (hits(area()) && !must) continue; }
      perZone[z] = (perZone[z] || 0) + 1;
      placed.push(area());
      g.fillStyle = INK; g.fillRect(bx, by - d, bw, h + 2 * d); g.fillRect(bx - d, by, bw + 2 * d, h);
      g.fillStyle = '#FFFDF9'; g.fillRect(bx, by, bw, h);
      g.fillStyle = 'rgba(123,91,75,0.14)'; g.fillRect(bx, by + h - 2 * d, bw, 2 * d);
      g.fillStyle = INK;
      if (by + h + 5 * d < tailY) g.fillRect(x - d, by + h, d, tailY - by - h);
      else {
        g.fillRect(x - 3 * d, by + h, 6 * d, 2 * d); g.fillRect(x - 2 * d, by + h + 2 * d, 4 * d, 2 * d); g.fillRect(x - d, by + h + 4 * d, 2 * d, d);
        g.fillStyle = '#FFFDF9'; g.fillRect(x - 2 * d, by + h, 4 * d, 2 * d); g.fillRect(x - d, by + h + 2 * d, 2 * d, 2 * d);
      }
      g.fillStyle = INK; g.fillText(text, bx + bw / 2, by + h / 2);
    }
    // 보고 줄에서 기다리는 사람: 말풍선 대신 머리 오른쪽 위에 작은 "…" 표시 (점 셋이 차례로 진해진다). 말풍선 밑에 걸리지 않게 머리에 살짝 겹쳐 놓고 말풍선 뒤에 그린다
    const q = Math.max(1, Math.round(d * fz));
    for (const e of sorted) {
      if (e.state !== 'report' || !e.queued || !e._box) continue;
      const [x] = this.toDev(e.x, e.y), w = 13 * q, h = 8 * q, bx = x + 4 * q, by = e._box.top - h + 3 * q;
      g.fillStyle = INK; g.fillRect(bx + q, by, w - 2 * q, h); g.fillRect(bx, by + q, w, h - 2 * q);
      g.fillStyle = '#FFFDF9'; g.fillRect(bx + q, by + q, w - 2 * q, h - 2 * q);
      const on = Math.floor(t / 420) % 3;
      for (let i = 0; i < 3; i++) { g.fillStyle = i === on ? INK : '#B9A493'; g.fillRect(bx + (3 + i * 3) * q, by + 3 * q, 2 * q, 2 * q); }
    }
    g.textAlign = 'left';
  }

  hit(wx, wy, office) {
    const people = peopleOf(office).sort((a, b) => b.y - a.y);
    return people.find((e) => e._box && wx >= e._box.x && wx <= e._box.x + e._box.w && wy >= e._box.y && wy <= e._box.y + e._box.h + 4) || null;
  }
}

// 화면에 그릴 사람: 대표 + 출근한 직원 (캐릭터 그림이 있는 사람만)
export function peopleOf(office) {
  return [office.ceo, ...office.staff.filter((e) => e.state !== 'off')].filter((e) => charOf(e));
}

// 월드 좌표 사각형 하나 (wg 래퍼에 칠한다)
function fill(g, x, y, w, h, c) { g.fillStyle = c; g.fillRect(x, y, w, h); }

// 미니맵: 오른쪽 위 작은 지도. 바깥은 옅은 풀색, 복도와 구역은 실제 바닥색, 칸 사이는 갈색 선.
// 직원은 팀 색 점(갈색 테두리), 고른 직원은 파란 점, 카메라가 보는 곳은 파란 테두리.
export function drawMinimap(cv, office, view) {
  const d = Math.max(1, Math.round(window.devicePixelRatio || 1));
  const w = cv.clientWidth, h = cv.clientHeight;
  if (!w) return;
  if (cv.width !== w * d || cv.height !== h * d) { cv.width = w * d; cv.height = h * d; }
  const g = cv.getContext('2d');
  const T = STAGE.top, k = Math.min((w * d) / WORLD.w, (h * d) / (WORLD.h - T)); // 위로 공연 무대까지
  const R = (v) => Math.round(v * k), RY = (v) => Math.round((v - T) * k);
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = mix(GRASS.b, '#FFFFFF', 0.25); g.fillRect(0, 0, cv.width, cv.height);
  const L = Math.max(1, Math.round(d * 0.75));
  const rect = (x, y, ww, hh, c) => { g.fillStyle = c; g.fillRect(R(x), RY(y), R(x + ww) - R(x), RY(y + hh) - RY(y)); };
  const frame = (x, y, ww, hh, c, t) => { const x0 = R(x), y0 = RY(y), x1 = R(x + ww), y1 = RY(y + hh); g.fillStyle = c; g.fillRect(x0, y0, x1 - x0, t); g.fillRect(x0, y1 - t, x1 - x0, t); g.fillRect(x0, y0, t, y1 - y0); g.fillRect(x1 - t, y0, t, y1 - y0); };
  rect(-50, T, WORLD.w + 100, SEA_Y - T, '#8ED2EE'); rect(-50, SEA_Y, WORLD.w + 100, 26, '#F7E8C6'); // 미니맵 바다·해변
  if (false) { const S = STAGE; rect(S.yard.x0, S.backdrop.y - 8, S.yard.x1 - S.yard.x0, S.yard.y1 - (S.backdrop.y - 8), '#E6DCC7'); rect(S.x - 3, S.yard.y1, 6, -S.yard.y1, '#E6DCC7'); rect(S.backdrop.x, S.backdrop.y, S.backdrop.w, S.backdrop.h - 10, '#F1DC97'); rect(S.floor.x, S.floor.y, S.floor.w, S.floor.h, '#F2EEE6'); frame(S.floor.x, S.floor.y, S.floor.w, S.floor.h, '#B39A86', L); }
  rect(0, 0, WORLD.w, WORLD.h, ZONE_FLOOR.hall.b);
  for (const r of ROOMS) { rect(r.x, r.y, r.w, r.h, mix(ZONE_FLOOR[r.id].b, '#8A6B56', 0.05)); frame(r.x, r.y, r.w, r.h, r.walled ? '#8A6B56' : '#B39A86', r.walled ? L + 1 : L); }
  frame(0, 0, WORLD.w, WORLD.h, '#6B4E3D', L + 1);
  const dot = Math.max(3, Math.round(3 * d));
  for (const e of peopleOf(office)) {
    const sel = e === view.selected, r = sel ? dot + 2 * L : dot;
    const x = R(e.x) - (r >> 1), y = RY(e.y) - (r >> 1);
    g.fillStyle = INK; g.fillRect(x - L, y - L, r + 2 * L, r + 2 * L);
    g.fillStyle = sel ? '#4A9EFF' : ((TEAMS[e.team] || {}).tint || '#D3D3D7'); g.fillRect(x, y, r, r);
  }
  g.strokeStyle = '#4A9EFF'; g.lineWidth = L + 1; // 지금 보는 곳 = 액센트 (벽 선과 헷갈리지 않게)
  const x0 = Math.max(0, R(view.cam.x)), y0 = Math.max(0, RY(view.cam.y)), x1 = Math.min(cv.width, R(view.cam.x + view.viewW())), y1 = Math.min(cv.height, RY(view.cam.y + view.viewH()));
  g.strokeRect(x0 + (L + 1) / 2, y0 + (L + 1) / 2, x1 - x0 - L - 1, y1 - y0 - L - 1);
}

// 정보 카드와 대사 창의 얼굴 (원본 도트 + 팀 소품)
export function paintAvatar(canvas, team, key, k = 1, crop) {
  if (!key || !SP[key]) { canvas.width = canvas.height = 0; return; } // 그림이 없으면 빈 칸
  const c = spriteCanvas(key, team, false, k);
  if (crop && crop.face != null) crop = { w: crop.w, h: crop.h, padTop: 4, side: 2 }; // 사원증 사진: 머리 위 4칸 여백, 몸 가운데
  if (crop) { // crop = { w, h, padTop }: w x h칸 사진. 몸 가운데(ax)를 가로 가운데에, 맨 위 칠한 칸(소품 포함)을 padTop 아래에 둔다
    const ctx = c.getContext('2d'), px = ctx.getImageData(0, 0, c.width, c.height).data;
    let top = 0; while (top < c.height && ![...Array(c.width).keys()].some((x) => px[(top * c.width + x) * 4 + 3])) top++;
    let x0 = c.width, x1 = -1;
    for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (px[(y * c.width + x) * 4 + 3]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
    // 좌우: 몸 가운데 기준, 단 꼬리, 소품이 틀(좌우 M칸)에 닿으면 안쪽으로 민다. 틀보다 넓으면 그림 전체를 가운데
    const M = crop.side ?? 0;
    let dx = Math.floor(crop.w / 2) - c.ax;
    if (x1 - x0 + 1 > crop.w - 2 * M) dx = Math.floor((crop.w - (x1 - x0 + 1)) / 2) - x0;
    else if (dx + x0 < M) dx = M - x0;
    else if (dx + x1 > crop.w - 1 - M) dx = crop.w - 1 - M - x1;
    canvas.width = crop.w; canvas.height = crop.h;
    const g = canvas.getContext('2d'); g.clearRect(0, 0, crop.w, crop.h);
    g.drawImage(c, dx, (crop.padTop ?? 1) - top); // 정수 칸 이동만 (확대, 축소 없음)
    return;
  }
  canvas.width = c.width; canvas.height = c.height;
  const g = canvas.getContext('2d');
  g.clearRect(0, 0, c.width, c.height);
  g.drawImage(c, 0, 0);
}

// 팀 소품 표식 (이 판에는 팀 소품이 없다): 빈 칸
export function paintGear(canvas) {
  canvas.width = canvas.height = 0;
  return false;
}
