// 업무 책상: 아래 바의 '업무지시'(지시문 복사 + 오늘 일정)와 '보고함'(팀 보고 검토).
// 서버는 읽기 전용이라, 버튼은 Claude Code에 붙여 넣을 문장을 복사만 한다. 검토 표시는 이 브라우저에만 남는다.
// 내용은 desk.json (비서실장 Claude가 팀 보고가 끝날 때마다 reports에 한 줄씩 추가한다).
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DAYS = ['일', '월', '화', '수', '목', '금', '토'];
const store = {
  get() { try { return JSON.parse(localStorage.getItem('desk-review') || '{}'); } catch { return {}; } },
  set(v) { try { localStorage.setItem('desk-review', JSON.stringify(v)); } catch { /* 저장 못 해도 화면은 동작 */ } },
};

let data = { plan: {}, tasks: [], reports: [] };
async function load() {
  try {
    const r = await fetch('desk.json', { cache: 'no-store' });
    if (r.ok) data = await r.json();
  } catch { /* 파일이 없으면 빈 책상 */ }
  const n = (data.reports || []).filter((x) => !store.get()[x.id]).length;
  $('rep-count').textContent = n;
  $('rep-count').classList.toggle('has', n > 0);
}

async function copy(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const t = document.createElement('textarea'); t.value = text; document.body.append(t); t.select();
    try { document.execCommand('copy'); } finally { t.remove(); }
  }
  toast('복사했어요. Claude Code 창에 붙여 넣으면 그 팀이 일해요.');
}
let toastTimer = 0;
function toast(msg) {
  const el = $('desk-toast'); el.textContent = msg; el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
}

function renderTasks() {
  const today = DAYS[new Date().getDay()];
  const plan = data.plan || {};
  const todayItems = [...(plan[today] || []), ...(plan['매일'] || [])];
  const head = `<div class="desk-today"><b>오늘(${today}) 할 일</b>${todayItems.length ? `<ul>${todayItems.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '<p class="desk-muted">일정이 없어요.</p>'}</div>`;
  const teams = (data.tasks || []).map((t, i) => `
    <section class="desk-team"><h4>${esc(t.team)}</h4>
      ${(t.items || []).map((it, j) => `<button class="desk-task" data-t="${i}" data-j="${j}"><span>${esc(it.label)}</span><em data-lbl="${esc(it.label)}" data-paste="${needsPaste(it.prompt) ? 1 : 0}">${needsPaste(it.prompt) ? '복사' : '업무지시'}</em></button>`).join('')}
    </section>`).join('');
  $('desk-body').innerHTML = '<div id="desk-runs"></div>' + head + teams; paintRuns(); paintTaskStates();
  $('desk-body').querySelectorAll('.desk-task').forEach((b) => {
    b.onclick = () => { const t = data.tasks[+b.dataset.t], it = t.items[+b.dataset.j]; runNow(t.team, it.label, it.prompt); };
  });
}

// 결과물(마크다운) 간단히 보여 주기: 제목, 목록, 굵게, 표, 인용, 링크 글자
function mdToHtml(md) {
  const inline = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  const out = []; let table = null;
  const flush = () => { if (table) { out.push('<table>' + table.map((r, i) => '<tr>' + r.map((c) => (i ? `<td>${inline(c)}</td>` : `<th>${inline(c)}</th>`)).join('') + '</tr>').join('') + '</table>'); table = null; } };
  for (const line of md.split(/\r?\n/)) {
    if (/^\s*\|.*\|\s*$/.test(line)) { if (/^\s*\|[\s:|-]+\|\s*$/.test(line)) continue; (table = table || []).push(line.trim().slice(1, -1).split('|').map((c) => c.trim())); continue; }
    flush();
    const h = line.match(/^(#{1,4})\s+(.*)/);
    if (h) out.push(`<h${h[1].length + 2}>${inline(h[2])}</h${h[1].length + 2}>`);
    else if (/^\s*[-*]\s+/.test(line)) out.push(`<p class="li">• ${inline(line.replace(/^\s*[-*]\s+/, ''))}</p>`);
    else if (/^\s*>\s?/.test(line)) out.push(`<blockquote>${inline(line.replace(/^\s*>\s?/, ''))}</blockquote>`);
    else if (/^\s*---+\s*$/.test(line)) out.push('<hr>');
    else if (line.trim()) out.push(`<p>${inline(line)}</p>`);
  }
  flush();
  return out.join('');
}
function renderReports() {
  const rev = store.get();
  const list = [...(data.reports || [])].reverse();
  if (!list.length) { $('desk-body').innerHTML = '<p class="desk-muted">아직 올라온 보고가 없어요. \'업무지시\'에서 일을 맡기면 끝날 때 여기에 보고가 쌓여요.</p>'; return; }
  $('desk-body').innerHTML = list.map((r) => {
    const st = rev[r.id];
    return `<article class="desk-rep ${st ? 'done' : ''}" data-id="${esc(r.id)}">
      <div class="desk-rep-top"><span class="desk-chip">${esc(r.team)}</span><span class="desk-muted">${esc(r.date)}</span>${st ? `<span class="desk-st">${st === 'ok' ? '승인함' : '수정 요청함'}</span>` : ''}</div>
      <h4>${esc(r.title)}</h4>
      <p>${esc(r.summary)}</p>
      ${r.file ? `<p class="desk-file">결과물: ${esc(r.file)}</p><button class="desk-view" data-file="${esc(r.file)}">결과물 보기</button><div class="desk-doc" hidden></div>` : ''}
      ${r.next ? `<p class="desk-next">다음 단계: ${esc(r.next)}</p>` : ''}
      <div class="desk-act">
        <button class="desk-ok">승인</button>
        <button class="desk-fix">수정 요청</button>
      </div>
      <div class="desk-note" hidden><textarea rows="2" placeholder="고칠 점을 적어 주세요"></textarea><button class="desk-send">수정 요청 보내기</button></div>
    </article>`;
  }).join('');
  $('desk-body').querySelectorAll('.desk-rep').forEach((el) => {
    const id = el.dataset.id, r = data.reports.find((x) => x.id === id);
    const mark = (st) => { const v = store.get(); v[id] = st; store.set(v); load(); renderReports(); };
    const who = r.agent ? `${r.team} 직원(${r.agent})에게 맡겨: ` : `${r.team}에서 이 보고를 올린 직원(모르면 이 일에 맞는 팀 직원)에게 맡겨: `;
    el.querySelector('.desk-ok').onclick = async () => { if (!r.next) { mark('ok'); toast('승인했어요.'); return; } if (await runNow(r.team, `승인: ${r.next}`, `${who}"${r.title}" 보고 승인. 다음 단계(${r.next}) 진행해줘.`)) mark('ok'); };
    const vb = el.querySelector('.desk-view');
    if (vb) vb.onclick = async () => { // 결과물 보기: 카드 아래로 펼치기 / 다시 누르면 접기
      const doc = el.querySelector('.desk-doc');
      if (!doc.hidden) { doc.hidden = true; vb.textContent = '결과물 보기'; return; }
      vb.textContent = '불러오는 중…';
      try { const j = await fetch('/api/result?file=' + encodeURIComponent(vb.dataset.file), { cache: 'no-store' }).then((x) => x.json()); doc.innerHTML = j.ok ? mdToHtml(j.text) : `<p>${esc(j.error)}</p>`; }
      catch { doc.innerHTML = '<p>서버에 연결하지 못했어요.</p>'; }
      doc.hidden = false; vb.textContent = '접기';
    };
    el.querySelector('.desk-fix').onclick = () => { const n = el.querySelector('.desk-note'); n.hidden = !n.hidden; n.querySelector('textarea').focus(); };
    el.querySelector('.desk-send').onclick = () => {
      const note = el.querySelector('textarea').value.trim();
      if (!note) { toast('고칠 점을 한 줄 적어 주세요.'); return; }
      runNow(r.team, `수정: ${r.title}`, `${who}"${r.title}" 보고 수정 요청: ${note}. 고쳐서 다시 보고해줘.`).then((ok) => { if (ok) mark('fix'); });
    };
  });
}

let open = '';
function show(kind) {
  if (open === kind) { hide(); return; }
  open = kind;
  $('desk').hidden = false;
  $('desk-title').textContent = kind === 'tasks' ? '업무지시' : '보고함';
  $('desk-sub').textContent = kind === 'tasks' ? '업무지시를 누르면 그 팀이 바로 일해요(Sonnet).\n자료를 붙여 넣어야 하는 일만 복사돼요.' : '팀이 끝낸 일이에요. 승인하면 다음 단계를,\n수정 요청하면 고치는 일을 바로 맡겨요.';
  $('btn-desk-tasks').classList.toggle('on', kind === 'tasks');
  $('btn-desk-reports').classList.toggle('on', kind === 'reports');
  load().then(() => (kind === 'tasks' ? renderTasks() : renderReports()));
}
function hide() { open = ''; $('desk').hidden = true; $('btn-desk-tasks').classList.remove('on'); $('btn-desk-reports').classList.remove('on'); }

window.deskCopy = copy; // 출근·퇴근 버튼(app.js)도 같은 복사를 쓴다

// ---------- 바로 일 시키기 (서버가 Claude Code를 Sonnet으로 실행, run.mjs) ----------
let runToken = '', runInfo = { limit: 10, used: 0, runs: [] };
fetch('/api/office', { cache: 'no-store' }).then((r) => r.json()).then((o) => { runToken = o.runToken || ''; }).catch(() => {});
const needsPaste = (prompt) => /붙여넣/.test(prompt); // 내가 자료를 붙여 넣어야 하는 일은 복사 방식
async function pollRuns() {
  try { const r = await fetch('/api/runs', { cache: 'no-store' }); if (r.ok) runInfo = await r.json(); } catch { /* 서버가 꺼져 있으면 그대로 */ }
  const n = runInfo.runs.filter((x) => x.state === 'running').length;
  $('btn-desk-tasks').dataset.running = n ? String(n) : '';
  if (open === 'tasks') { paintRuns(); paintTaskStates(); }
}
function paintTaskStates() { // 업무지시를 누른 일은 '업무 중', 끝나면 '완료', 막히면 '막힘'
  document.querySelectorAll('#desk-body em[data-lbl]').forEach((em) => {
    if (em.dataset.paste === '1') return;
    const hid = new Set(store.get().__hiddenRuns || []), r = runInfo.runs.find((x) => x.label === em.dataset.lbl && !hid.has(x.id));
    const st = r ? r.state : '';
    em.textContent = st === 'running' ? '업무 중' : st === 'done' ? '완료' : st === 'error' ? '막힘' : '업무지시';
    em.closest('.desk-task').dataset.st = st;
  });
}
function paintRuns() {
  const box = $('desk-runs'); if (!box) return;
  const st = { running: '⏳ 일하는 중', done: '✅ 끝남 (보고함 확인)', error: '⚠️ 막힘' };
  const hidden = new Set(store.get().__hiddenRuns || []); // 지운 줄 (이 브라우저에만)
  const recent = runInfo.runs.filter((x) => !hidden.has(x.id)).slice(0, 4);
  box.innerHTML = `<div class="desk-quota">오늘 바로 실행 <b>${runInfo.used}/${runInfo.limit}</b>회 · Sonnet</div>` +
    recent.map((x) => `<div class="desk-run ${x.state}"><b>${esc(x.team)}</b> ${esc(x.label)}<span>${st[x.state] || x.state}</span>${x.state !== 'running' ? `<button class="run-x" data-hide="${esc(x.id)}" aria-label="지우기">×</button>` : ''}${x.state === 'error' ? `<small>${esc(x.tail.slice(-160))}</small>` : ''}</div>`).join('');
  box.querySelectorAll('[data-hide]').forEach((b) => { b.onclick = (ev) => { ev.stopPropagation(); const v = store.get(); v.__hiddenRuns = [...(v.__hiddenRuns || []), b.dataset.hide].slice(-50); store.set(v); paintRuns(); paintTaskStates(); }; });
}
async function runNow(team, label, prompt) {
  if (needsPaste(prompt)) { copy(prompt); toast('자료를 붙여 넣어야 하는 일이라 복사했어요. Claude Code에 붙여 넣고 자료를 같이 주세요.'); return true; }
  if (!confirm(`${team}에 "${label}" 일을 업무지시 할까요?\n오늘 ${runInfo.used}/${runInfo.limit}회 사용 · Sonnet`)) return false;
  let ok = false;
  try {
    const r = await fetch('/api/run', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AIO-Token': runToken }, body: JSON.stringify({ team, label, prompt }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) { toast(j.error || '맡기지 못했어요.'); return false; }
    toast('업무지시 했어요. 끝나면 보고함에 올라와요.'); ok = true;
  } catch { toast('서버에 연결하지 못했어요.'); }
  pollRuns();
  return ok;
}
setInterval(pollRuns, 5000); pollRuns();
$('btn-desk-tasks').onclick = () => show('tasks');
$('btn-desk-reports').onclick = () => show('reports');
$('desk-x').onclick = hide;
load();
setInterval(load, 15000);
