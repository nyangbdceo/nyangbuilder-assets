#!/usr/bin/env python3
"""도트 그림 만들기 (pixel-character 스킬).

AI 이미지 도구가 그린 "도트풍" 그림은 칸 크기가 들쭉날쭉하고 크다(1000px 안팎). 이 스크립트는
  1) 색 경계가 몰리는 간격(도트 한 칸 크기)과 시작점을 찾고
  2) 칸마다 가장 많이 쓰인 색을 고르고
  3) 배경을 투명하게(선택), 비슷한 색을 합치고, 여백을 자르고
  4) 1px = 도트 1칸 PNG와 보기 좋게 키운 PNG를 저장한다.
색은 원래 그림 색을 그대로 쓴다.

필요한 것: python3 (3.8 이상) 표준 라이브러리만. 입력은 PNG (8비트, 일반 PNG. AI 이미지 도구 기본 저장 형식).

  python3 pixel.py 그림.png                          # 그림 옆에 그림_dot.png, 그림_dot_x8.png
  python3 pixel.py 그림.png --name 콩이 --scale 12 --max 64x64
  python3 pixel.py 그림.png --preset ai-office --name 콩이 --out <ai-office 폴더>/characters
"""
import argparse, os, re, struct, sys, zlib
try: sys.stdout.reconfigure(encoding='utf-8'); sys.stderr.reconfigure(encoding='utf-8')
except Exception: pass
from collections import Counter

POSES = ('happy', 'sad', 'walk', 'rest')
SMALL = 160  # 긴 변이 이 이하인 그림은 이미 1칸 = 1px 도트로 본다
MAX_CELLS = 512  # 결과 칸 수 상한 (가로, 세로 각각)
MAX_BIG = 8192   # 키운 판 가로세로 상한 (px)
RESERVED = {'con', 'prn', 'aux', 'nul', *(f'com{i}' for i in range(1, 10)), *(f'lpt{i}' for i in range(1, 10))}  # 윈도우에서 파일 이름으로 못 쓰는 이름
BAD_CHARS = re.compile('[\\\\/:*?"<>|\x00-\x1f\x7f\u200e\u200f\u202a-\u202e\u2066-\u2069]')


def check_name(name):
    stem = name.split('.')[0].strip().lower()
    if (not name or len(name) > 80 or BAD_CHARS.search(name) or name.startswith('.') or name[-1] in ' .' or stem in RESERVED):
        die('--name에는 / \\ : * ? " < > | 와 보이지 않는 제어 문자를 쓸 수 없고, 점이나 공백으로 끝나거나 con, prn, aux, nul, com1~9, lpt1~9 같은 이름도 안 돼요. 80자 안으로 지어 주세요.')
PRESETS = {'ai-office': {'max': (70, 80)}}  # AI 오피스 직원 캐릭터 규격


def die(msg):
    sys.exit(f'pixel.py: {msg}')


def say(*a):
    print(*a, file=sys.stderr)


# ---------------------------------------------------------------- PNG 읽기, 쓰기 (zlib만)
MAX_SIDE = 4096  # 이보다 큰 그림은 받지 않는다


def read_png(path):
    """PNG -> (W, H, [(r, g, b, a), ...]). 깨진 파일은 한 줄 안내로 멈춘다."""
    try:
        return _read_png(path)
    except (struct.error, zlib.error, IndexError, ValueError, TypeError):
        die(f'{path}: 그림 파일이 깨졌어요. 이미지 AI에서 PNG로 다시 저장해 주세요.')


def _read_png(path):
    """8비트 그레이, RGB, 팔레트, 그레이+알파, RGBA."""
    with open(path, 'rb') as f:
        data = f.read()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        if data[:3] == b'\xff\xd8\xff':
            die(f'{path}: JPG 그림이에요. PNG로 다시 저장해 주세요 (맥 미리보기: 파일 > 내보내기 > PNG, 윈도우 그림판: 다른 이름으로 저장 > PNG).')
        die(f'{path}: PNG 그림이 아니에요. PNG로 저장한 파일을 주세요.')
    i, idat, plte, trns = 8, b'', None, None
    W = H = depth = ctype = interlace = None
    while i < len(data):
        n = struct.unpack('>I', data[i:i + 4])[0]
        t, body = data[i + 4:i + 8], data[i + 8:i + 8 + n]
        if t == b'IHDR':
            W, H, depth, ctype, _, _, interlace = struct.unpack('>IIBBBBB', body)
        elif t == b'PLTE':
            plte = body
        elif t == b'tRNS':
            trns = body
        elif t == b'IDAT':
            idat += body
        elif t == b'IEND':
            break
        i += 12 + n
    if W is None:
        die(f'{path}: 그림 파일이 깨졌어요 (그림 정보가 없어요). PNG로 다시 저장해 주세요.')
    if not (0 < W <= MAX_SIDE and 0 < H <= MAX_SIDE):
        die(f'{path}: 그림이 너무 커요({W}x{H}px). 가로세로 {MAX_SIDE}px 안으로 줄여 주세요.')
    if depth != 8:
        die(f'{path}: {depth}비트 PNG는 못 읽어요. 8비트 PNG로 저장해 주세요.')
    if interlace:
        die(f'{path}: 인터레이스 PNG는 못 읽어요. 다른 이름으로 일반 PNG로 저장해 주세요.')
    bpp = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if not bpp:
        die(f'{path}: 이 PNG 형식(color type {ctype})은 못 읽어요.')
    stride = W * bpp
    need = (stride + 1) * H
    dec = zlib.decompressobj()
    raw = dec.decompress(idat, need)  # 그림 크기만큼만 푼다 (압축 폭탄 막기)
    if len(raw) < need:
        die(f'{path}: 그림 파일이 깨졌어요 (데이터가 모자라요). PNG로 다시 저장해 주세요.')
    prev = bytearray(stride)
    out = bytearray(stride * H)
    pos = 0
    for y in range(H):
        ft = raw[pos]; line = bytearray(raw[pos + 1:pos + 1 + stride]); pos += 1 + stride
        if ft == 1:
            for x in range(bpp, stride):
                line[x] = (line[x] + line[x - bpp]) & 255
        elif ft == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif ft == 3:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                line[x] = (line[x] + ((a + prev[x]) >> 1)) & 255
        elif ft == 4:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                b = prev[x]; c = prev[x - bpp] if x >= bpp else 0
                p = a + b - c; pa = abs(p - a); pb = abs(p - b); pc = abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = line
    px = []
    if ctype == 6:
        px = [tuple(out[k:k + 4]) for k in range(0, len(out), 4)]
    elif ctype == 2:
        px = [(out[k], out[k + 1], out[k + 2], 255) for k in range(0, len(out), 3)]
    elif ctype == 0:
        px = [(v, v, v, 255) for v in out]
    elif ctype == 4:
        px = [(out[k], out[k], out[k], out[k + 1]) for k in range(0, len(out), 2)]
    elif ctype == 3:
        pal = [tuple(plte[k:k + 3]) for k in range(0, len(plte), 3)]
        al = list(trns or b'') + [255] * 256
        px = [pal[v] + (al[v],) for v in out]
    return W, H, px


def write_png(path, W, H, rows):
    """rows[y][x] = (r, g, b) 또는 None(투명) -> RGBA PNG."""
    raw = bytearray()
    for r in rows:
        raw.append(0)
        for c in r:
            raw += bytes(c) + b'\xff' if c else b'\x00\x00\x00\x00'
    chunk = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b''))


# ---------------------------------------------------------------- 칸 찾기
def differ(a, b):
    """두 점 색이 확실히 다른가 (AI 그림의 잔 얼룩, 번짐은 경계로 보지 않는다)."""
    if (a[3] < 128) != (b[3] < 128):
        return True
    return a[3] >= 128 and abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2]) > 60


def transitions(W, H, px):
    tx, ty = [0] * W, [0] * H
    for y in range(H):
        row = px[y * W:(y + 1) * W]
        for x in range(1, W):
            if differ(row[x], row[x - 1]):
                tx[x] += 1
        if y:
            up = px[(y - 1) * W:y * W]
            ty[y] = sum(1 for x in range(0, W, 2) if differ(row[x], up[x])) * 2  # 세로는 두 열에 하나만 봐도 충분하다
    return tx, ty


def score(t, total, p, ph):
    """격자선(간격 p, 시작 ph) 위에 놓인 경계 비율 - 우연히 맞는 비율(2/p). 진짜 칸의 배수는 놓치는 경계가 많아 낮다."""
    s, x, n = 0.0, ph, len(t)
    while x < n - 1:
        i = int(round(x))
        s += t[i] + 0.5 * ((t[i - 1] if i > 0 else 0) + (t[i + 1] if i + 1 < n else 0))
        x += p
    return s / (total or 1) - 2 / p


def best_phase(t, total, p):
    best, ph = (-9, 0.0), 0.0
    while ph < p:
        sc = score(t, total, p, ph)
        if sc > best[0]:
            best = (sc, ph)
        ph += 0.5
    return best


def find_cell(t, lo, hi):
    total, best, p = sum(t), None, lo
    while p <= hi + 1e-9:
        sc, ph = best_phase(t, total, p)
        if best is None or sc > best[0]:
            best = (sc, round(p, 1), ph)
        p += 0.1
    return best[1]


# ---------------------------------------------------------------- 칸 읽기와 정리
def sample(W, H, px, p, ox, oy):
    key = lambda c: -1 if c[3] < 128 else ((c[0] >> 5) << 6) | ((c[1] >> 5) << 3) | (c[2] >> 5)
    gw, gh = int((W - ox) // p), int((H - oy) // p)
    rows = []
    for j in range(gh):
        row = []
        for i in range(gw):
            x0 = int(ox + i * p + p * 0.2); x1 = max(x0 + 1, int(ox + (i + 1) * p - p * 0.2))
            y0 = int(oy + j * p + p * 0.2); y1 = max(y0 + 1, int(oy + (j + 1) * p - p * 0.2))
            acc = {}
            for y in range(y0, min(y1, H)):
                for x in range(x0, min(x1, W)):
                    c = px[y * W + x]; k = key(c)
                    e = acc.get(k)
                    if e:
                        e[0] += 1; e[1] += c[0]; e[2] += c[1]; e[3] += c[2]
                    else:
                        acc[k] = [1, c[0], c[1], c[2]]
            k, e = max(acc.items(), key=lambda kv: kv[1][0])
            row.append(None if k == -1 else tuple(round(v / e[0]) for v in e[1:]))
        rows.append(row)
    return rows


def dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])


def remove_background(rows):
    """테두리에 닿은 배경색(테두리에서 가장 흔한 색)과 비슷한 칸을 따라가며 투명하게."""
    h, w = len(rows), len(rows[0])
    edge = [rows[0][x] for x in range(w)] + [rows[h - 1][x] for x in range(w)] + [rows[y][0] for y in range(h)] + [rows[y][w - 1] for y in range(h)]
    solid = [c for c in edge if c]
    if len(solid) * 2 < len(edge):  # 테두리 절반 넘게 이미 투명하면 배경이 없는 그림 (지우면 외곽선이 깎인다)
        return rows
    bg = max(solid, key=lambda c: sum(1 for d in solid if dist(c, d) < 30))
    seen, stack = set(), [(x, 0) for x in range(w)] + [(x, h - 1) for x in range(w)] + [(0, y) for y in range(h)] + [(w - 1, y) for y in range(h)]
    while stack:
        x, y = stack.pop()
        if x < 0 or y < 0 or x >= w or y >= h or (x, y) in seen:
            continue
        seen.add((x, y))
        c = rows[y][x]
        if c and dist(c, bg) > 60:
            continue
        rows[y][x] = None
        stack += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    return rows


def reduce_colors(rows, n):
    """가까운 색끼리 합쳐 n색 이하로. 색이 아주 많은 그림도 빨리 끝나게:
    1) 색마다 3비트 묶음(최대 512개)의 평균색으로 모으고  2) 많이 쓰인 64개만 후보로 남겨 나머지는 가장 가까운 후보로
    3) 후보끼리 가장 가까운 두 색을 합치기를 n색이 될 때까지 (많이 쓰인 색 쪽으로)."""
    count = Counter(c for r in rows for c in r if c)
    if not count:
        return rows
    buckets = {}
    for c, v in count.items():
        k = (c[0] >> 5, c[1] >> 5, c[2] >> 5)
        b = buckets.setdefault(k, [0, 0, 0, 0])
        b[0] += v; b[1] += c[0] * v; b[2] += c[1] * v; b[3] += c[2] * v
    avg = {k: (round(b[1] / b[0]), round(b[2] / b[0]), round(b[3] / b[0])) for k, b in buckets.items()}
    pal = sorted(([avg[k], b[0]] for k, b in buckets.items()), key=lambda x: -x[1])
    keep, rest = pal[:64], pal[64:]
    for c, v in rest:
        min(keep, key=lambda p: dist(p[0], c))[1] += v
    owner = {p[0]: p[0] for p in keep}
    for c, _ in rest:
        owner[c] = min(keep, key=lambda p: dist(p[0], c))[0]
    while len(keep) > n:
        best = None
        for i in range(len(keep)):
            for j in range(i + 1, len(keep)):
                d = dist(keep[i][0], keep[j][0])
                if best is None or d < best[0]:
                    best = (d, i, j)
        _, i, j = best
        big, small = (keep[i], keep[j]) if keep[i][1] >= keep[j][1] else (keep[j], keep[i])
        big[1] += small[1]
        for k, v in owner.items():
            if v == small[0]:
                owner[k] = big[0]
        keep.remove(small)
    final = {c: owner[avg[(c[0] >> 5, c[1] >> 5, c[2] >> 5)]] for c in count}
    return [[final[c] if c else None for c in r] for r in rows]


def crop(rows):
    ys = [y for y, r in enumerate(rows) if any(r)]
    xs = [x for x in range(len(rows[0])) if any(r[x] for r in rows)]
    if not ys:
        die('정리하고 나니 남은 칸이 없어요. 배경과 캐릭터 색이 비슷하면 --keep-bg로 다시 해 보세요.')
    return [r[xs[0]:xs[-1] + 1] for r in rows[ys[0]:ys[-1] + 1]]


def halve(rows):
    """2x2 묶음을 한 칸으로 (진한 선 우선, 투명이 과반이면 투명, 나머지는 가장 많은 색)."""
    h, w = len(rows), len(rows[0])
    dark = lambda c: c[0] * 0.3 + c[1] * 0.59 + c[2] * 0.11 < 115
    out = []
    for y in range(0, h, 2):
        row = []
        for x in range(0, w, 2):
            cs = [rows[yy][xx] for yy in (y, y + 1) for xx in (x, x + 1) if yy < h and xx < w]
            solid = [c for c in cs if c]
            dk = [c for c in solid if dark(c)]
            if dk:
                row.append(Counter(dk).most_common(1)[0][0])
            elif len(solid) * 2 < len(cs):
                row.append(None)
            else:
                row.append(Counter(solid).most_common(1)[0][0])
        out.append(row)
    return out


def enlarge(path, rows, z, checker=False):
    """z배로 키운 그림. checker면 투명 칸을 옅은 체크무늬로 채운다(확인용), 아니면 투명 그대로.
    줄 단위로 바로 압축해 쓰므로 큰 배수에도 메모리를 적게 쓴다."""
    h, w = len(rows), len(rows[0])
    W, H = w * z, h * z
    co = zlib.compressobj(9)
    body = bytearray()
    for y in range(H):
        src = rows[y // z]
        line = bytearray(b'\x00')
        for x in range(W):
            c = src[x // z]
            if c:
                line += bytes(c) + b'\xff'
            elif checker:
                line += (b'\xec\xec\xec\xff' if ((x // 8 + y // 8) % 2) else b'\xff\xff\xff\xff')
            else:
                line += b'\x00\x00\x00\x00'
        body += co.compress(bytes(line))
    body += co.flush()
    chunk = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 6, 0, 0, 0)) + chunk(b'IDAT', bytes(body)) + chunk(b'IEND', b''))


def parse_max(v):
    m = re.fullmatch(r'(\d+)[xX](\d+)', v or '')
    if not m or int(m.group(1)) < 4 or int(m.group(2)) < 4:
        die('--max는 "가로x세로" 꼴로 주세요. 예: --max 64x64')
    return int(m.group(1)), int(m.group(2))


def safe_target(path):
    """저장할 자리 점검: 바로가기면 멈추고, 이미 있으면 .bak로 옮긴다 (--force면 그냥 덮어씀)."""
    if os.path.islink(path):
        die(f'{path}는 바로가기(심볼릭 링크)라 덮어쓰지 않아요. 지우거나 다른 이름을 주세요.')
    return path


def backup(path, force):
    if os.path.exists(path) and not force:
        bak = path + '.bak'
        if os.path.islink(bak):
            die(f'{bak}가 바로가기라 백업을 만들지 않아요. 지우고 다시 해 주세요.')
        os.replace(path, bak)
        say(f'예전 {os.path.basename(path)}는 {os.path.basename(bak)}로 옮겼어요')


# ---------------------------------------------------------------- 실행
def main():
    ap = argparse.ArgumentParser(description='AI 도트풍 그림 -> 진짜 도트 PNG (1px = 도트 1칸) + 키운 PNG')
    ap.add_argument('image', help='입력 그림 (PNG)')
    ap.add_argument('--name', help='저장할 이름 (기본: 입력 파일 이름 + _dot)')
    ap.add_argument('--out', help='저장할 폴더 (기본: 입력 그림과 같은 폴더)')
    ap.add_argument('--scale', type=int, default=8, help='보기 좋게 키운 판의 배수 (정수, 기본 8. 1이면 키운 판을 만들지 않음)')
    ap.add_argument('--max', help='결과 크기 상한 "가로x세로" (예: 64x64). 넘으면 반씩 줄인다. 기본은 상한 없음')
    ap.add_argument('--keep-bg', action='store_true', help='배경을 지우지 않는다 (기본: 테두리에 닿은 배경을 투명하게)')
    ap.add_argument('--cell', type=float, help='도트 한 칸 크기(px)를 직접 준다. 자동 결과가 뭉개지거나 어긋날 때')
    ap.add_argument('--colors', type=int, default=16, help='남길 색 개수 (기본 16)')
    ap.add_argument('--force', action='store_true', help='같은 이름 파일이 있으면 백업 없이 덮어쓴다 (기본: 예전 파일을 .bak로 옮기고 저장)')
    ap.add_argument('--preset', choices=sorted(PRESETS), help='정해진 규격: ai-office = AI 오피스 직원 캐릭터 (70x80칸 안, --out은 characters 폴더)')
    ap.add_argument('--pose', choices=POSES, help='(ai-office) 표정이나 동작 그림이면: happy, sad, walk, rest')
    ap.add_argument('--preview', help='(ai-office) 확인용 큰 그림을 둘 폴더 (기본: 입력 그림 옆)')
    a = ap.parse_args()

    if not os.path.isfile(a.image):
        die(f'그림 파일이 없어요: {a.image}')
    office = a.preset == 'ai-office'
    if (a.pose or a.preview) and not office:
        die('--pose와 --preview는 --preset ai-office와 같이 써요.')
    if a.scale < 1 or a.scale > 64:
        die('--scale은 1에서 64 사이 정수로 주세요.')
    limit = parse_max(a.max) if a.max else (PRESETS[a.preset]['max'] if a.preset else None)

    if office:
        if not a.name or not a.out:
            die('--preset ai-office는 --name(캐릭터 이름)과 --out(ai-office 폴더 안 characters 폴더)이 꼭 필요해요.')
        if not re.fullmatch(r'[^\W_]+(?:-[^\W_]+)*', a.name) or len(a.name) > 30:
            die('AI 오피스 캐릭터 이름은 글자와 숫자(사이에 - 가능)로 30자 안에서 지어 주세요. 예: 콩이')
        check_name(a.name)
        base = f'{a.name}_{a.pose}' if a.pose else a.name
    else:
        base = a.name or os.path.splitext(os.path.basename(a.image))[0] + '_dot'
        check_name(base)
    out_dir = a.out or os.path.dirname(os.path.abspath(a.image))
    if not os.path.isdir(out_dir):
        die(f'저장할 폴더가 없어요: {out_dir}')
    out = safe_target(os.path.join(out_dir, base + '.png'))
    if os.path.realpath(a.image) == os.path.realpath(out):
        die('입력 그림과 저장할 파일이 같아요. 다른 이름(--name)이나 다른 폴더(--out)를 주세요.')
    if office:
        # 확인용 그림은 characters 폴더에 두지 않는다 (섞이면 AI 오피스 화면에 경고가 뜬다)
        real_out = os.path.realpath(out_dir)
        pdir = a.preview or os.path.dirname(os.path.abspath(a.image))
        if os.path.realpath(pdir) == real_out:
            if a.preview:
                die('--preview를 저장 폴더와 다른 곳으로 주세요 (확인용 그림이 characters에 섞이면 화면에 경고가 떠요).')
            pdir = os.path.join(os.path.dirname(real_out), 'dot-preview')
        big = safe_target(os.path.join(pdir, base + '_preview.png'))
    else:
        big = safe_target(os.path.join(out_dir, f'{base}_x{a.scale}.png')) if a.scale > 1 else None
        if big and os.path.realpath(a.image) == os.path.realpath(big):
            die('입력 그림과 저장할 파일이 같아요. 다른 이름(--name)을 주세요.')

    W, H, px = read_png(a.image)
    say(f'그림 {W}x{H}px 읽음')
    if a.cell is not None:
        if not (1 <= a.cell <= max(W, H) / 2):
            die(f'--cell은 1 이상, 그림 긴 변의 절반({max(W, H) // 2}px) 이하로 주세요.')
        p = a.cell
    elif max(W, H) <= SMALL:
        p = 1.0  # 이미 작은 도트 그림 (1칸 = 1px)
    else:
        tx, ty = transitions(W, H, px)
        lo, hi = max(2.0, W / 120), max(2.0, W / 12)  # 그림 폭에 도트 12~120칸
        p = find_cell(tx, round(lo, 1), round(hi, 1))
    if p > 1:
        tx, ty = transitions(W, H, px)
        ox = best_phase(tx, sum(tx), p)[1] % p
        oy = best_phase(ty, sum(ty), p)[1] % p
    else:
        ox = oy = 0
    say(f'도트 한 칸 = {p}px (시작점 {ox}, {oy})')
    gw, gh = int((W - ox) // p), int((H - oy) // p)
    if gw > MAX_CELLS or gh > MAX_CELLS:
        die(f'결과가 너무 커요({gw}x{gh}칸). {MAX_CELLS}칸 안이 되게 --cell을 키워 주세요.')
    rows = sample(W, H, px, p, ox, oy)
    if not a.keep_bg:
        rows = remove_background(rows)
    rows = reduce_colors(rows, max(2, a.colors))
    rows = crop(rows)
    while limit and (len(rows[0]) > limit[0] or len(rows) > limit[1]):
        say(f'{len(rows[0])}x{len(rows)}칸이라 {limit[0]}x{limit[1]}칸 안으로 반씩 줄여요')
        rows = crop(halve(rows))

    z = 8 if office else a.scale
    if big and max(len(rows[0]), len(rows)) * z > MAX_BIG:
        die(f'키운 판이 {MAX_BIG}px를 넘어요({len(rows[0]) * z}x{len(rows) * z}px). --scale 배수를 줄여 주세요.')
    backup(out, a.force)
    write_png(out, len(rows[0]), len(rows), rows)
    print(f'저장: {out} ({len(rows[0])}x{len(rows)}칸)')
    if big:
        os.makedirs(os.path.dirname(big), exist_ok=True)
        if office:
            enlarge(big, rows, 8, checker=True)
            print(f'확인용 큰 그림: {big}')
        else:
            backup(big, a.force)
            enlarge(big, rows, a.scale)
            print(f'{a.scale}배 그림: {big}')


if __name__ == '__main__':
    main()
