@echo off
chcp 65001 >nul
rem 냥빌더판 AI 오피스 열기: 사무실 서버를 창 없이 켜고 브라우저에 띄워요. 끌 때는 Claude Code에 "AI 오피스 꺼 줘"
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js가 없어요. https://nodejs.org 에서 LTS를 설치한 뒤 다시 눌러 주세요. & pause & exit /b)
powershell -NoProfile -Command "$port = 4326; $log = '%~dp0server.log'; if (Test-Path $log) { $m = Select-String -Path $log -Pattern 'localhost:(\d+)' | Select-Object -First 1; if ($m) { $port = $m.Matches[0].Groups[1].Value } }; try { Invoke-RestMethod ('http://127.0.0.1:' + $port + '/api/office') -TimeoutSec 2 | Out-Null } catch { $port = 4326; if (Get-NetTCPConnection -LocalPort 4326 -State Listen -ErrorAction SilentlyContinue) { $port = 4400 }; $env:AIO_PORT = $port; Start-Process node -ArgumentList 'server.mjs' -WorkingDirectory '%~dp0.' -WindowStyle Hidden -RedirectStandardOutput '%~dp0server.log' -RedirectStandardError '%~dp0server.err.log'; Start-Sleep 2 }; Start-Process ('http://localhost:' + $port + '/')"
