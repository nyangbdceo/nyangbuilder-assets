# AI 오피스 (냥빌더판): Claude Code 작업 안내서

이 폴더는 내 Claude Code 에이전트들을 도트 캐릭터 직원으로 보여 주는 사무실 프로그램이에요. 화면에서 업무지시를 하고 보고함으로 결과를 받을 수 있어요.
이걸 쓰는 분들은 대부분 개발을 해 본 적이 없어요. 사용자는 파일을 끌어다 놓고 문장 하나만 붙여 넣고, 나머지는 Claude Code가 이 안내서대로 처리해요.

**말투**: 어려운 말 없이, 한 단계가 끝날 때마다 한 줄로 알려 줘요. 전문 용어가 나오면 쉬운 말로 풀어 줘요. Claude Code가 명령 실행 허락을 물으면, 그 명령이 무슨 일을 하는지 한 줄로 먼저 말해 주고 "맞으면 허용을 누르면 돼요"라고 해요. 지우기, 이름 바꾸기, 끄기처럼 되돌리기 어려운 일은 대상 경로나 프로그램 번호(PID)를 보여 준 뒤 허용받아요.

---

## 구조

| 파일 | 내용 |
|---|---|
| `office.config.json` | 사용자가 고치는 설정 파일은 이것 하나 (회사 이름, 호칭, 팀과 직원) |
| `characters/` | 직원 얼굴로 쓰는 도트 캐릭터 PNG |
| `server.mjs`, `office.mjs`, `live.mjs` | 서버. Node.js 내장 모듈만, 127.0.0.1 전용. 쓰는 곳은 `run.mjs`(바로 실행)뿐 |
| `run.mjs` | 냥빌더판: 업무지시 창의 '업무지시' 버튼 → 이 PC의 Claude Code를 뒤에서 실행 (하루 10회, 동시 2개, 이 화면에서 온 요청만) |
| `public/desk.json` | 냥빌더판: 업무 지시 목록(`tasks`), 요일별 할 일(`plan`), 보고함(`reports`) |
| `schedule.json` | 냥빌더판: 왼쪽 '주간 일정' 패널의 요일별 시간표 |
| `public/` | 브라우저에 보이는 사무실 화면 |
| `skills/pixel-character/` | 그림을 도트로 바꾸는 스킬 (어디든 쓸 수 있고, `--preset ai-office`면 사무실 규격) |
| `skills/ai-office/` | 어느 폴더에서 Claude Code를 열어도 AI 오피스 요청을 알아듣게 하는 안내 스킬 |

## 지켜야 할 것

1. 패키지를 새로 설치하지 않아요. 이 프로그램은 `npm install` 없이 돌아가요.
2. 서버 보안 설정(127.0.0.1, Host 확인, 바로 실행의 횟수 제한·열쇠 확인)을 바꾸지 않아요. 외부 공개를 원하면 위험을 설명하고 멈춰요.
3. 실제 작업 연결이 읽는 범위를 넓히지 않아요. 대화 기록 본문은 읽지 않고 시각만 봐요.
4. 사람이 준 그림으로만 캐릭터를 만들어요. 만화, 게임, 브랜드 캐릭터를 따라 그리거나 비슷하게 만들지 않아요. 그런 요청이면 저작권 문제를 알려 주고 직접 만든 그림을 쓰도록 안내해요.
5. 사무실 지도 좌표(`public/data.js`)는 고치지 않아요. 팀과 직원은 설정 파일에서만 바꿔요.
6. 사용자가 원래 갖고 있던 파일(`~/.claude` 안의 스킬, 에이전트, 설정)은 덮어쓰기 전에 반드시 먼저 물어봐요.

## 명령 모음 (맥 / 윈도우)

AI 오피스 폴더를 `<폴더>`로 적어요. 기본 위치는 바탕화면의 `ai-office`예요.

| 할 일 | 맥 (터미널) | 윈도우 (PowerShell) |
|---|---|---|
| 바탕화면 경로 | `~/Desktop` | `[Environment]::GetFolderPath('Desktop')` (OneDrive 바탕화면도 이걸로 잡혀요) |
| zip 풀기 (새 임시 폴더로) | `ditto -x -k "<zip>" ~/Desktop/<임시 폴더>` | `Expand-Archive -Path "<zip>" -DestinationPath "<바탕화면>\<임시 폴더>"` |
| Node 확인 | `node -v` | `node -v` |
| 파이썬 확인 | `python3 --version` | `python --version` 안 되면 `py --version` |
| 스킬 폴더 | `~/.claude/skills/` | `$HOME\.claude\skills\` |
| 스킬 복사 (같은 이름 폴더가 없을 때만. 있으면 아래 「스킬 설치」대로 비교 후 물어보기) | `mkdir -p ~/.claude/skills && cp -R "<폴더>/skills/pixel-character" "<폴더>/skills/ai-office" ~/.claude/skills/` | `New-Item -ItemType Directory -Force "$HOME\.claude\skills" ; Copy-Item -Recurse "<폴더>\skills\pixel-character","<폴더>\skills\ai-office" "$HOME\.claude\skills\"` |
| 예전 스킬 옮기기 (바꾸기로 했을 때) | `mkdir -p ~/.claude/skills-예전 && mv ~/.claude/skills/<이름> ~/.claude/skills-예전/<이름>` | `New-Item -ItemType Directory -Force "$HOME\.claude\skills-예전" ; Move-Item "$HOME\.claude\skills\<이름>" "$HOME\.claude\skills-예전\<이름>"` |
| 스킬 내용 비교 | `diff -r "<폴더>/skills/pixel-character" ~/.claude/skills/pixel-character` (아무것도 안 나오면 같음) | `Compare-Object (Get-ChildItem -Recurse "<폴더>\skills\pixel-character" \| Get-FileHash).Hash (Get-ChildItem -Recurse "$HOME\.claude\skills\pixel-character" \| Get-FileHash).Hash` (아무것도 안 나오면 같음) |
| 켜져 있나 | `curl -s http://127.0.0.1:4326/api/office` | `Invoke-RestMethod http://127.0.0.1:4326/api/office` |
| 켜기 (창을 닫아도 계속) | `cd "<폴더>" && nohup node server.mjs > server.log 2>&1 &` | `Start-Process node -ArgumentList 'server.mjs' -WorkingDirectory "<폴더>" -WindowStyle Hidden -RedirectStandardOutput "<폴더>\server.log" -RedirectStandardError "<폴더>\server.err.log"` |
| 다른 포트로 켜기 | `AIO_PORT=4400 nohup node server.mjs > server.log 2>&1 &` | `$env:AIO_PORT=4400; Start-Process node -ArgumentList 'server.mjs' -WorkingDirectory "<폴더>" -WindowStyle Hidden -RedirectStandardOutput "<폴더>\server.log" -RedirectStandardError "<폴더>\server.err.log"` |
| 브라우저 열기 | `open http://localhost:4326` | `Start-Process http://localhost:4326` |
| 끌 프로그램 찾기 (번호와 이름) | `lsof -nP -t -iTCP@127.0.0.1:4326 -sTCP:LISTEN` 로 번호(PID), `ps -p <PID> -o comm=` 이 `node`(또는 `/경로/node`)인지 | `$c = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 4326 -State Listen; Get-Process -Id $c.OwningProcess` 의 이름이 `node`인지 |
| 끄기 (위에서 확인한 번호만) | `kill <PID>` | `Stop-Process -Id <PID>` |
| 도트 변환 | `python3 -I ~/.claude/skills/pixel-character/scripts/pixel.py ...` | `python -I "$HOME\.claude\skills\pixel-character\scripts\pixel.py" ...` (`py`도 됨) |
| JSON 확인 | `node -e "JSON.parse(require('fs').readFileSync('office.config.json','utf8'));console.log('ok')"` | 같은 명령 |

**켜졌는지 판단**: `/api/office`가 `"company"`가 들어 있는 JSON을 돌려주면 AI 오피스예요. 표의 4326은 기본 번호예요.

**포트 번호 기억하기**: 4326이 AI 오피스가 아니면(응답이 없거나 다른 프로그램) `<폴더>/server.log` 첫 줄의 `http://localhost:<번호>`를 읽어 그 번호로 다시 확인해요. 다른 포트로 켠 적이 있으면 끄기, 다시 켜기, 진단, 안내 문구 모두 이 번호를 써요. 서버는 켤 때마다 이 첫 줄을 새로 써요.

**끄기 안전 규칙**: ① `/api/office`로 그 포트가 AI 오피스인지 확인 ② 127.0.0.1에서 그 포트를 듣는 프로그램의 번호(PID)를 찾고 이름이 `node`인지 확인 ③ 번호와 이름을 사람에게 보여 주고 허용받기 ④ 그 번호 하나만 끄기. 하나라도 맞지 않으면 끄지 말고 본 것을 알려 줘요. 4326번을 다른 프로그램이 쓰고 있으면 4400, 4401처럼 다음 번호로 켜고 주소도 그 번호로 알려 줘요.

---

## 1. "이 파일을 바탕화면에 풀고, 안에 있는 CLAUDE.md를 읽고 그대로 AI 오피스를 설치하고 실행해 줘."

사용자가 zip 파일을 채팅창에 끌어다 놓고 붙여 넣은 문장이에요. 아래 순서대로 진행하고, 한 단계가 끝날 때마다 한 줄로 알려 줘요.

1. **압축 풀기**: 바탕화면에 새 임시 폴더를 정해 풀어요. 이름은 `ai-office-풀기`, 이미 있으면 `ai-office-풀기-2`, `-3`처럼 없는 이름으로(기존 폴더는 건드리지 않아요). 그 안에 `ai-office` 폴더가 하나 있으면 그 폴더를, 파일이 바로 있으면 임시 폴더 자체를 바탕화면의 `ai-office`로 옮겨요. 임시 폴더를 지울 때는 방금 만든 그 폴더인지(이름과 안이 비었는지) 확인하고 지워요. 결과로 `server.mjs`가 들어 있는 폴더가 `<폴더>`예요.
   - 바탕화면에 `ai-office`가 이미 있으면:
     - 기존 폴더는 **지우지 않고** 이름을 `ai-office-예전`으로 바꿔 남겨요(이미 있으면 `ai-office-예전-2`처럼). 바꾸기 전에 경로를 보여 주고 허용받아요.
     - `characters`에 기본 캐릭터 `베리.png` 말고 다른 PNG가 없고 `office.config.json`이 기본값(`"company": "나의 AI 회사"`, 빈 `teams`)이면, 앞서 하다 멈춘 설치예요(Node나 파이썬을 설치하고 같은 문장을 다시 붙여 넣은 경우). 따로 묻지 않고 위처럼 이름만 바꾸고 새로 푼 것을 써요.
     - 그림이나 설정이 바뀌어 있으면 먼저 물어봐요. 바꾸기로 하면 `ai-office-예전`의 `characters`와 `office.config.json`을 새 폴더로 복사해 와요.
2. **이 CLAUDE.md 읽기**: 지금 이 문서예요.
3. **Node.js 확인**: `node -v`가 20 이상이어야 해요. 없거나 낮으면 "https://nodejs.org 에서 LTS를 받아 설치한 뒤, Claude Code를 새로 열고 다시 말해 주세요"라고 안내하고 **멈춰요**.
4. **파이썬 확인**: 3.8 이상. 없으면 "캐릭터를 만들 때 필요해요. https://www.python.org 에서 설치해 주세요(윈도우는 설치 첫 화면의 'Add python.exe to PATH'를 꼭 체크)"라고 알려 주고, 사무실 설치는 계속해요.
5. **스킬 설치**: `skills/pixel-character`와 `skills/ai-office`를 스킬 폴더에 복사해요. 같은 이름 폴더가 이미 있으면 「스킬 내용 비교」로 확인해서, 같으면 그대로 두고, 다르면 덮어쓸지 먼저 물어봐요. 바꾸기로 하면 기존 폴더를 스킬 폴더 **밖** `~/.claude/skills-예전/<이름>`(이미 있으면 `<이름>-2`)으로 옮긴 뒤 복사해요. 스킬 폴더 안에 남기면 같은 이름 스킬이 둘이 돼 예전 쪽이 불릴 수 있고, 그냥 복사하면 예전 파일과 섞여요. 옮기기 전에 두 경로를 보여 주고 허용받아요.
6. **실행**: 이미 켜져 있는지(4326, 또는 server.log 첫 줄 번호) 확인하고, 아니면 "켜기" 명령으로 백그라운드 실행해요. 2초쯤 뒤 `/api/office`로 확인해요. 안 되면 `<폴더>/server.log`를 읽고 이유를 쉬운 말로 알려 줘요.
7. **업무지시 버튼 준비 확인**: `claude auth status`를 돌려 `"loggedIn": true`인지 봐요(아래 「업무지시 버튼 준비」). 아니면 설치는 계속하고 마지막 안내에 한 줄 덧붙여요.
8. **브라우저 열기**, 그리고 이렇게 안내해요.
   > http://localhost:<실제 번호> 에 AI 오피스가 열렸어요. 처음에는 기본 캐릭터(베리)가 예시 직원들로 출근해 있어요. 내 에이전트로 팀을 짜면 그 직원들로 바뀌어요.
   > 다음으로 캐릭터 그림을 채팅에 끌어다 놓고 "이 그림으로 AI 오피스 직원 캐릭터 만들어 줘. 이름은 콩이."라고 말해 주세요.
   > 컴퓨터를 껐다 켜면 사무실도 꺼져요. 그때는 "AI 오피스 다시 켜 줘"라고 하면 돼요.

## 2. "이 그림으로 AI 오피스 직원 캐릭터 만들어 줘. 이름은 콩이."

같은 절: "이 그림으로 AI 오피스 직원 캐릭터 하나 더 만들어 줘. 이름은 두부." (캐릭터 추가, 방법은 똑같아요)

1. 그림 파일 경로를 확인해요. 채팅에 붙여 넣은 이미지라 파일 경로가 없으면 "그림 파일을 채팅 창에 끌어다 놓아 주세요"라고 해요. PNG가 아니면(JPG 등) PNG로 다시 저장해 달라고 해요.
2. AI 오피스 폴더를 찾아요(아래 「폴더 찾기」).
3. 변환해요 (스킬이 설치돼 있지 않으면 `<폴더>/skills/pixel-character/scripts/pixel.py`를 써요):
   ```
   python3 -I ~/.claude/skills/pixel-character/scripts/pixel.py "<그림>" --preset ai-office --name 콩이 --out "<폴더>/characters"
   ```
   이름은 글자와 숫자(사이에 `-` 가능)만 돼요. 띄어쓰기나 기호가 있으면 빼고 쓰고 그렇게 했다고 말해 줘요.
4. 기본 캐릭터 `베리.png`가 `characters`에 있고 이번이 사람의 첫 캐릭터면, 베리는 `characters/기본캐릭터/`로 옮겨 둬요(그 폴더는 화면에 안 나와요). 그래야 직원들이 내 캐릭터로 출근해요. "베리도 같이 써 줘"라고 하면 다시 `characters`로 꺼내요.
5. 출력에 나온 확인용 그림(`콩이_preview.png`)을 열어 사람에게 보여 줘요. "확인용 그림은 원래 그림 옆에 `콩이_preview.png`로 생겨요(사무실 폴더에는 안 들어가요)"라고 알려 줘요.
6. "AI 오피스 화면을 새로고침하면 콩이가 출근해요"라고 알려 줘요. 사무실이 꺼져 있으면 먼저 켜요.
7. 결과가 뭉개져 보인다고 하면 출력의 "도트 한 칸 = Npx"를 보고 `--cell`을 조금 바꿔 다시 해요(같은 이름이면 예전 파일은 `.bak`로 남아요).

**표정 추가**: "이 그림을 AI 오피스 콩이 웃는 표정으로 넣어 줘." (또는 "콩이 웃는 표정도 넣어 줘") → `--pose happy`. 속상한(슬픈, 화난) 표정은 `sad`, 걷는 모습은 `walk`, 쉬는 모습은 `rest`.
- 표정 그림이 따로 필요해요. 사람이 아직 없으면 이렇게 안내해요: "이미지 AI(ChatGPT 등)에 처음 그림을 첨부하고 '같은 캐릭터, 같은 크기와 화풍으로 웃는 표정만 바꿔 줘'라고 받아서 여기에 끌어다 놓아 주세요." 이 Claude Code에 이미지 생성 도구가 연결돼 있으면 그걸로 만들어도 돼요.
- 같은 명령에 `--pose happy`만 붙여요. 저장 이름은 `콩이_happy.png`.

**캐릭터가 하나뿐이면** 모든 직원이 같은 얼굴이에요. 여러 개를 넣으면 차례로 나눠 줘요. 특정 직원에게 주려면 설정의 `"character"`(3번).

## 3. "내 에이전트로 AI 오피스 팀 짜 줘. 회사 이름은 콩이 스튜디오."

고치는 파일은 `office.config.json` 하나예요. 회사 이름을 알려 줬으면 `company`에 넣고, 안 알려 줬으면 원래 값을 그대로 둬요.

1. 에이전트를 찾아요. 각 파일 맨 위 머리말의 `name:`과 `description:`만 읽어요.
   - `~/.claude/agents/*.md`(윈도우 `$HOME\.claude\agents\`)에 에이전트가 있으면 **묻지 말고** 그걸로 짜고, `claudeFolder`는 `""`(이 컴퓨터 기록 전체)로 둬요. 마지막에 "작업 폴더의 에이전트도 넣고 싶으면 '내 에이전트는 [폴더 경로]에 있어. 그 폴더 에이전트로 AI 오피스 팀 짜 줘.'라고 말해 주세요"라고 한 줄 알려 줘요.
   - `~/.claude/agents`가 비어 있으면, 사람이 Claude Code를 주로 여는 작업 폴더를 물어 그 `.claude/agents/*.md`로 짜요(3-1번과 같은 방법).
2. 에이전트가 하나도 없으면 4번으로.
3. 하는 일이 비슷한 에이전트끼리 묶어 팀을 짜요. 팀은 6개까지, 팀마다 2~6명. 에이전트가 7명보다 적으면 한 팀이어도 돼요. 1명만 남는 팀은 가장 비슷한 팀에 합쳐요. `id`는 `name:` 값 그대로, `name`은 한국어로 짧은 호칭, `role`은 하는 일을 30자 안으로(직원 목록에 담당 업무로 보여요).
4. 설정을 고쳐요. 바꾸기 전 파일은 `office.config.json.bak`로 복사해 둬요.
   ```json
   {
     "company": "회사 이름",
     "boss": "대표",
     "assistant": "비서",
     "claudeFolder": "작업 폴더 경로 (윈도우는 C:/Users/... 처럼 / 로)",
     "bossCharacter": "",
     "assistantCharacter": "",
     "teams": [
       { "name": "기획팀", "members": [ { "id": "researcher", "name": "리서치", "role": "경쟁 상품·트렌드 조사", "character": "콩이" } ] }
     ]
   }
   ```
   `claudeFolder`는 작업 폴더가 있을 때만. 없으면 `""`.
5. JSON 확인 명령을 돌려 `ok`가 나오는지 봐요. 틀렸으면 바로 고쳐요.
6. "새로고침하면 팀이 바뀌어요. 이제 에이전트를 부르면 그 직원이 실제로 일하는 모습이 보여요. 'AI 오피스 연결 시험해 줘.'라고 하면 바로 확인해 볼 수 있어요"라고 알려 줘요.

## 3-1. "내 에이전트는 [폴더 경로]에 있어. 그 폴더 에이전트로 AI 오피스 팀 짜 줘."

사람이 알려 준 경로로 작업 폴더를 정해요. 3번과 같은데 아래만 달라요.

1. 경로를 확인해요. `~`는 홈 폴더로 풀어요.
   - 알려 준 경로가 `~/.claude/agents`나 `~/.claude`(사용자 전체 에이전트)면 `claudeFolder`는 비워 둬요(`""`, 이 컴퓨터 기록 전체를 봐요). 에이전트는 `~/.claude/agents`에서 찾아요.
   - 그 밖의 폴더 안 `.claude/agents`를 알려 줬으면 그 두 단계 위가 작업 폴더예요. 그 밖의 폴더를 알려 줬으면 그 폴더가 작업 폴더예요.
   - 작업 폴더 안에 `.claude/agents/*.md`가 없으면 비어 있다고 알려 주고, 경로를 다시 묻거나 4번(에이전트 만들기)을 권해요.
2. 작업 폴더가 있으면 `claudeFolder`에 전체 경로를 넣어요(윈도우는 `C:/Users/...`처럼 `/`로). 1단계에서 비워 두기로 했으면 `""`.
3. 그 폴더의 `.claude/agents`와 `~/.claude/agents`의 에이전트로 3번 3~5단계(팀 짜기, `.bak`, JSON 확인)를 해요.
4. "새로고침하면 팀이 바뀌어요. 이제 [그 폴더]에서 Claude Code를 열고 에이전트를 부르면 사무실에 보여요. 'AI 오피스 연결 시험해 줘.'라고 하면 바로 확인해 볼 수 있어요"라고 알려 줘요.

## 4. "내 일에 맞는 에이전트 3개 만들어 줘." (에이전트가 없을 때)

같은 절: "내 일에 맞는 AI 직원(에이전트)을 만들고, AI 오피스 팀까지 짜 줘." (가이드 PART 3의 문장이에요. 아래에 `[팀 구성]`으로 팀과 직원, 직원마다 하는 일이 적혀 있어요.)
- 에이전트를 둘 곳: `claudeFolder`가 이미 있으면 그 폴더의 `.claude/agents`. 비어 있으면 바탕화면에 회사 이름으로 회사 폴더를 만들고(이미 있으면 그 폴더) 그 안 `.claude/agents`에 만든 뒤, `claudeFolder`를 그 폴더 경로로 넣어요(윈도우는 `C:/Users/...`처럼 `/`로). 이 폴더가 결과물을 모으는 회사 폴더도 돼요.
- 적힌 팀과 직원 그대로 만들어요. 직원 하나가 에이전트 파일 하나예요. 이름(`name:`)은 하는 일을 나타내는 영문 소문자와 `-`(예: `market-researcher`, `copywriter`), `description:`에는 괄호 안에 적힌 하는 일을 한국어로 구체적으로 적어요. 설정의 그 직원 `role`에도 괄호 안 하는 일을 짧게 넣어요(직원 목록에 담당 업무로 보여요).
- 만든 뒤 3번 3~5단계로 `office.config.json`을 고쳐요. 팀 이름과 순서는 사용자가 적은 그대로, 직원 `name`은 사용자가 쓴 호칭(예: "시장조사"), 회사 이름을 적었으면 `company`에.
- 마지막에 "새로고침하면 팀별로 자리가 나뉘어요. 회사 폴더는 바탕화면의 [회사 이름] 폴더예요. 직원들이 만든 결과물은 그 안 '결과물' 폴더에 모여요. 다음은 가이드 PART 4 문장으로 직원별 업무를 세팅해 주세요"라고 알려 줘요.
- "운영팀에 리뷰 답장 직원 한 명 추가해 줘"처럼 직원 추가를 부탁하면, 에이전트 파일을 하나 만들고 그 팀 `members`에 넣어요(팀마다 6명까지).
- 직원을 빼거나 `id`·팀 이름을 바꾸면 `public/desk.json`의 업무 버튼도 같이 맞춰요: 그 직원을 부르는 버튼의 prompt를 새 id로 고치거나, 빠진 직원의 버튼은 지워요(지우기 전 `desk.json.bak`). 팀 이름이 바뀌면 `tasks`의 `team`도 같이 바꿔요.

"에이전트가 아직 없어서 예시 직원만 일하고 있어요. '내 일에 맞는 에이전트 3개 만들어 줘'라고 하면 만들어 드릴게요."라고 안내해요.
- 만들어 달라고 하면 무슨 일을 하는지 묻고, Claude Code 에이전트 파일(`~/.claude/agents/<이름>.md`, 머리말에 `name`, `description`)로 만들어요. 이름은 영문 소문자와 `-`.
- 만든 뒤 3번(팀 짜기)을 이어서 해요.

## 5. "AI 오피스 다시 켜 줘." / "AI 오피스 꺼 줘."

- **켜기**: 폴더를 찾고, 4326 또는 server.log 첫 줄 번호로 확인해 이미 켜져 있으면 주소만 알려 줘요(두 번 켜지 않아요). 아니면 "켜기" 명령, 2초 뒤 확인, 브라우저 열기.
- **끄기**: 위 「끄기 안전 규칙」대로. 다른 포트로 켰다면 그 번호로. "껐어요. 다시 보려면 'AI 오피스 다시 켜 줘'라고 해 주세요."

## 6. "AI 오피스가 안 돼. 원인 찾아서 고쳐 줘."

아래를 위에서부터 하나씩 확인하고, 무엇이 문제였고 무엇을 고쳤는지 쉬운 말로 알려 줘요.

1. 폴더를 찾아요(아래 「폴더 찾기」). 없으면 설치(1번)부터.
2. `node -v`가 20 이상인지.
3. 켜져 있는지(`/api/office`). 꺼져 있으면 켜고, 안 켜지면 `<폴더>/server.log`의 마지막 줄을 읽어요. 포트를 다른 프로그램이 쓰면 다음 번호로.
4. 설정 JSON 확인 명령. 틀렸으면 `office.config.json.bak`이 있으면 비교해서 고치고, 없으면 틀린 곳만 고쳐요.
5. 화면 왼쪽 아래 "확인해 주세요" 창의 내용은 `/api/office` 응답의 `notices`와 같아요. 그 문장대로 고쳐요(그림 크기, 이름, PNG 형식).
6. 캐릭터가 없으면 2번 안내.
7. 실제 작업이 안 보이면: 설정 `teams`의 `id`가 에이전트 파일 `name:`과 같은지, `claudeFolder`가 Claude Code를 여는 폴더인지, `/api/live`가 `"ok":true`인지. 에이전트가 없으면 4번.
8. 그래도 안 되면 본 것(명령과 결과)을 정리해 보여 주고 멈춰요. 서버 코드나 보안 설정은 고치지 않아요.

## 7. "AI 오피스 연결 시험해 줘."

에이전트 한 명에게 아주 간단한 일을 진짜로 시켜 보고, 사용자가 사무실 화면에서 그 직원 머리 위 번개 표시를 직접 확인하게 해요.

1. 사무실이 켜져 있는지 보고, 꺼져 있으면 켜요. 브라우저에 사무실 화면을 띄워 두라고 말해요.
2. 설정 `teams`의 `id` 중 실제 에이전트 파일(`name:`)이 있는 직원 하나를 **묻지 말고** 골라요. 파일을 고치거나 메일·메시지를 보내지 않는 가벼운 직원(조사, 정리, 기획 담당 같은)을 고르고, "[직원 호칭]으로 시험할게요"라고 한 줄 알려 줘요. 사람이 다른 직원을 말하면 그 직원으로 해요. 에이전트가 없거나 팀에 예시 직원(`sample-`)만 있으면 "아직 연결할 에이전트가 없어요"라고 하고 4번(에이전트 만들기)으로 안내해요.
3. 시험 방법을 고르세요. 어느 쪽이든 사람이 멈추거나 폴더를 다시 열 일이 없게 해요.
   - **A. 업무지시 버튼 시험 (기본, `claudeFolder`가 정해져 있으면 이걸로)**: 사무실은 `claudeFolder`(회사 폴더)에서 일어난 일만 보기 때문에, 이 대화가 다른 폴더에서 열렸으면 여기서 부른 에이전트는 사무실에 안 보여요. 그래서 버튼으로 시험해요.
     1. `public/desk.json`의 `tasks`에 그 직원의 가벼운 일이 있는지 봐요. 없으면 "연결 시험" 버튼을 하나 추가해요: label `연결 시험`, prompt `"<팀> <호칭> 직원(<id>)에게 맡겨: 자기소개 한 줄만 써서 회사 폴더의 결과물 폴더에 .md로 저장하고, 끝나면 보고함에 올려 줘. 인터넷 검색이나 다른 작업은 하지 마."` (바꾸기 전 `desk.json.bak`, JSON 확인)
     2. "사무실 화면을 새로고침하고, 아래 '업무지시' → [그 일] 옆 '업무지시'를 눌러 주세요(확인 창이 뜨면 확인). 그 직원 머리 위에 하늘색 번개가 뜨는지 봐 주세요"라고 안내해요.
     3. 사람이 눌렀다고 하면 `<폴더>/runs` 안 가장 최근 `.log`와 `public/desk.json`의 `reports`를 1~3분 동안 30초마다 확인해요. 보고가 추가되면 성공이라고 알려 주고, '막힘'이거나 로그에 오류가 있으면 로그 마지막 줄로 원인을 쉬운 말로 알려 줘요(로그인 문제면 「업무지시 버튼 준비」 2번).
   - **B. 이 대화에서 바로 부르기 (`claudeFolder`가 비어 있거나, 이 대화가 그 폴더에서 열렸을 때)**:
     1. "지금 [직원 호칭]에게 자기소개 한 줄을 맡길게요. 사무실 화면에서 그 직원 머리 위에 하늘색 번개가 뜨는지 봐 주세요"라고 먼저 말해요.
     2. 그 에이전트를 Claude Code의 에이전트 호출 기능으로 불러 이 일만 맡겨요: "도구는 쓰지 말고 자기소개 한 줄만 답해 줘. 파일, 메일, 메시지, 인터넷 요청, 명령 실행은 하지 마."
     3. 끝나면 "방금 끝났어요. 1~2분 안에 체크 표시를 달고 대표실로 보고하러 가고, 오른쪽 아래 결재 창에 카드가 생겨요"라고 알려 줘요.
4. 번개가 안 떴다고 하면 8번 진단으로 이어가요.

## 8. "AI 오피스에 내 에이전트가 안 보여. 연결 확인해 줘."

아래를 차례로 보고, 맞는 것과 틀린 것을 표로 보여 준 뒤, 고칠 수 있는 건 허락받고 고쳐요.

1. **에이전트 파일**: `~/.claude/agents/*.md`와 `claudeFolder`의 `.claude/agents/*.md`에서 `name:` 목록. 파일 맨 위가 `---`로 시작하는 머리말이어야 하고, `name:`은 영문, 숫자, `-`, `_`만.
2. **팀 id 일치**: `office.config.json`의 `teams` 안 `id`가 1번 `name:`과 글자 하나까지 같은지. 다르면 고쳐요(JSON 확인까지).
3. **작업 폴더 일치**: `claudeFolder`가 사람이 Claude Code를 여는 폴더와 같은지. 비어 있으면 이 컴퓨터 기록 전체를 봐요.
4. **서버 응답**: `/api/live`(켜져 있나 명령의 주소 끝을 `/api/live`로). `"ok":true`면 연결된 거예요. `"reason":"no-agents"`면 팀에 실제 에이전트 id가 없음(2번), `"no-source"`면 그 작업 폴더의 기록 폴더가 없음(3번, 또는 아직 그 폴더에서 에이전트를 한 번도 안 부름), `"off"`면 연결을 끄고 켠 것(`AIO_LIVE=0` 없이 다시 켜기).
5. **실행 기록**: 기록 폴더는 `~/.claude/projects/<이름>`이에요. `<이름>`은 작업 폴더 전체 경로에서 영문 글자와 숫자가 아닌 것(한글, 공백, `/`, `\`, `:`, `.` 포함)을 모두 `-`로 바꾼 것이에요. 서버와 같은 계산(맥, 윈도우 같은 명령):
   ```
   node -e "console.log(require('path').resolve(process.argv[1]).replace(/[^A-Za-z0-9]/g,'-'))" "<작업 폴더>"
   ```
   `claudeFolder`가 비어 있으면 `~/.claude/projects` 아래 모든 폴더가 대상이라, 아래 명령을 폴더마다 돌려요(반복 명령은 이 단계 끝에). 기록 폴더 안 실행 정보 파일(`*/subagents/agent-*.meta.json`)에서 **에이전트 이름과 끝났는지, 시각만** 뽑아 봐요(설명 글이 화면에 나오지 않게 파일을 통째로 열지 말고 이 명령으로):
   ```
   node -e "const fs=require('fs'),p=require('path');const d=process.argv[1];for(const s of fs.readdirSync(d)){const sub=p.join(d,s,'subagents');if(!fs.existsSync(sub))continue;for(const f of fs.readdirSync(sub)){if(!/^agent-[0-9a-f]+\.meta\.json$/.test(f))continue;const fp=p.join(sub,f);let m;try{m=JSON.parse(fs.readFileSync(fp,'utf8'))}catch{console.log(f,'읽기 실패(쓰는 중일 수 있음)');continue}if(Date.now()-fs.statSync(fp).mtimeMs<36*3600e3)console.log(m.agentType,(m.finished||Date.now()-fs.statSync(fp).mtimeMs>90e3)?'끝':'진행',fs.statSync(fp).mtime.toISOString())}}" "<기록 폴더>"
   ```
   폴더마다 돌리기 (줄이 하나도 안 나온 폴더는 건너뛰고 봐요):
   - 맥: `for d in ~/.claude/projects/*/; do echo "== $d"; node -e "<위 명령의 따옴표 안 내용>" "$d"; done`
   - 윈도우: `Get-ChildItem -Directory "$HOME\.claude\projects" | ForEach-Object { "== $($_.FullName)"; node -e "<위 명령의 따옴표 안 내용>" $_.FullName }`
   최근 36시간 안 줄이 있고 이름이 2번 id와 같으면 기록은 정상이에요. 아무 줄도 없으면 "그 폴더에서 아직 에이전트를 부른 적이 없어요. 'AI 오피스 연결 시험해 줘.'로 한 번 불러 볼게요"라고 7번으로. 대화 기록 `.jsonl` 파일은 열지 않아요.
6. 다 맞는데도 안 보이면 사무실 화면을 새로고침하고, 서버를 껐다 켜요(끄기 안전 규칙대로).

## 폴더 찾기

1. 이 대화가 AI 오피스 폴더에서 열렸으면 그 폴더.
2. 아니면 바탕화면의 `ai-office` (`office.config.json`과 `server.mjs`가 함께 있는 폴더).
3. 거기 없으면 찾아요. 맥: `find ~/Desktop ~/Documents ~/Downloads -maxdepth 3 -name office.config.json` / 윈도우: `Get-ChildItem "$HOME\Desktop","$HOME\Documents","$HOME\Downloads" -Recurse -Depth 3 -Filter office.config.json -ErrorAction SilentlyContinue`. `server.mjs`가 옆에 있는 것만.
4. 그래도 없으면 사람에게 물어봐요.

## 자주 막히는 곳

| 증상 | 할 일 |
|---|---|
| `node`를 찾을 수 없음 | Node.js 설치 후 Claude Code를 새로 열라고 안내 |
| `python3`를 찾을 수 없음 | 맥은 python.org 설치, 윈도우는 `python`이나 `py`로 다시 |
| 포트를 이미 씀 | 그게 AI 오피스면 그대로 쓰고, 아니면 다음 번호로 켜기 |
| 캐릭터가 안 나옴 | 화면 왼쪽 아래 "확인해 주세요" 창의 문장대로 고치기 |
| 실제 작업이 안 보임 | 설정의 `id`가 에이전트 `name:`과 같은지, `claudeFolder`가 맞는지. 에이전트가 없으면 4번 |
| 기록 폴더 위치를 바꿔 쓰는 고급 사용자 | 서버를 켤 때 `AIO_CLAUDE_HOME=<.claude 폴더>`(윈도우 `$env:AIO_CLAUDE_HOME=...`)로 알려 줄 수 있어요 |
| 윈도우에서 스크립트 실행이 막힘 | 이 안내의 명령은 스크립트 파일이 아니라 한 줄 명령이라 보통 괜찮아요. 막히면 메시지를 그대로 사람에게 보여 주고 멈춰요 |

---

## 냥빌더판에서 더한 것

1인 사업자가 실제 업무에 쓰기 좋게 냥빌더가 더한 기능이에요. 화면 아래 버튼과 왼쪽 탭에서 써요.

- **업무지시**: `public/desk.json`의 `tasks`에 적힌 일을 팀별로 보여 줘요. 일마다 '업무지시'를 누르면 이 PC의 Claude Code(Sonnet)가 뒤에서 바로 일해요(Claude Code 로그인 필요, 하루 10회, `claudeFolder` 필요). 자료를 붙여 넣어야 하는 일만 지시문이 복사돼요.
- **보고함**: 일이 끝나면 `public/desk.json`의 `reports`에 한 줄씩 쌓여요. '결과물 보기'로 결과 파일(회사 폴더 안의 .md/.txt/.json/.csv)을 열어 볼 수 있어요.
- **산책 보내기**: 아래 '직원 목록'에서 직원마다 '산책'을 누르면 산책을 다녀와요.
- **주간 일정·오늘 할 일**: 왼쪽 📅 탭. 시간표는 `schedule.json`, 할 일은 브라우저에 저장돼요.
- **뽀모도로·근무시간**: 위쪽 띠에서 집중/쉬기 타이머와 카페·장작 소리를 켤 수 있어요.

### "AI 오피스 업무지시 버튼 준비해 줘." (업무지시 버튼 준비)

업무지시 버튼은 이 PC의 **터미널용 Claude Code**(`claude` 명령)를 뒤에서 실행해요. Claude 데스크톱 앱만 쓰는 분은 따로 준비가 필요해요.

1. `claude --version`이 되는지 봐요. 안 되면 설치 명령을 보여 주고 사람이 직접 실행하게 해요(사람 동의 없이 설치하지 않아요).
   - 윈도우 PowerShell: `irm https://claude.ai/install.ps1 | iex`
   - 맥 터미널: `curl -fsSL https://claude.ai/install.sh | bash`
2. `claude auth status`가 `"loggedIn": true`인지 봐요. 아니면 "PowerShell(맥은 터미널)을 열고 `claude auth login`을 입력해 브라우저로 로그인해 주세요. 로그인은 직접 해 주셔야 해요"라고 안내해요. 비밀번호나 코드는 받지 않아요.
3. `office.config.json`의 `claudeFolder`가 비어 있으면 아래 「업무지시 목록 내 일에 맞게 바꿔 줘」 절의 0번처럼 회사 폴더를 정해요.
4. 다 되면 "AI 오피스 연결 시험해 줘"나 업무지시 버튼 하나로 시험해 보라고 안내해요. 끝나면 보고함에 카드가 생기고 '결과물 보기'로 내용이 펼쳐져요.
5. 업무지시가 '막힘'으로 끝났다고 하면 `<폴더>/runs` 안 가장 최근 `.log` 파일의 마지막 몇 줄을 읽고 원인을 쉬운 말로 알려 줘요. 로그인 문제면 2번으로, 회사 폴더 문제면 3번으로 돌아가요.

### "업무지시 하루 횟수를 20회로 늘려 줘."

업무지시 버튼은 하루 10회가 기본이에요(실수로 여러 번 눌러 Claude 사용량이 한꺼번에 나가지 않게).
1. 말한 숫자를 `office.config.json`에 `"runLimit": 20`처럼 넣어요. 1~50 사이만 돼요(50을 넘게 말하면 50으로 하고 그렇게 알려 줘요). 바꾸기 전 `office.config.json.bak`, 고친 뒤 JSON 확인.
2. "횟수가 늘수록 Claude 사용량도 그만큼 더 쓸 수 있어요"라고 한 줄 알려 주고, "사무실 화면을 새로고침하면 바로 반영돼요(서버를 다시 켤 필요 없어요)"라고 안내해요.
3. 줄여 달라고 하면 같은 방법으로 낮추고, "기본으로 돌려 줘"라고 하면 `runLimit` 줄을 지워요.

### "업무지시 목록 내 일에 맞게 바꿔 줘."

같은 절: "AI 오피스 업무지시 목록을 내 일에 맞게 바꿔 줘…", "AI 오피스 업무지시 목록을 아래처럼 세팅해 줘." (가이드 PART 4. 아래에 `[팀 이름]`마다 "직원: 할 일"이 적혀 있어요), "AI 오피스 업무지시에 ○○ 직원 일로 … 추가해 줘."

**직원별로 적어 준 경우**: 적힌 줄 하나가 버튼 하나예요. `label`은 할 일을 12자 안팎으로 줄인 것, `prompt`는 이렇게 써요: `"<팀> <직원 호칭> 직원(<에이전트 id>)에게 맡겨: <적힌 할 일 그대로, 모양·개수 포함>. 결과물은 회사 폴더의 결과물 폴더에 .md로 저장하고, 끝나면 보고함에 올려 줘."` 에이전트 id는 `office.config.json`의 그 직원 `id`예요. 그런 직원이 없으면 4번대로 먼저 만들어요.
- 사용자의 자료(매출 파일, 문의 내용 등)가 있어야 하는 일이면 prompt 끝에 "(필요한 자료는 대표가 붙여넣어 줄 거야)"를 붙여요. 이 말이 들어간 버튼은 바로 실행 대신 지시문 복사로 동작해요.
- 기존 `tasks`는 바꾸기 전 `desk.json.bak`에 남기고, 예시 팀(`예시 팀`으로 시작하는 것)은 지워요.

0. `office.config.json`의 `claudeFolder`가 비어 있으면 업무지시 버튼이 동작하지 않아요. 회사 폴더(결과물을 모을 폴더)를 묻고, 따로 없다고 하면 바탕화면에 회사 이름(`office.config.json`의 `company`)으로 폴더를 만들어(이미 있으면 그 폴더) 그 경로를 넣어요(윈도우는 `C:/Users/...`처럼 `/`로). 에이전트가 `~/.claude/agents`에 있어도 그대로 불려요.
1. 내 팀(`office.config.json`의 `teams`)과 하는 일을 확인하고, 팀마다 자주 시킬 일 2~4개를 `tasks`에 적어요. 형식: `{ "team": "팀 이름", "items": [ { "label": "버튼에 보일 짧은 이름", "prompt": "그 팀 직원(id)에게 맡길 지시문. 끝나면 보고함에 올려 줘." } ] }`
2. `plan`은 요일(`매일`, `월`~`일`)별 할 일 목록이에요. 사람이 말한 루틴으로 채워요. 이건 업무지시 창 맨 위 "오늘 할 일"에 보여요. 다 채운 뒤 "요일별 업무는 업무지시 창 맨 위 '오늘 할 일'에 나와요. 왼쪽 주간 일정 시간표도 바꾸려면 '주간 일정 바꿔 줘'라고 해 주세요"라고 알려 줘요.
3. 바꾸기 전 `desk.json.bak`으로 복사하고, 고친 뒤 JSON 확인 명령으로 `ok`인지 봐요.

### 보고함에 올리기 (팀 일이 끝났을 때 AI가 할 일)

`public/desk.json`의 `reports` 맨 끝에 한 줄 추가해요. 다른 줄은 건드리지 않아요.

```json
{ "id": "2026-01-05-기획팀-1", "date": "2026-01-05", "team": "기획팀", "agent": "researcher", "title": "한 줄 제목", "summary": "무엇을 했는지 두세 문장", "file": "결과물/2026-01-05 아이디어.md", "next": "승인하면 다음에 할 일" }
```

`file`은 회사 폴더(`claudeFolder`) 기준 상대 경로예요. 결과물은 회사 폴더 안 `결과물` 폴더에 저장해요.

### "주간 일정 바꿔 줘."

`schedule.json`의 `days`는 일요일부터 토요일까지 7칸이에요. 칸마다 `["시작", "끝", "할 일", "분류"]` 목록. 분류는 `work`(본업), `content`(콘텐츠), `study`(공부), `side`(부업), `check`(점검·계획), `meal`(식사), `rest`(휴식) 중 하나예요.

---

## 만든 곳

냥빌더 (인스타그램 @nyang_builder_)
