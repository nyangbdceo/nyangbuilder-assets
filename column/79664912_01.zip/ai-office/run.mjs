// 화면에서 바로 일 시키기 (냥빌더판에서 추가): '일 시키기'·'보고함' 버튼이 이 PC의 Claude Code를 Sonnet으로 뒤에서 실행한다.
// 지킴: ① 이 화면에서 온 요청만(Origin + 서버를 켤 때마다 새로 만드는 열쇠) ② 하루 횟수 제한(office.config.json의 runLimit 1~50, 또는 AIO_RUN_LIMIT, 기본 10)
//       ③ 한 번에 2개까지 ④ 쓸 수 있는 도구를 정해 둠(읽기·쓰기·웹 검색·에이전트·node만, 그 밖의 명령 실행은 안 됨)
// 실행 기록은 runs/ 폴더에 날짜별 횟수와 로그로 남는다.
import { spawn, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import { expandHome } from './office.mjs';

export const RUN_TOKEN = randomBytes(16).toString('hex');
// 하루 횟수: 환경변수 > office.config.json의 runLimit(1~50) > 10. 설정은 누를 때마다 다시 읽는다(서버를 다시 켜지 않아도 된다)
const limitFrom = (HERE) => {
  const env = Number(process.env.AIO_RUN_LIMIT);
  if (env > 0) return Math.min(50, Math.floor(env));
  try { const n = Number(JSON.parse(readFileSync(join(HERE, 'office.config.json'), 'utf8')).runLimit); if (n > 0) return Math.min(50, Math.floor(n)); } catch { /* 설정이 깨졌으면 기본값 */ }
  return 10;
};
const MAX_PARALLEL = 2;
const TOOLS = 'Read,Glob,Grep,Edit,Write,WebSearch,WebFetch,Agent,Task,TodoWrite,Bash(node:*)';
const CLAUDE = [process.env.AIO_CLAUDE, join(homedir(), '.local', 'bin', 'claude.exe'), join(homedir(), '.local', 'bin', 'claude')].find((p) => p && existsSync(p)) || 'claude';

// Claude Code(데스크톱 앱 등) 안에서 서버를 켜면 그 세션 설정(CLAUDECODE, CLAUDE_CODE_*)이 따라와서 로그인 갱신이 꼬인다. 실행할 때는 빼고 넘긴다.
const cleanEnv = () => Object.fromEntries(Object.entries(process.env).filter(([k]) => !/^(CLAUDECODE|CLAUDE_CODE_)/.test(k)));

const runs = []; // 최근 20개: { id, team, label, state, startedAt, endedAt, tail }
const today = () => new Date().toLocaleDateString('sv-SE');

export function makeRunner(HERE, getOffice, port) {
  const dir = join(HERE, 'runs');
  mkdirSync(dir, { recursive: true });
  const countFile = join(dir, 'count.json');
  const used = () => { try { const c = JSON.parse(readFileSync(countFile, 'utf8')); return c.date === today() ? c.n : 0; } catch { return 0; } };
  const bump = (d = 1) => writeFileSync(countFile, JSON.stringify({ date: today(), n: Math.max(0, used() + d) }));
  // 로그인 확인: 로그인이 풀려 있으면 실행하지 않고(횟수도 안 씀) 대표에게 알려 준다
  const loggedIn = () => { try { const r = spawnSync(CLAUDE, ['auth', 'status'], { env: cleanEnv(), encoding: 'utf8', windowsHide: true, timeout: 15000 }); return /"loggedIn":\s*true/.test(r.stdout || ''); } catch { return false; } };
  const LIMIT_NOW = () => limitFrom(HERE);
  const originOk = (req) => [`http://127.0.0.1:${port()}`, `http://localhost:${port()}`].includes(String(req.headers.origin || ''));

  function status() {
    return { limit: LIMIT_NOW(), used: used(), runs: runs.map(({ child, ...r }) => r) };
  }

  async function start(req) {
    if (!originOk(req) || req.headers['x-aio-token'] !== RUN_TOKEN) return { code: 403, body: { ok: false, error: '이 화면에서 온 요청이 아니에요. 새로고침해 주세요.' } };
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) return { code: 415, body: { ok: false, error: 'JSON만 받아요.' } };
    let raw = '';
    for await (const ch of req) { raw += ch; if (raw.length > 8000) return { code: 413, body: { ok: false, error: '너무 길어요.' } }; }
    let b; try { b = JSON.parse(raw); } catch { return { code: 400, body: { ok: false, error: '요청을 읽지 못했어요.' } }; }
    const team = String(b.team || '').slice(0, 40), label = String(b.label || '').slice(0, 80), prompt = String(b.prompt || '').slice(0, 2000);
    if (!prompt.trim()) return { code: 400, body: { ok: false, error: '지시문이 비어 있어요.' } };
    const LIMIT = LIMIT_NOW();
    if (used() >= LIMIT) return { code: 429, body: { ok: false, error: `오늘 ${LIMIT}회를 다 썼어요. 내일 다시 쓸 수 있어요. (하루 횟수는 Claude Code에 "업무지시 하루 횟수를 20회로 늘려 줘"처럼 말하면 바꿀 수 있어요)` } };
    if (runs.filter((r) => r.state === 'running').length >= MAX_PARALLEL) return { code: 429, body: { ok: false, error: `지금 ${MAX_PARALLEL}개가 일하는 중이에요. 하나 끝나면 다시 눌러 주세요.` } };
    if (!loggedIn()) return { code: 401, body: { ok: false, error: '터미널용 Claude Code가 로그인돼 있지 않아요. Claude Code에 "AI 오피스 업무지시 버튼 준비해 줘"라고 하거나, PowerShell(맥은 터미널)에서 claude auth login 을 입력해 로그인한 뒤 다시 눌러 주세요. (횟수는 안 썼어요)' } };
    const o = await getOffice();
    const cwd = o.claudeFolder ? resolve(expandHome(o.claudeFolder)) : '';
    if (!cwd || !existsSync(cwd)) return { code: 500, body: { ok: false, error: '회사 폴더(claudeFolder)를 찾지 못했어요.' } };

    const id = `${today()}-${Date.now().toString(36)}`;
    const desk = join(HERE, 'public', 'desk.json').split('\\').join('/');
    const full = `${prompt}\n\n(AI 오피스 화면의 버튼으로 대표가 맡긴 일이야. 말한 팀 직원(코드명) 에이전트를 Agent 도구로 불러서 맡겨. 대표에게 되묻지 말고 할 수 있는 데까지 해.\n` +
      `결과물은 이 폴더 안 '결과물' 폴더에 .md 파일로 저장해.\n` +
      `끝나면 \`${desk}\`의 reports 배열 맨 끝에 보고 한 줄을 꼭 추가해 (다른 줄은 건드리지 말고, JSON이 깨지지 않게):\n` +
      `{"id":"${today()}-${team}-<번호>","date":"${today()}","team":"${team}","agent":"<맡은 직원 코드명>","title":"한 줄 제목","summary":"무엇을 했는지 두세 문장","file":"결과물/<파일 이름>.md","next":"승인하면 다음에 할 일"})`;
    const log = join(dir, `${id}.log`);
    const child = spawn(CLAUDE, ['-p', full, '--model', 'sonnet', '--permission-mode', 'acceptEdits', '--add-dir', HERE, '--allowedTools', TOOLS, '--output-format', 'text'], { cwd, env: cleanEnv(), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    const run = { id, team, label, state: 'running', startedAt: Date.now(), endedAt: 0, tail: '', child };
    runs.unshift(run); runs.length = Math.min(runs.length, 20);
    bump();
    const onData = (d) => { const t = d.toString(); try { appendFileSync(log, t); } catch { /* 로그 못 써도 진행 */ } run.tail = (run.tail + t).slice(-1200); };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    child.on('error', (e) => { run.state = 'error'; run.tail = `Claude Code를 실행하지 못했어요: ${e.message}`; run.endedAt = Date.now(); });
    child.on('close', (code) => {
      if (run.state === 'running') run.state = code === 0 ? 'done' : 'error';
      if (run.state === 'error') { // 흔한 원인은 한국어로 덧붙인다 (화면은 tail 끝부분을 보여 준다)
        const t = run.tail;
        if (/usage limit|rate.?limit|limit reached|quota|credit balance|out of (credits|usage)|429/i.test(t)) run.tail += '\n⚠️ Claude 사용량 한도에 걸렸어요. 한도가 풀린 뒤(보통 몇 시간 안) 다시 눌러 주세요.';
        else if (/oauth|not logged in|log ?in|authenticat|401|token/i.test(t)) run.tail += '\n⚠️ 터미널용 Claude Code 로그인 문제예요. PowerShell에서 claude auth login 으로 다시 로그인한 뒤 눌러 주세요.';
        else if (/ENOTFOUND|ECONNRESET|network|timed? ?out/i.test(t)) run.tail += '\n⚠️ 인터넷 연결이 끊겼어요. 연결을 확인하고 다시 눌러 주세요.';
      }
      if (run.state === 'error' && Date.now() - run.startedAt < 60000) bump(-1); // 시작하자마자 막힌 건 횟수에서 빼 준다
      run.endedAt = Date.now(); delete run.child;
    });
    return { code: 200, body: { ok: true, id, used: used(), limit: LIMIT } };
  }
  return { status, start };
}
